#This file has two sections. The first section constitutes helper functions and globals. The helper functions are not exported and cannot be called directly outside the file.
# The second section constitutes the actual cmdlets that are exported from this module

# get the module file properties. Note that get-module doesn't work here as the environment isn't fully initialised, but test-modulemanifest will work to get a ref
$manifestpath = $PSScriptRoot + "\Custom1Etoolkit.psd1"
$MODULE = test-modulemanifest $manifestpath
$MODULEFILE = $MODULE.name + ".psd1"

$TOOLKITVERSION = $MODULE.version.ToString()
$CMDPREFIX = $MODULE.prefix # required for auto-generated code (as user may have changed the cmdlet prefix for legacy use)

$INSTRUCTIONSIGNTOOL = "Tachyon.InstructionSigner" #executable used to sign dynamically-created instructions
$PPDTTOOL = "tachyon.productpackdeploymenttool.exe" #executable used to deploy product packs

$TACHYONURL = ""
$TACHYONVER = ""
$TACHYONMAJORVER = 0 # updated when we set the platform server and used in some cases where there is a min platform version prereq for a cmdlet
$TACHYONMINORVER = 0

$TACHYONCLOBSIZE = 0

$progressPreference = 'silentlyContinue' # this causes invoke-webrequest not to display a progress bar.


$TACHYONCONSUMER = "Explorer" # Consumer to use when executing instructions

$TENANTID = "1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E" #used when a default tenant ID is required
$PLATFORMPRINCIPAL = "TachyonPlatform" #the configured principal under which Tachyon Platform services run
$JWTEXPIRYSEC = 3600 # standard expiry period for JWTs

$TACHYONAUTHENDPOINT = "/tachyon/api/Authentication" # this is the standard Tachyon authentication endpoint

# when aggregating results (which would otherwise be associated with a device), use this fixed key as the parent for the dataset

$AGGREGATEKEY = "Aggregate"
$ERRORURLSUBSTRING = "Error" # assumed to be part of error retrieval URL


$USEBASICAUTH = $false # set to $true to use basic authentication, false to use NTLM authentication
$USEPROXY = $false # set to $true to use the platform proxy. USEBASICAUTH setting should be false to use this option
$PROXYVIANTLM = $false # set to true internally if we manage to connect to proxy using NTLM inbound
$CLIENTCERT = $null # set when negotiating with proxy if a client cert is required, to the appropriate cert
$PROXYAPITOKEN = $null # set when connecting to proxy
$IGNOREINVALIDSSLCERTS = $true #set to $true if you don't care about the platform server cert (e.g, you don't have a trust chain to it on your endpoint cert store)
$TOKENTTL = 120 # token remaining lifetime in seconds before being marked invalid. You can set this to a larger value for testing e.g 3550, which would make a token cease to be valid 50 seconds after it was issued (assuming 1 hour lifetime)

$gLastInstructionId = 0 # updated by anything that runs an instruction so we can retrieve 'last instruction' status subsequently

if ($IGNOREINVALIDSSLCERTS)

    {
    # may already exist in scope; just throw and ignore if it is
    try
        {
    Add-Type @"
        using System;
        using System.Net;
        using System.Net.Security;
        using System.Security.Cryptography.X509Certificates;
        public class ServerCertificateValidationCallback
        {
            public static void Ignore()
            {
                ServicePointManager.ServerCertificateValidationCallback += 
                    delegate
                    (
                        Object obj, 
                        X509Certificate certificate, 
                        X509Chain chain, 
                        SslPolicyErrors errors
                    )
                    {
                        return true;
                    };
            }
        }
"@
    }

    catch
    {
    }

    [ServerCertificateValidationCallback]::Ignore();
    }


##### begin support functions #####

$INSTPREFIX = "1E-Exchange" # Instruction prefix that you have a license for and corresponding code signing certificate in your local machine cert store
                 # Use set-instructionprefix to set this (or just hard-code it if you prefer)

$INSTRUCTIONSET = "DynamicScripting" # Instruction set name where dynamic instructions are created on the platform

$MAXTARGETDEVICES = 100 # Maximum number of devices allowed to be targetted by scope; this is a safety-catch to prevent you accidentally sending stuff out to a large device count

$MAXSYNCTARGETDEVICES = 5 # Maximum number of devices allowed to be targetted by a synchronous instruction

$METHODMETADATAFILE = "methods.json" # assumed name of methods metadata file

#### Platform-neutral authentication support functions #####

# invoke interactive login process and get an interactive token

function GetInteractiveToken($server)
{
Try{  
    $token = ""
    Do{
        write-information -MessageData ([string](get-date) + " Attempting to interactively authenticate")
        $url = "wss://" + $server + $TACHYONAUTHENDPOINT + "/RequestAuthentication"
        $WS = New-Object System.Net.WebSockets.ClientWebSocket                                                
        $CT = New-Object System.Threading.CancellationToken
        $WS.Options.UseDefaultCredentials = $true

        #Get connected
        $Conn = $WS.ConnectAsync($URL, $CT)
        While (!$Conn.IsCompleted) { 
            Start-Sleep -Milliseconds 100 
        }
        write-information -MessageData ([string](get-date) + " Connected to " + $($URL))
        $Size = 8192 # note in extreme edge cases a user with LOTS of group memberships might exceed this limit
        $Array = [byte[]] @(,0) * $Size

        #Send Starting Request
        $Command = [System.Text.Encoding]::UTF8.GetBytes("ACTION=Command")
        $Send = New-Object System.ArraySegment[byte] -ArgumentList @(,$Command)            
        $Conn = $WS.SendAsync($Send, [System.Net.WebSockets.WebSocketMessageType]::Text, $true, $CT)

        While (!$Conn.IsCompleted) { 
            write-information -MessageData ([string](get-date) + " Sleep waiting for connection completion")
            Start-Sleep -Milliseconds 100 
        }

        write-information -MessageData ([string](get-date) + " Request sent")

        #Start reading the received items
        While ($WS.State -eq 'Open') {                        
           $Recv = New-Object System.ArraySegment[byte] -ArgumentList @(,$Array)
            $Conn = $WS.ReceiveAsync($Recv, $CT)
            While (!$Conn.IsCompleted) { 
                    write-information -MessageData ([string](get-date) + " Sleep waiting for receive connection completion")
                    Start-Sleep -Milliseconds 100
            }

            write-information -MessageData ([string](get-date) + " Receive complete")

            $response = [System.Text.Encoding]::utf8.GetString($Recv.array)
            write-information -MessageData ([string](get-date) + " Response: " + $response)
            try
                {
                $res = $response -match "{.*}"
                # to support the testbed, which returns data as simple strings currently, handle this
                if ($res)
                    {
                    $res = $matches[0]
                    $res = convertfrom-json $res
                    $response = $res.Data
                    }
                else
                    {
                    $response = $res
                    }
                }
            catch
                {
                write-information -MessageData ([string](get-date) + " Response was not in expected JSON format")
                throw "Unable to parse response"
                }

            write-information -MessageData ([string](get-date) + " Response length: " + $response.Length)

            if ($response.IndexOf([char]0) -gt 0)
                {
                $response = $response.substring(0,$response.IndexOf([char]0))
                }
# TODO: final platform will return proper DTO here
            if ($response.StartsWith("https"))
                {
                write-information -MessageData ([string](get-date) + " Authentication URL received, invoking browser")
                start-process $response
                }
            else
                {
                write-information -MessageData ([string](get-date) + " Token or error received")
                $token = $response
                }

        }   
    } Until ($WS.State -ne 'Open')

}Finally{

    If ($WS) { 
        write-information -MessageData ([string](get-date) + " Closing websocket")
        $WS.Dispose()
    }
}
write-information -MessageData ([string](get-date) + " Processing Token, length = " + $token.Length)
$r = $token -match "{.*}" # temporary: remove gunge at end of current interim token
if ($r)
    {
    $tokenJson = $matches[0]
    return $tokenJson
    }
return $token
}

function getJwkFromCert($cert)
{
$publickey = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPublicKey($cert)
$param = $publicKey.ExportParameters($false)
$modulus = ToBase64Url $param.modulus
$exp = ToBase64Url $param.exponent
 
$jwk = New-Object PSObject -Property @{
            kty = "RSA"
            use = "sig"
            alg = "RS256"
            kid = (getThumbprint $cert.Thumbprint)
            n = $modulus
            e = $exp
            }

return $jwk | convertto-json
}

function GetOS()
{
if ($iswindows)
	{
	return "Windows"
	}
if ($islinux)
	{
	return "Linux"
	}
if ($isMacOS)
	{
	return "MacOS"
	}
# legacy PS doesn't define these variables and so we drop through and return Windows
return "Windows"
}


function GetEmptyToken()
{
return New-Object PSObject -Property @{
	Token = $null
	ExpiryTime = $null
	IssueAppId = $null
	IssueCertSubject = $null
	IssueCertThumbprint = $null
	IssuePrincipal = $null
	TokenType = $null
    }
}

function GetUTCNow()
{
return (get-date).ToUniversalTime()
}

function IsTokenValid($wrappedToken)
{
$expiryTime = GetWrappedTokenExpiryUTC $wrappedToken
$timeToLive = ($expiryTime - (GetUTCNow)).TotalSeconds
if ($timeToLive -gt $script:TOKENTTL)
    {
    return $true
    }
return $false
}

function GetOrUpdateToken($wrappedToken)
{
if ((IsNullOrEmpty $wrappedToken) -or (IsNullOrEmpty $wrappedToken.Token) -or (IsTokenValid $wrappedToken))
    {
    return $wrappedToken
    }
write-information -MessageData ([string](get-date) + " Token was null or expired: requesting update")
return Update-AuthToken
}

function DecodeAuthToken($authToken)
{
	if (IsNullOrEmpty $authToken)
		{
		throw "No current auth token is defined"
		}
	$token = $authToken.split(".")[0]
	$token = FromBase64Url $token
	$token = convertfrom-json $token
    return $token
}

function GetTokenExpiryUTC($authToken)
{
return ([DateTime]((DecodeAuthToken $authToken).Expiration)).ToUniversalTime()
}

function GetWrappedTokenExpiryUTC($wrappedToken)
{
return ([DateTime]($wrappedToken.ExpiryTime)).ToUniversalTime()
}

function ConnectProxyWithClientCerts()
{
$clientCerts = getClientCerts
if ($clientCerts.Count -eq 0)
    {
    return $false
    }

foreach ($cert in $clientCerts)
    {
    $script:CLIENTCERT = $cert
    try
	    {
	    $res = GetProxyInfo #non-authenticated, but will fail if a valid client cert isn't presented.
        return $true
	    }
    catch
        {
        }
    }
return $false
}

function RefreshAuthToken($authToken)
{
if (IsNullOrEmpty $authToken -or IsNullOrEmpty $authToken)
    {
    throw "No current authentication token to refresh"
    }
$url = $TACHYONAUTHENDPOINT +"/RefreshToken"
$res = PostHttpRequest $url (quotify $authToken.Token)
return $res
}

function InvalidateAuthToken($authToken)
{
if (IsNullOrEmpty $authToken -or IsNullOrEmpty $authToken)
    {
    throw "No current authentication token to invalidate"
    }
$url = $TACHYONAUTHENDPOINT +"/InvalidateToken"
$res = PostHttpRequest $url (quotify $authToken.Token)
return $res
}

function getMetadataEndpoint()
{
$url= $TACHYONAUTHENDPOINT +"/metadataendpoint"
$res = GetHttpRequest $url
return $res
}

#used in non-Windows environments where cert: namespace not available

function GetCertFromStore($storename, $locator, $findType)
{
$storeparts = $storename.split("\") # e.g LocalMachine\My or for most non-windows platforms, CurrentUser\My
$store = new-object system.security.cryptography.X509certificates.x509store($storeparts[1] , $storeparts[0])
$store.Open("ReadOnly")
if (IsNullOrEmpty $locator)
	{
	$cers = $store.Certificates
	}
else
	{
	$cers = $store.Certificates.Find($findType, $locator, $false)
	}
$store.Close()
return $cers
}

function GetCertBySubject($certsubject)
{
	if (IsNullOrEmpty $CertSubject)
	{
		throw "You must supply a certificate subject"
	}

        write-information -MessageData ([string](get-date) + " Attempting to locate a suitable signing certificate by subject: " + $CertSubject)
	$os = GetOS
	if ($os -eq "Windows")
		{
	        $cert = get-childitem cert:\\localmachine\my | where-object {$_.Subject -eq $CertSubject}
		}
	else
		{
		$cert = GetCertFromStore "CurrentUser\My" $CertSubject 2
		}

        if ($cert.Count -eq 0)
   	     {
	     throw "Unable to locate certificate with specified subject"
	     }
	return $cert
}

function GetCertByThumbprint($certthumbprint)
{
	if (IsNullOrEmpty $CertThumbprint)
	{
		throw "You must supply a certificate thumbprint"
	}
        write-information -MessageData ([string](get-date) + " Attempting to locate a suitable signing certificate by thumbprint: " + $certthumbprint)
	$os = GetOS
	if ($os -eq "Windows")
		{
	        $cert = get-childitem cert:\\localmachine\my | where-object {$_.Thumbprint -eq $CertThumbprint}
		}
	else
		{
		$cert = GetCertFromStore "CurrentUser\My" $CertThumbprint 0
		}

        if ($cert.Count -eq 0)
   	     {
	     throw "Unable to locate certificate with specified thumbprint"
	     }
	return $cert
}

function HaveValidToken()
{
if (-not (IsNullOrEmpty $script:AUTHTOKEN) -and -not (IsNullOrEmpty $script:AUTHTOKEN.Token))
    {
    return $true
    }
return $false
}

function GetTokenEndpoint($metadataUrl)
{
$res = GetHttpRequestExternal $metadataUrl
return $res.token_endpoint
}
 
function ToUnixTimestamp($datetime)
{
    $epoch = Get-Date -Year 1970 -Month 1 -Day 1 -Hour 0 -Minute 0 -Second 0   
    $seconds = [math]::truncate($datetime.ToUniversalTime().Subtract($epoch).TotalSeconds)
    return $seconds
}  
 
function GetJwt($audience, $issuer, $subject, $upn)
{
$timestamp= (ToUnixTimeStamp (Get-Date))
$exptimestamp= $timestamp + $script:JWTEXPIRYSEC
$jwt = New-Object PSObject -Property @{
                aud = $audience
		        iat = [string]$timestamp
                exp = [string]$exptimestamp
                iss = $issuer
                sub = $subject
                jti = [string](new-guid)
                }
if (-not (IsNullOrEmpty $upn))
    {
    add-member -MemberType NoteProperty -Name "Tachyon.upn" -Value $upn -inputobject $jwt -force
    }

return $jwt
}
 
function getJwtHdr($thumbprint)
{
$jwtHdr = New-Object PSObject -Property @{
                alg = "RS256"
                typ = "JWT"
                x5t = $thumbprint
                kid = $thumbprint
                }
return $jwtHdr
 
}
 
function GetSignedClientAssertion($jwt, $certificate)
{
$jwtHdr = getJwtHdr (ToBase64Url $certificate.GetCertHash())
$jwtHdrJson = convertto-json $jwtHdr
$jwtHdrBytesEncoded = ToBase64UrlString $jwtHdrJson
 
$jwtJson = convertto-json $jwt
$jwtBytesEncoded = ToBase64urlString $jwtJson
 
$token = $jwtHdrBytesEncoded + "." + $jwtBytesEncoded 
return GetSignedAssertion $token $certificate
}

function GetSignedAssertion($assertion, $certificate)
{
$rsa = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($certificate)
$assertionBytes = [System.Text.Encoding]::UTF8.GetBytes($assertion)
$padding = [System.Security.Cryptography.RSASignaturePadding]::Pkcs1
$signature = $rsa.SignData($assertionbytes, "SHA256", $padding)
$signatureEncoded = ToBase64Url $signature
$signedClientAssertion = $assertion + "." + $signatureEncoded
return $signedClientAssertion
}

function GetSignedJwt($cert, $tokenEndpoint, $appId, $principal)
{
    write-information -MessageData ([string](get-date) + " Using certificate to sign JWT: thumbprint" + $cert.thumbprint)
    $token = GetJwt $tokenEndpoint $AppId $AppId $principal
    $signedToken = GetSignedClientAssertion $token $cert
    write-information -MessageData ([string](get-date) + " successfully signed JWT")
    return $signedToken
}


function GetAuthToken($cert, $upn, $tokenEndpoint, $appId)
{
    write-information -MessageData ([string](get-date) + " Using certificate to sign JWT: thumbprint" + $cert.thumbprint)
    $token = GetJwt $tokenEndpoint $AppId $AppId $upn
    $signedToken = quotify (GetSignedClientAssertion $token $cert)
    write-information -MessageData ([string](get-date) + " successfully signed JWT")
    $url = $TACHYONAUTHENDPOINT +"/RequestJwtAuthentication"
    $authToken = PostHttpRequest $url $signedToken
    write-information -MessageData ([string](get-date) + " Retrieved authentication token from endpoint")
    return $authToken
}

function GetBearerToken($cert, $tokenEndpoint, $appId, $scope, $secret)
{
    if (-not (IsNullOrEmpty $Secret))
        {
        write-information -MessageData ([string](get-date) + " Using shared secret to retrieve bearer token")
        $res = GetBearerTokenFromSecret $secret $tokenEndpoint $appId $scope
        return $res
        }
    write-information -MessageData ([string](get-date) + " Using certificate to sign JWT: thumbprint" + $cert.thumbprint)
    $token = GetJwt $tokenEndpoint $AppId $AppId 
    $signedToken = GetSignedClientAssertion $token $cert
    write-information -MessageData ([string](get-date) + " successfully signed JWT")
    $res = GetBearerTokenFromAssertion $signedToken $tokenEndpoint $scope
    return $res
}

function GetBearerTokenFromSecret($secret, $tokenEndpoint, $appId, $scope)
{
$payload = @{
  "client_id" = $appId
  "client_secret" = $secret
  "grant_type" = "client_credentials"
  "scope" = $scope
}
 
$addhdrs = @{
    "Content-type" = "application/x-www-form-urlencoded"
    }
$res = PostHttpRequestExternal $tokenEndpoint $payload $addhdrs
return $res
}

function GetBearerTokenFromAssertion($signedAssertion, $tokenUrl, $scope)
{
$payload = @{
    "grant_type"="client_credentials"
    "client_assertion_type"="urn:ietf:params:oauth:client-assertion-type:jwt-bearer"
    "client_assertion" = $signedAssertion
    "scope" = $scope
    }
 
$addhdrs = @{
    "Content-type" = "application/x-www-form-urlencoded"
    }
$res = PostHttpRequestExternal $tokenurl $payload $addhdrs
return $res
}

function IsLegacyPS()
{
if ($PSVersionTable.PSEdition -eq "Desktop")
	{
	return $true
	}
return $false
}

### Azure Credential Vault functions. Note: these only work in PowerShell Core (but they do work in non-Windows platforms)

function AddTypes()
{
add-type -assembly Azure.Identity 
add-type -assembly Azure.Security.KeyVault.Certificates
add-type -assembly Azure.Security.KeyVault.Secrets 
add-type -assembly Azure.Core
add-type -assembly Microsoft.Identity.Client
}

function GetCertFromAzureVault($keyVaultUri, $managedIdentityId, $certName)
{
if (IsLegacyPS)
	{
	throw "This function requires PowerShell 7 or later"
	}

try
{
	AddTypes
}
catch
	{
	throw "Unable to load assemblies"
	}
$credentialoptions = new-object Azure.Identity.DefaultAzureCredentialOptions
$credentialoptions.ManagedIdentityClientId = $ManagedIdentityId
$uri = new-object System.Uri($keyVaultUri)
$credential = new-object Azure.Identity.DefaultAzureCredential($credentialoptions)
$certclient = new-object Azure.Security.KeyVault.Certificates.CertificateClient($uri,$credential)
$cert = $certClient.GetCertificate($certName)
$cert = $cert.Value
$certWithPk = AzureGetCertWithPrivateKey $cert $credential $keyVaultUri $certName
return $certWithPk
}


function AzureGetCertWithPrivateKey($vaultCert, $credential, $keyVaultUri, $certName)
{
$secretId = $vaultCert.SecretId
$segments = $secretId.Segments
$secretName = $segments[2].Trim("/")
$secretVersion = $segments[3].TrimEnd("/")
$uri = new-object System.Uri($keyVaultUri)
$secretClient = new-object Azure.Security.KeyVault.Secrets.SecretClient($uri,$credential)
$s = $secretClient.GetSecret($secretName, $secretVersion)
$s = $s.Value
$s = $s.Value 
$privateKeyBytes = [System.Convert]::FromBase64String($s)
$cert = new-object System.Security.Cryptography.X509Certificates.X509Certificate2(,$privateKeyBytes)
return $cert
}

#### Other support functions ####

# populate server version etc. from result of calling GetConsumerInfo

function setServerInfo($res)
{
    $script:TACHYONVER = $res.Version
    $verparts = $script:TACHYONVER.split(".")
    if ($verparts.Length -eq 4)
    	{
	    $script:TACHYONMAJORVER = $verparts[0]
	    $script:TACHYONMINORVER = $verparts[1]
	    }
    $clobSize = GetClobSize
    $script:TACHYONCLOBSIZE = $clobSize
}

# TODO: this is not available yet for non-Windows environments

function getClientCerts()
{
# if using client certificate authentication (via Proxy), then find a suitable collection of certs and supply it
# currently this will be any cert with an appropriate EKU (client authentication)
# do NOT include any cert that also has the 'logon with smart card' EKU. If Windows Hello is installed, this will cause a PIN prompt if the cert is sent to an endpoint during connectivity testing
# and that will lock up the PowerShell cmdlet until the dialogue is dismissed.

$EKU = "1.3.6.1.5.5.7.3.2"
$EKUSmartCard = "1.3.6.1.4.1.311.20.2.2"
$certList = New-Object System.Collections.Generic.List[System.Object]
$certs = get-childitem -path cert:\currentuser\my
foreach ($cert in $certs)
	{
    $include = $false
	foreach ($objid in $cert.EnhancedKeyUsageList.ObjectId)
		{
		if ( $objid -eq $EKU)
			{
			$include = $true
			}
        if ($objid -eq $EKUSmartCard)
            {
            $include = $false
            break
            }
		}
    if ($include)
        {
        [void]$certList.Add($cert)
        }
 	}
# try local machine personal cert store as well

$certs = get-childitem -path cert:\localmachine\my
foreach ($cert in $certs)
	{
    $include = $false
	foreach ($objid in $cert.EnhancedKeyUsageList.ObjectId)
		{
		if ( $objid -eq $EKU)
			{
			$include = $true
			}
        if ($objid -eq $EKUSmartCard)
            {
            $include = $false
            break
            }
        }        
    if ($include)
        {
        [void]$certList.Add($cert)
        }
	}
return $certList
}

# tokenizer for human-readable schema

function getNextSchemaToken($in,[ref]$pos)
{
$p = $pos.Value
if ($null -eq $in -or $p -ge $in.Length)
    {
    return $null
    }
while (((peek $in $p) -eq " " -or (peek $in $p) -eq ",")  -and $p -lt $in.Length)
    {
    $p++
    }
if ($p -ge $in.Length)
    {
    $pos.Value = $p
    return $null
    }

if ((restofline $in $p) -match "^(int32|int64|string|double|datetime|bool|guid|clob)(\s*\(|\W+|$)") #datatype
    {
    $p += $matches[1].length
    $pos.Value = $p
    return $matches[1]
    }

if ((restofline $in $p) -match "^(\(\s*\d+\s*\))") #length
    {
    $p += $matches[1].length
    $pos.Value = $p
    return $matches[1] -replace "\(|\)|\s+", ""
    }

if ((restofline $in $p) -match "^(\w+)(\W+|$)") # identifier
    {
    $p += $matches[1].length
    $pos.Value = $p
    return $matches[1]
    }

$pos.Value = $p
return ""
}

function SchemaToJson($expr)
{
$p = 0
$tok = getNextSchemaToken $expr ([ref]$p)
if ($tok -eq "")
    {
    throw "unexpected token parsing " + $expr
    }

$schema = New-Object System.Collections.Generic.List[System.Object]
$schemaEntry = New-Object PSObject -Property @{
                Name = $tok
                Type = $null
                Length = 0
                }
while ($null -ne $tok)
    {
    $tok = getNextSchemaToken $expr ([ref]$p)
    if ($null -ne $tok)
        {
        if ($null -eq $schemaEntry.Type)
            {
            $schemaEntry.Type = $tok
            }
        else
            {
            if ($tok -match "^\d+$")
                {
                $schemaEntry.Length = $tok
                }
            else
                {
                if ($schemaEntry.Type -eq "string" -and $schemaEntry.Length -eq 0)
                    {
                    $schemaEntry.Length = 256
                    }
                if ($schemaEntry.Type -ne "string")
                    {
                    $schemaEntry.Length = 0
                    }
                $schema.Add($schemaEntry)
                $schemaEntry = New-Object PSObject -Property @{
                    Name = $tok
                    Type = $null
                    Length = 0
                    }
                }        
            }
        }
    }
if ($null -eq $schemaEntry.Type)
    {
    throw "Data type not specified for schema column"
    }
if ($schemaEntry.Type -eq "string" -and $schemaEntry.Length -eq 0)
    {
    $schemaEntry.Length = 256
    }
if ($schemaEntry.Type -ne "string")
    {
    $schemaEntry.Length = 0
    }

$schema.Add($schemaEntry)
return convertto-json $schema
}

function GetEntityParams($params, $name)
{
$outparams = New-Object System.Collections.Generic.List[System.Object]
foreach ($p in $params)
    {
        $paramSplit = $p.Name.split("?")
        $paramParent = $paramSplit[0].replace(" ","-")
        $paramName = $paramSplit[1]
        if ($paramParent.substring(0,1) -eq "-")
            {
            $paramParent = $paramParent.substring(1)
            }
        if ($paramParent -eq $name)
            {

            $v = New-Object PSObject -Property @{
                Name = $paramName
                Value = $p.Value
                }
            [void]$outparams.Add($v)
            }
    }
return $outparams
}

function BuildDynamicParams($instruction, $offset)
{
 
 $dict = new-object System.Management.Automation.RuntimeDefinedParameterDictionary
    if (IsNullOrEmpty $instruction)
        {
        throw "Instruction name must be supplied"
        }
    $m = getinstructionmetadataByName $instruction
    if ($null -ne $m)
        {
        $metadata = $m.Parameters
        if ($null -ne $m)
        {
            foreach ($p in $metadata)
                {
                AddDynamicParam $dict $p $offset
    	        }
	    }
    }
    $ret = New-Object PSObject -Property @{
                Dict = $dict
                Metadata = $metadata
                InstrId = $m.Id
                }
    return $ret
}

function TransformParamName($paramName,$name)
{
$pName = $name.Replace("-","_") + "?" + $paramName.Replace(" ","_")
if ($pName.substring(0,1).IndexOfAny("0123456789") -eq 0)
    {
    $pName = "_" + $pName
    }
return $pName
}

function findNewName($dict, $name, [ref]$index)
{
    $nameSplit = $name.split("?")
    $nameFirst = $nameSplit[0]
    if ($nameSplit.Count -gt 1)
        {
        $nameLast = $nameSplit[$nameSplit.Count - 1]
        }
    else
        {
        $nameLast = ""
        }
    $i = 1
    while ($true)
        {
        $newname = $nameFirst + "_" + $i
        if ($nameLast -ne "")
            {
            $newname = $newname + "?" + $nameLast
            }
        if ($null -eq $dict[$newname])
            {
            if ($null -ne $index)
                {
                $index.Value = $i
                }
            return $newname
            }
        $i = $i + 1
        }
}


function BuildDynamicParamsForRule($dict, $name, $ruleParams, $offset)
{
    $params = New-Object System.Collections.Generic.List[System.Object]

    # For trigger templates, we could specify the same template multiple times but with different params e.g watching for different files
    # So we check the dictionary to see if we already added it. If we did, we append a number, starting from 1 and check for collisions until we find none
    # e.g if we tried to add the param FileChange?FileName more than once it would become FileChange_1?FileName, FileChange_2?FileName etc.

    foreach ($p in $ruleParams)
        {
           $paramName = TransformParamName $p.Name $Name
           if ($null -ne $dict[$paramName])
                {
                $newName = findNewName $dict $paramName
                $p.Name = $newName
                }
           else
                {
                $p.Name = $paramName
                }
                     
           AddDynamicParam $dict $p $offset
           [void]$params.Add($p)
        }
    return $params
}


function GetParms($parms)
{
$params = New-Object System.Collections.Generic.List[System.Object]
if ($parms.Count -eq 0)
    {
     return $null
    }
if ($parms[0].GetType().Name -eq "string")
    {
    $paramsSplit = $parms[0].Split(",")
    foreach ($p in $paramsSplit)
        {
        # assume simple param list, each of which is freetext string
        $paramEntry = New-Object PSObject -Property @{
            Name = $p.Trim()
            Type = "string"
            DefaultValue = ""
            IsOptional = $false
            }
        [void]$params.Add($paramEntry)
        }
    return $params
    }
else
    {
    # just return the object we were given
    return $parms
    }
}

function GetParamDataType ($paramType)
{
$ret = switch ($paramType)
    {
    "integer" {"int"}
    "boolean" {"int"}
    default {$paramType}
    }
return $ret
}

function MapDefaultValue($param)
{
if ($param.Type -eq "boolean")
    {
    if ($param.DefaultValue -eq "true")
        {
        return 1
        }
    else
        {
        return 0
        }
    }
return $param.DefaultValue
}

function GetMethodParameters($method)
{
$dictMethods = GetMethodDictionary $METHODMETADATAFILE
$m = $dictMethods[$methodName]
if ($null -eq $m)
	{
	throw "Unable to locate metadata for method"
	}
return $m.Parameters
}

function GetNormalisedMethodName($method)
{
$dictMethods = GetMethodDictionary $METHODMETADATAFILE
$m = $dictMethods[$methodName]
if ($null -eq $m)
	{
	throw "Unable to locate metadata for method"
	}
return $m.NormalisedName
}

function GetMethodSchema($method)
{
$dictMethods = GetMethodDictionary $METHODMETADATAFILE
$m = $dictMethods[$methodName]
if ($null -eq $m)
	{
	throw "Unable to locate metadata for method"
	}
# adjust the type to match what the actual instruction will have e.g boolean -> bool, integer -> int64 etc
foreach ($entry in $m.Columns)
    {
    $entry.Type = MapSchemaType $entry.Type
    }
return $m.Columns
}


function GetMethodInfo($method)
{
$dictMethods = GetMethodDictionary $METHODMETADATAFILE
if (IsNullOrEmpty $method)
	{
	return $dictMethods
	}
$m = $dictMethods[$methodName]
if ($null -eq $m)
	{
	throw "Unable to locate metadata for method"
	}
return $m
}

function ParamToJson($parameters)
    {
    $params = New-Object System.Collections.Generic.List[System.Object]
    foreach ($p in $parameters)
        {
        $pattern = "%" + $p.Name + "%"
        if (-not (IsNullOrEmpty $p.DefaultValue))
            {
            $paramEntry = New-Object PSObject -Property @{
                Name = $p.Name
                DataType = $p.Type
                Pattern = $pattern
                ControlType = "freeText"
                DefaultValue = $p.DefaultValue
                }
            }
        else
            {
            $paramEntry = New-Object PSObject -Property @{
                Name = $p.Name
                DataType = $p.Type
                Pattern = $pattern
                ControlType = "freeText"
                }
            }

        [void]$params.Add($paramEntry)
        }
    return convertto-json $params
    }



function GetFullPath($file)
{
$path = (Get-Location -PSProvider FileSystem).ProviderPath
if ($file -match "^[A-Za-z]\:|^\\")
    {
    $filepath = $file
    }
else
    {
    $filepath = $path + "\" + $file
    }
return $filepath
}

function AddAttribute($xmlDoc,$xmlNode, $attr, $value)
{
$attr = $xmlDoc.CreateAttribute($attr)
$attr.Value = $value
[void]$xmlNode.Attributes.Append($attr)
}

function InferResourceType($path)
{
$extension = [System.IO.Path]::GetExtension($path)
$ret = switch ($extension)
    {
    ".ps1" {"PowerShell"}
    ".txt" {"Text"}
    ".cmd" {"Batch"}
    ".bat" {"Batch"}
    ".sh" {"Shell"}
    ".exe" {"Executable"}
    ".dll" {"Library"}
    ".so" {"Library"}
    default {"Unknown"}
    }
return $ret
}

function ParseSchedule($schedule)
{
if ($schedule -match "^Once$")
    {
    $ret = New-Object PSObject -Property @{
                ScheduleFreqType = 1
                ScheduleFreqInterval = 0
                ScheduleFreqSubdayType = 0
                ScheduleFreqSubdayInterval = 0
                ScheduleFreqRecurrenceFactor = 0
                }
    return $ret
    }

if ($schedule -match "^Daily$")
    {
        $ret = New-Object PSObject -Property @{
                ScheduleFreqType = 4
                ScheduleFreqInterval = 1
                ScheduleFreqSubdayType = 1
                ScheduleFreqSubdayInterval = 0
                ScheduleFreqRecurrenceFactor = 0
                }
    return $ret

    }

if ($schedule -match "^Hourly$")
    {
        $ret = New-Object PSObject -Property @{
                ScheduleFreqType = 4
                ScheduleFreqInterval = 1
                ScheduleFreqSubdayType = 8
                ScheduleFreqSubdayInterval = 1
                ScheduleFreqRecurrenceFactor = 0
                }
    return $ret

    }

if ($schedule -match "^Weekly$|^Weekly\s+on\s+day\s+(\d)$")
    {
    if ($null -eq $matches[1])
            {
            $weekDay = 1
            }
        else
            {
            $weekDay = [int]$matches[1]
            }
        if ($weekDay -lt 1 -or $weekDay -gt 7)
            {
            throw "Week day must be between 1 and 7"
            }
    $ret = New-Object PSObject -Property @{
                ScheduleFreqType = 8
                ScheduleFreqInterval = [math]::Pow(2,$weekDay - 1)
                ScheduleFreqSubdayType = 0
                ScheduleFreqSubdayInterval = 0
                ScheduleFreqRecurrenceFactor = 1
                }
    return $ret
    }

if ($schedule -match "^Monthly$|^Monthly\s+on\s+day\s+(\d|\d\d)$")
    {
        if ($null -eq $matches[1])
            {
            $monthDay = 1
            }
        else
            {
            $monthDay = [int]$matches[1]
            }
        if ($monthDay -lt 1 -or $monthDay -gt 31)
            {
            throw "Month day must be between 1 and 31"
            }

        $ret = New-Object PSObject -Property @{
                ScheduleFreqType = 16
                ScheduleFreqInterval = $monthDay
                ScheduleFreqSubdayType = 0
                ScheduleFreqSubdayInterval = 0
                ScheduleFreqRecurrenceFactor = 1
                }
    return $ret

    }

if ($schedule -match "^(?:Every\s+)?(\d|\d\d)\s+(?:Mins|Minutes)$")
    {
        $mins = [int]$matches[1]
        if ($mins -lt 10 -or $mins -gt 60)
            {
            throw "mins must be between 10 and 60"
            }

        $ret = New-Object PSObject -Property @{
                ScheduleFreqType = 4
                ScheduleFreqInterval = 1
                ScheduleFreqSubdayType = 4
                ScheduleFreqSubdayInterval = $mins
                ScheduleFreqRecurrenceFactor = 0
                }
    return $ret

    }

throw "Schedule is not valid"


}

function GetCopyScale($resourceVar, $destPath)
{
$s = @"
@cmdLine = select "cmd /c if not exist \"$($destPath)\" mkdir \"$($destPath)\"";
NativeServices.RunCommand(CommandLine: @cmdLine);
@cmdLine = select "cmd /c copy " || "\"" || (select FilePath from @$($resourceVar)) || "\"" || " /y \"$($destPath)\"";
NativeServices.RunCommand(CommandLine: @cmdLine);
"@
return $s
}

function GetExecuteScale($resourceVar, $resourceType, $splitLines, $interpretAsJson, $overridePolicy, $params)
{
if ($splitLines)
    {
    $splitFlag = "true"
    }
else
    {
    $splitFlag = "false"
    }

if ($interpretAsJson)
    {
    $jsonFlag = "true"
    }
else
    {
    $jsonFlag = "false"
    }

if ($overridePolicy)
    {
    $policy = ', ExecutionPolicy: "Override"'
    }
else
    {
    $policy = ""
    }

$paramString = ""


if ($resourceType -eq "Executable")
    {
    foreach ($param in $params)
        {
        $paramString += " " + $param
        }
    if ($paramString -ne "")
        {
        $paramString = '|| " " || "' + $params + '"'
        }
    $exe = @"
@$($resourceVar)CmdLine = select FilePath $($paramString) from @$($resourceVar);
@$($ResourceVar)Result = NativeServices.RunCommand(CommandLine: @$($resourceVar)CmdLine, SplitLines: $($splitFlag), InterpretAsJson: $($jsonFlag) );
"@
    return $exe
    }

if ($resourceType -eq "PowerShell")
    {
    $notfirst = $false
    foreach ($param in $params)
        {
        if ($notfirst)
            {
            $paramString += ',"' + $param + '"'
            }
        else
            {
            $paramString = '"' +  $param + '"'
            $notfirst = $true
            }
        }

    if ($paramString -ne "")
        {
        $paramString = "," + $paramString
        }
    $exe = @"
@$($ResourceVar)Result = Scripting.Run(Language: "PowerShell" $($policy), ScriptPath: @$($ResourceVar), InterpretAsJson: $($jsonFlag) $($paramString) );
"@
    return $exe
    }

}

function escQuote($s)
{
return $s.Replace('"',"&quot;")
}
function getRuleType($t)
{
if ($t -eq 1)
    {
    return "Check"
    }
else
    {
    return "Fix"
    }
}

function GetTempDir ()
{
    $parent = [System.IO.Path]::GetTempPath()
    $name = [System.IO.Path]::GetRandomFileName()
    return New-Item -ItemType Directory -Path (Join-Path $parent $name)
}

function rulePayloadToXml($payloadType, $name, $params)
{
$p = "<" + $payloadType + ' Template="' + $name + '">'


if ($params.Count -gt 0)
    {
    $p += "<Parameters>"
    foreach ($param in $params)
        {
        if (-not (IsNullOrEmpty $param.Value))
            {
            $val = $param.Value
            }
        else
            {
            $val = $param.DefaultValue
            }
        $p += '<Parameter Name="' + $param.Name + '" Value="' + $val +'"/>'
        }
    $p += "</Parameters>"
    }

$p += "</" + $payloadType + ">"
return $p
}

function ruleToXml($ruleJson)
{
$template = @"
<?xml version="1.0" encoding="UTF-8"?>
<Rule Name="{Name}" Description="{Description}" Type="{Type}" >
{Precondition}
{Check}
{Fix}
  <Triggers>
    {Triggers}
  </Triggers>
</Rule>
"@

$template = $template.Replace("{Name}",$ruleJson.Name)
$template = $template.Replace("{Description}",$ruleJson.Description)
$template = $template.Replace("{Type}",(getRuleType $ruleJson.Type))
$s = ""
if (-not (IsNullOrEmpty $ruleJson.PreConditionPayload))
    {
    $s = rulePayloadToXml "PreCondition" $ruleJson.PreconditionFragment.Name $ruleJson.PreconditionParameters
    }
$template = $template.Replace("{Precondition}",$s)

$s = ""
if (-not (IsNullOrEmpty $ruleJson.CheckPayload))
    {
    $s = rulePayloadToXml "Check" $ruleJson.CheckFragment.Name $ruleJson.CheckParameters
    }
$template = $template.Replace("{Check}",$s)

$s = ""
if (-not (IsNullOrEmpty $ruleJson.FixPayload))
    {
    $s = rulePayloadToXml "Fix" $ruleJson.FixFragment.Name $ruleJson.FixParameters
    }
$template = $template.Replace("{Fix}",$s)

$tr = ""
foreach ($trigger in $ruleJson.Triggers)
    {
    $t = get-triggertemplate -id ($trigger.TriggerTemplateId)
    $tr += '<Trigger Template="' + $t.Name + '">'
    $tr += '<Parameters>'
 
    foreach ($param in $trigger.UserParameters)
        {
        $tr += '<Parameter Name="' + $param.Name + '" Value="' + $param.Value + '"/>'
        }
    $tr += '</Parameters>'
    $tr += '</Trigger>'
    }
$template = $template.Replace("{Triggers}",$tr)
return $template
}

function PolicyToXml($policyJson)
{
$template = @"
<?xml version="1.0" encoding="UTF-8"?>
<Policy Name="{Name}" Description="{Description}">
  <Rules>
  {Rules}
  </Rules>
</Policy>
"@
$template = $template.Replace("{Name}",$policyJson.Name)
$template = $template.Replace("{Description}",(escQuote $policyJson.Description))
$r = ""
foreach ($rule in $policyJson.Rules)
    {
    $r += '<Rule Name="' + $rule.Name + '"/>'
    }
$template = $template.Replace("{Rules}",$r)
return $template
}

function TriggerTemplateToXml($templateJson)

{
$template = @"
<?xml version="1.0" encoding="UTF-8"?>
<TriggerTemplate Name="{Name}" Category="{Category}" Description="{Description}" Type="{Type}" ReadablePayload="{ReadablePayload}">
  <AgentParameters>
    {AgentParameterJson}
  </AgentParameters>
  <UserParameterJson><![CDATA[{UserParameters}]]></UserParameterJson>
</TriggerTemplate>
"@
$template = $template.Replace("{Name}",$templateJson.Name)
$template = $template.Replace("{Category}",$templateJson.Category)
$template = $template.Replace("{Description}",$templateJson.Description)
$template = $template.Replace("{Type}",$templateJson.Type)
$template = $template.Replace("{ReadablePayload}",(escQuote $templateJson.ReadablePayload))
$template = $template.Replace("{UserParameters}",(convertto-json $templateJson.UserParameters -Depth 99))
$p=""
if (-not (IsNullOrEmpty $templateJson.AgentParameterJson))
	{
	$params = convertfrom-json $templateJson.AgentParameterJson
	foreach ($parm in $params)
	    {
	    foreach ($prop in (Get-Member -InputObject $parm -MemberType NoteProperty))
	        {
	        $p += '<Parameter Name="' + $prop.Name + '" Value="' + $parm.($prop.Name) + '"/>'
	        }
	    }
	}
$template = $template.Replace("{AgentParameterJson}",$p)
return $template
}

function ManifestToXml($name, $description, $icon)
{
$template = @"
<?xml version="1.0" encoding="utf-8"?>
<Manifest version="2">
  <Name>{Name}</Name>
  <Description>{Description}</Description>
  <Icon>{Icon}</Icon>
</Manifest>
"@
$template = $template.Replace("{Name}",$Name)
$template = $template.Replace("{Description}",$Description)
$template = $template.Replace("{Icon}",$Icon)
return $template
}

function CreateResource($xmlDoc, $xmlns, $resourcePath, $name)
{
$bytes = [System.IO.File]::ReadAllBytes($resourcePath)
$base64 = [Convert]::ToBase64String($bytes)
$hash = (get-filehash $resourcePath).hash.ToLower()
$length = $bytes.Count
$resNode = $xml.CreateNode("element","Resource",$xmlns)
AddAttribute $xml $resNode "Name" $name
$contentNode = $xml.CreateNode("element","Content",$xmlns)
$resourceType = InferResourceType $resourcePath
AddAttribute $xml $contentNode "Type" $resourceType
$baseName = split-path -Path $resourcePath -Leaf
AddAttribute $xml $contentNode "FileName" $baseName
AddAttribute $xml $contentNode "Size" $length
AddAttribute $xml $contentNode "Platform" "Windows" # TODO: sort this out later
AddAttribute $xml $contentNode "Hash" $hash
$cdata = $xml.CreateCdataSection($base64)
[void]$contentNode.AppendChild($cdata)
[void]$resNode.AppendChild($contentNode)
return $resNode
}

function CreateInstructionXml($name, $readablePayload,$description, $insttype,$version, $content, $schema, $resources, $parameters, $DataSource, $RowSourceType)
{
# don't use IsNullOrEmpty as an array of one param is returned true also allow empty string to solve problem of not being able to place fill with $null when calling functions
if ($parameters -eq "")
    {
    $parameters = $null
    }

if ($resources -eq "")
    {
    $resources = $null
    }

if ($null -ne $parameters)
    {
        foreach ($p in $parameters)
        {
        $patt = "%" + $p.Name + "%"
        $readablePayload += " " + $p.Name + ":" + $patt
        }
    }

[xml]$xml = new-object system.xml.xmldocument
$xmldec = $xml.CreateXmlDeclaration("1.0","UTF-8",$null)
$xmldec.Standalone = "yes"
[void]$xml.AppendChild($xmldec)
$xmlns="http://schemas.1e.com/Tachyon/InstructionDefinition/1.0"
$instr = $xml.CreateNode("element","InstructionDefinition",$xmlns)
AddAttribute $xml $instr "Author" $env:USERNAME
AddAttribute $xml $instr "Name" $name
AddAttribute $xml $instr "ReadablePayload" $readablePayload
AddAttribute $xml $instr "Description" $description
AddAttribute $xml $instr "InstructionType" $insttype
AddAttribute $xml $instr "InstructionTtlMinutes" "10"
AddAttribute $xml $instr "ResponseTtlMinutes" "10"
AddAttribute $xml $instr "Version" $version
if (-not (IsNullOrEmpty $DataSource))
    {
    AddAttribute $xml $instr "DataSource" $DataSource
    }

if (-not (IsNullOrEmpty $RowSourceType))
    {
    AddAttribute $xml $instr "RowSourceType" $RowSourceType
    }

[void]$xml.AppendChild($instr)
$payload = $xml.CreateNode("element","Payload",$xmlns)
$cdata = $xml.CreateCdataSection($content)
[void]$payload.AppendChild($cdata)
[void]$xml.InstructionDefinition.AppendChild($payload)
$schemaJson = $xml.CreateNode("element","SchemaJson",$xmlns)
$jsonSchema = SchemaToJson $schema
$cdata = $xml.CreateCdataSection($jsonSchema)
[void]$schemaJson.AppendChild($cdata)

[void]$xml.InstructionDefinition.AppendChild($schemaJson)

if ($null -ne $parameters)
    {
    $paramJson = $xml.CreateNode("element","ParameterJson",$xmlns)
    $jsonParam = ParamToJson $parameters
    $cdata = $xml.CreateCdataSection($jsonParam)
    [void]$paramJson.AppendChild($cdata)
    [void]$xml.InstructionDefinition.AppendChild($paramJson)
    }

if ($resources.Count -gt 0)
    {
    $resourcesNode = $xml.CreateNode("element","Resources",$xmlns)
    $i = 1
    foreach ($resource in $resources)
        {
            $resName = "Resource" + $i
            $resNode = CreateResource $xml $xmlns $resource $resName
            [void]$resourcesNode.AppendChild($resNode)
            $i++
        }
    [void]$xml.InstructionDefinition.AppendChild($resourcesNode)
    }
return $xml
}

function MapSchemaType($in)
{
$ret = switch ($in)
    {
    "integer" {"int64"}
    "boolean" {"bool"}
    default {$in}
    }
return $ret
}

function GetMethodDictionary($file)
{
$filepath = $PSScriptRoot + "\" + $file
$r = get-content $filePath | convertfrom-json
$dictMethods = @{}
foreach ($namespace in $r)
    {
    foreach ($method in $namespace.Methods)
	    {
        $key = $namespace.Name + "." + $method.Name
        add-member -MemberType NoteProperty -Name "NormalisedName" -Value $Key -inputobject $method
	    $dictMethods[$key] = $method
	    }
    }
return $dictMethods
}

function CreateInstructionForMethod($methodName, $includeAllParams, $optionalParams)
{
$methodParams = Get-MethodParameter -MethodName $methodName
$methodName = GetNormalisedMethodName $methodName
$scale = $methodName + "("
$notfirst = $false
$paramDict = @{}
if ($null -ne $optionalParams)
    {
    $optParams = $optionalParams.Split(",")
    foreach ($optParam in $optParams)
        {
        $paramDict[$optParam] = $optParam
        }
    }

$instParams = New-Object System.Collections.Generic.List[System.Object]
foreach ($p in $methodParams)
	{
	if ((-not $p.IsOptional)-or $includeAllParams -or ($paramDict.Count -gt 0 -and $paramDict.ContainsKey($p.Name)))
		{
        [void]$instParams.add($p)
        $pattern = "%" + $p.Name + "%"
        if ($notfirst)
            {
            $scale += ","
            }
        else
            {
            $notfirst = $true
            }
		if ($p.Type -eq "string")
			{
			$scale += " " + $p.Name + ": " +'"' + $pattern + '"'
			}
		else
			{
			$scale += " " + $p.Name + ": " + $pattern
			}
		}
   
	}

$scale += ");"

$schema = Get-MethodSchema $methodName -AsText
$instName = $INSTPREFIX + "-" + $methodName
$instFile = $instName + ".xml"
$payload = "Scale: " + $methodName

return new-instructionxml -name $instname -path $instFile -readablepayload $payload -Content $scale -Schema $schema -Parameters $instParams
}

function IsServerSideInstruction($instr)
{
if ($null -eq $instr)
    {
    return $false
    }
if ($null -ne $instr.DataSource -and $instr.DataSource.ToLower() -ne "1e.tachyon.client.scale")
    {
    return $true
    }
return $false
}

function GetBasicAuth()
{
# retrieve credentials from script global (set by set-server cmdlet)

if ($null -ne $script:CREDENTIAL)
    {
    $user = $script:CREDENTIAL.UserName
    $pass = $script:CREDENTIAL.GetNetworkCredential().Password
    }
else
    {
    throw "Unable to retrieve credentials for basic authentication"
    }

$pair = "$($user):$($pass)"
$encodedCreds = ToBase64 $pair
$basicAuthValue = "Basic $encodedCreds"
return $basicAuthValue
}

function ToBase64($s)
{
return [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($s))
}

function FromBase64($s)
{
try
    {
    return [Text.Encoding]::Utf8.GetString([Convert]::FromBase64String($s))
    }
catch
    {
    return ""
    }
}


function getThumbprint($thumbprint)
{
   
$tp = $thumbprint -split '(..)'
$buf = @()
foreach ($octet in $tp)
    {
    if ($octet -ne "")
        {
        $byte = [Convert]::ToInt32($octet,16)
        $buf += $byte
        }
    }
return ToBase64Url $buf
}
   
 
function ToBase64Url($buf)
{
$base64buf = [System.Convert]::ToBase64String($buf)
$base64buf = $base64buf.replace("=","")
$base64buf = $base64buf.replace("+","-")
$base64buf = $base64buf.replace('/',"_")
return $base64buf
}

function ToBase64UrlString($buf)
{
$bufBytes = [System.Text.Encoding]::UTF8.GetBytes($buf)
return ToBase64url $bufBytes
}

function FromBase64Url($base64buf)
{
if ($base64buf.Length % 4 -ne 0)
	{
	$base64buf = $base64buf + ("=" * (4 - $base64buf.Length % 4))
	}

$base64buf = $base64buf.replace("-","+")
$base64buf = $base64buf.replace('_',"/") #this was incorrectly a backslash, but note this routine is only used for diagnostic purposes currently
return (FromBase64 $base64buf)
}


# note the reversed comparisons to avoid PS typecasting issues. returns true for an empty string or a null object
# Note - currently this returns true for an object array with one entry

function IsNullOrEmpty($thing)
{
if ($null -eq $thing)
    {
    return $true
    }
if ("" -eq $thing -and $thing.count -eq 1)
    {
    return $true
    }
return $false
}

# given an instruction name and a scope (i.e device match pattern, currently), get the metadata for the instruction and prompt for params then run



function GetSid($account)
	{
	$adObj = new-object system.security.principal.ntaccount($account)
	try
		{
		$a = $adObj.Translate([System.Security.Principal.SecurityIdentifier])
		}
	catch
		{
		return $null
		}
	return $a.value
	}

function AddDynamicParam($dict,  $metadataEntry, $offset)
{
    # some params can have embedded spaces; replace with underscore
    $name = $metadataEntry.Name.Replace(" ","_")
	$a = new-object System.Management.Automation.ParameterAttribute
	$a.Position =$dict.Count + $offset

    if (IsNullOrEmpty $metadataEntry.DefaultValue)
        {
    	$a.Mandatory = $true
        }
    else
        {
        $a.Mandatory = $false
        }

	$coll = new-object System.Collections.ObjectModel.Collection[System.Attribute]
	$coll.add($a)
    if ($metadataEntry.DataType -eq "int")
        {
        $ap = new-object System.Management.Automation.RuntimeDefinedParameter($name,[int], $coll)
        }
    else
        {
        if ($metadataEntry.DataType -eq "float")
            {
	        $ap = new-object System.Management.Automation.RuntimeDefinedParameter($name,[double], $coll)
            }
        else
            {
            $ap = new-object System.Management.Automation.RuntimeDefinedParameter($name,[string], $coll)
            }
        }

        if ($metadataEntry.ControlType -eq "valuePicker")
            {
            $arrset=@()
            foreach ($v in $metadataEntry.Validation.AllowedValues)
                {
                $arrset += $v
                }
            $validateSet = new-object System.Management.Automation.ValidateSetAttribute($arrset)
            $coll.add($validateSet)
            }


        if (-not (IsNullOrEmpty $metadataEntry.DefaultValue))
            {
            $ap.Value = $metadataEntry.DefaultValue
            }
	$dict.add($name,$ap)
}

function UploadInstructionToSetId($content, $id)
{
$addhdrs = @{"Content-Type" ="multipart/form-data; boundary=xyzzy"}
$res = PostHttpRequest ("/consumer/ProductPacks/InstructionSet/Id/" + $Id)  $content $addhdrs
return $res
}


function UploadFragment($content)
{
$addhdrs = @{"Content-Type" ="multipart/form-data; boundary=xyzzy"}
$res = PostHttpRequest "/consumer/Fragments/UploadFile"  $content $addhdrs
return $res
}

function GetDeviceInfo($fqdn)
{
$fqdn = ToBase64 $fqdn
$url= "/consumer/devices/fqdn/" + $fqdn
$res = GetHttpRequest $url
return $res
}


function GetConsumerInfo()
{
$url = "/consumer/information"
$res = GetHttpRequest $url
return $res
}

function GetProxyInfo()
{
$url = "/Home/Info"
$res = GetHttpRequest $url
# the auth testbed behaves like the proxy with the same endpoint but we throw so that the set-server cmdlet doesn't mistakenly think it's using the proxy
if ($res.Info.Contains("Testbed"))
    {
    throw "Connected to auth testbed, not proxy"
    }
return $res
}

function IsConnectedToProxy()
{
try
    {
    $res = GetProxyInfo
    return $true
    }
catch
    {
    return $false
    }
}


function GetClobSize()
{
$url = "/consumer/settings/ClobDefaultReadSize"
$res = GetHttpRequest $url
return $res
}

# this is used for running OSQuery, WMI and activity queries where the raw JSON is returned from an instruction with a single CLOB output column, which we then parse and return
# namespace only used for WMI queries

function RunQuery($instruction, $query,$targetscope,$targetfqdns, $namespace)
{

$arguments = @{}

if ($targetscope -ne "")
	{
	$arguments.Add("TargetScope",$TargetScope)
	}

if ($null -ne $TargetFqdns)
	{
	$arguments.Add("TargetFqdns",$TargetFqdns)
	}

if ($null -ne $namespace)
	{
	$arguments.Add("Namespace",$namespace)
	}

		
     $r = invoke-instruction $instruction -query $query @arguments
     $valueSet = @{}
     foreach ($key in $r.Keys)
        {
        $res = $r[$key].Output
        [Collections.Generic.List[System.Object]]$json = $res | convertfrom-json 
        $valueSet[$key] = $json
        }
     return $valueSet
}


function AddHeaders($hdr, $addhdr)
{
$out = $hdr
foreach ($h in $addhdr.Keys)
	{
	$out[$h] =$addhdr[$h]
	}
return $out
}

function GetHeaders()
{
if ($USEPROXY)
	{
        if (-not (IsNullOrEmpty $script:PROXYAPITOKEN))
            {
            $Headers = @{
 	            Accept = "application/json"
        	    "Content-type" = "application/json"
	            "X-Tachyon-Consumer" = $script:TACHYONCONSUMER
		        "X-Access-Token" = $script:PROXYAPITOKEN	
            	}
            }
        else
            {
            $Headers = @{
 	            Accept = "application/json"
        	    "Content-type" = "application/json"
	            "X-Tachyon-Consumer" = $script:TACHYONCONSUMER
            	}
            }
	return $Headers
	}
if (HaveValidToken)
    {
	$tokenType = $script:AUTHTOKEN.TokenType
	if ($tokenType -eq 2)
		{
		$authHdr = "X-Tachyon-PlatformAuthenticate"
		}
	else
		{
		$authHdr = "X-Tachyon-Authenticate"
		}
        $Headers = @{
        Accept = "application/json"
        "Content-type" = "application/json"
        "X-Tachyon-Consumer" = $script:TACHYONCONSUMER
        "$($authHdr)" = (GetOrUpdateToken $script:AUTHTOKEN).Token
    }
    return $Headers
    }

if ($USEBASICAUTH)
    {
        $Headers = @{
        Authorization = GetBasicAuth
        Accept = "application/json"
        "Content-type" = "application/json"
        "X-Tachyon-Consumer" = $script:TACHYONCONSUMER
	    }
    }
    else
    {
        $Headers = @{
        Accept = "application/json"
        "Content-type" = "application/json"
        "X-Tachyon-Consumer" = $script:TACHYONCONSUMER
	    }
    }

return $Headers
}

function CreateUrl($url)
{
if ($TACHYONURL -ne "")
	{
	$fullUrl= "https://" + $TACHYONURL + $url
	return $fullUrl
	}
throw "Platform Server has not been defined. Use Set-${CMDPREFIX}Server to define it"
}

function 1ePostHttpRequest
{
param(

    [Parameter(Mandatory=$true, HelpMessage="URI of API Example: /admin/ManagementGroupsEx")]
    [string] $Url,
    [Parameter(Mandatory=$true, HelpMessage="JSON Post Body")]
    [string] $payload,
    [Parameter(Mandatory=$false, HelpMessage="Optional Headers")]
    [string] $addhdrs = $null

 )

    return DoHttpRequest $url "POST" $payload $addhdrs
}

function 1ePutHttpRequest
{
param(

    [Parameter(Mandatory=$true, HelpMessage="URI of API Example: /admin/ManagementGroupsEx")]
    [string] $Url,
    [Parameter(Mandatory=$true, HelpMessage="JSON Post Body")]
    [string] $payload,
    [Parameter(Mandatory=$false, HelpMessage="Optional Headers")]
    [string] $addhdrs = $null

 )

    return DoHttpRequest $url "PUT" $payload $addhdrs
}


function PostHttpRequest($Url, $payload, $addhdrs)
{
return DoHttpRequest $url "POST" $payload $addhdrs
}

function DoHttpRequest($Url, $verb, $payload, $addhdrs)
{
$fullurl= CreateUrl $Url
$hdrs = GetHeaders
if ($null -ne $addhdrs)
	{
	$hdrs = (AddHeaders $hdrs $addhdrs)
	}
try
	{
    if ($USEBASICAUTH -or $USEPROXY -or (HaveValidToken))
        {
        # connecting via basic auth, via proxy or via modern auth
        if (-not (IsNullOrEmpty $CLIENTCERT))
            {
	            if (IsNullOrEmpty $payload)
		        {
		        $res = Invoke-RestMethod -Method $verb -Uri $fullurl -Header $hdrs -Certificate $CLIENTCERT
		        }
	            else
		        {
	            $res = Invoke-RestMethod -Method $verb -Uri $fullurl -Header $hdrs -Body $payload -Certificate $CLIENTCERT
		        }
            }
        else
            {
            # proxy now supports NTLM inbound as well
            if ($script:PROXYVIANTLM)
                {
                if (IsNullOrEmpty $script:CREDENTIAL)
                    {
                    if (IsNullOrEmpty $payload)
	        	        {
		                $res = Invoke-RestMethod -Method $verb -Uri $fullurl -Header $hdrs -UseDefaultCredentials
		                }
                    else
		                {
	                    $res = Invoke-RestMethod -Method $verb -Uri $fullurl -Header $hdrs -Body $payload -UseDefaultCredentials
		                }
                    }
                else
                    {
                    if (IsNullOrEmpty $payload)
	        	        {
		                $res = Invoke-RestMethod -Method $verb -Uri $fullurl -Header $hdrs -Credential $script:CREDENTIAL
		                }
                    else
		                {
	                    $res = Invoke-RestMethod -Method $verb -Uri $fullurl -Header $hdrs  -Body $payload -Credential $script:CREDENTIAL
		                }
                    }
                }
            else
                {
    	        if (IsNullOrEmpty $payload)
	        	    {
		            $res = Invoke-RestMethod -Method $verb -Uri $fullurl -Header $hdrs
		            }
                else
		            {
	                $res = Invoke-RestMethod -Method $verb -Uri $fullurl -Header $hdrs  -Body $payload
		            }
                }
            }
        }
    else
        {
        # direct legacy connection using NTLM auth
        if (IsNullOrEmpty $script:CREDENTIAL)
            {
		    if (IsNullOrEmpty $payload)
		        {
		        $res = Invoke-RestMethod -Method $verb -Uri $fullurl -Header $hdrs -UseDefaultCredentials
		        }
	        else
		        {
	            $res = Invoke-RestMethod -Method $verb -Uri $fullurl -Header $hdrs -UseDefaultCredentials -Body $payload
		        }
            }
        else
            {
	        if (IsNullOrEmpty $payload)
		        {
		        $res = Invoke-RestMethod -Method $verb -Uri $fullurl -Header $hdrs -Credential $script:CREDENTIAL
		        }
	        else
		        {
	            $res = Invoke-RestMethod -Method $verb -Uri $fullurl -Header $hdrs -Credential $script:CREDENTIAL -Body $payload
		        }
            }
        }

	return $res
	}
catch
	{
    throw
	}
}

function PostHttpRequestRaw($Url, $payload, $addhdrs)
{
$fullurl= CreateUrl $Url
$hdrs = GetHeaders
if ($null -ne $addhdrs)
	{
	$hdrs = (AddHeaders $hdrs $addhdrs)
	}
try
	{
    if ($USEBASICAUTH -or $USEPROXY -or (HaveValidToken))
        {
        if (-not (IsNullOrEmpty $CLIENTCERT))
            {
            $res = Invoke-WebRequest -Method POST -Uri $fullurl -Header $hdrs  -Body $payload -UseBasicParsing -Certificate $CLIENTCERT
            }
        else
            {
            # proxy now supports NTLM inbound as well
            if ($script:PROXYVIANTLM)
                {
                if (IsNullOrEmpty $script:CREDENTIAL)
                    {
                    $res = Invoke-WebRequest -Method POST -Uri $fullurl -Header $hdrs -UseDefaultCredentials -Body $payload -UseBasicParsing
                    }
                else
                    {
                    $res = Invoke-WebRequest -Method POST -Uri $fullurl -Header $hdrs -Credential $script:CREDENTIAL -Body $payload -UseBasicParsing
                    }
                }
            else
                {
                $res = Invoke-WebRequest -Method POST -Uri $fullurl -Header $hdrs  -Body $payload -UseBasicParsing
                }
            }
        }
    else
        {
         if (IsNullOrEmpty $script:CREDENTIAL)
            {
            $res = Invoke-WebRequest -Method POST -Uri $fullurl -Header $hdrs -UseDefaultCredentials -Body $payload -UseBasicParsing
            }
        else
            {
            $res = Invoke-WebRequest -Method POST -Uri $fullurl -Header $hdrs -Credential $script:CREDENTIAL -Body $payload -UseBasicParsing
            }
        }

	return $res
	}
catch
	{
    throw
	}
}

function 1eGetHttpRequest
{
    param(

        [Parameter(Mandatory=$true, HelpMessage="URI of API Example: /consumer/devices")]
        [string] $Url


     )
    return DoHttpRequest $url "GET"
}

function GetHttpRequest($Url)
{
return DoHttpRequest $url "GET"
}

function GetHttpRequestExternal($url)
{
# just a GET call to some external non-authenticated internet resource
$res = Invoke-RestMethod -Method GET -Uri $url -ErrorAction SilentlyContinue 
return $res
}

function PostHttpRequestExternal($url, $payload, $addhdrs)
{
# just a POST call to some external non-authenticated internet resource

$hdrs = @{}
if ($null -ne $addhdrs)
	{
	$hdrs = (AddHeaders $hdrs $addhdrs)
	}
$res = Invoke-RestMethod -Method POST -Uri $url -Header $hdrs -Body $payload -ErrorAction SilentlyContinue 
return $res
}

function GetHttpRequestRaw($Url)
{
$fullurl= CreateUrl $Url

try
	{
    if ($USEBASICAUTH -or $USEPROXY -or (HaveValidToken))
        {
        if (-not (IsNullOrEmpty $CLIENTCERT))
            {
            $res = Invoke-WebRequest -Method GET -Uri $fullurl -Header (GetHeaders) -ErrorAction SilentlyContinue -Certificate $CLIENTCERT
            }
        else
            {
            # Proxy now supports NTLM inbound as well
            if ($script:PROXYVIANTLM)
                {
                if (IsNullOrEmpty $script:CREDENTIAL)
                    {
                    $res = Invoke-WebRequest -Method GET -Uri $fullurl -Header (GetHeaders) -UseDefaultCredentials -ErrorAction SilentlyContinue
                    }
                else
                    {
                    $res = Invoke-WebRequest -Method GET -Uri $fullurl -Header (GetHeaders) -Credential $script:CREDENTIAL -ErrorAction SilentlyContinue 
                    }
                }
            else
                {
                $res = Invoke-WebRequest -Method GET -Uri $fullurl -Header (GetHeaders) -ErrorAction SilentlyContinue
                }
            }
        }
    else
        {
	    if (IsNullOrEmpty $script:CREDENTIAL)
            {
	        $res = Invoke-WebRequest -Method GET -Uri $fullurl -Header (GetHeaders) -UseDefaultCredentials -ErrorAction SilentlyContinue 
            }
        else
            {
            $res = Invoke-WebRequest -Method GET -Uri $fullurl -Header (GetHeaders) -Credential $script:CREDENTIAL -ErrorAction SilentlyContinue 
            }
# -Proxy 'http://127.0.0.1:8888' 
        }
    
    return $res
	}
catch
	{
    throw
	}
}



function DeleteHttpRequest($Url, $payload)
{
return DoHttpRequest $url "DELETE" $payload
}

function PutHttpRequest($Url, $payload)
{
return DoHttpRequest $url "PUT" $payload
}

# for APIs which return paged results, if the result count exceeds the original page size, refetch as a single page with the specified result count
# This is a pragmatic compromise, because otherwise you would have to assemble pages into a list of lists and flatten them all out, which is arguably
# less efficient than just assuming a pragmatic page size (say, 2000) and then re-fetching everything in the rare case where there are more results than expected

function PostHttpRequestPaged($url,$payload)
{
    $ret = PostHttpRequest $url $payload

    if ((IsNullOrEmpty $ret) -or ($ret.Items.Count -eq $ret.TotalCount))
        {
        return $ret
        }
    else
        {
        $payload = @"
                {
                "Start": 1,
                "PageSize": $($ret.TotalCount)
                }
"@
        $ret = PostHttpRequest $url $payload
        return $ret
        }
}

function quotifyOrNull($s)
{
try
    {
    $ret = quotify $s
    return $ret
    }

catch
    {
    if ($null -eq $s)
        {
        return "null"
        }
    }
return ""
}

function ValOrNull($s,$default)
{
    if ($null -eq $s)
        {
        if ($null -eq $default)
            {
            return "null"
            }
        return $default            
        }
return $s
}

function quotify($s, $dataType)
{
$value = $s
if ($value -eq "True")
    {
    $value = "true"
    }
else
    {
    if ($value -eq "False")
        {
        $value = "false"
        }
    }
$value = $value.Replace("\", "\\") # escape backslash
if ($dataType -eq "string" -or $dataType -eq "" -or $null -eq $dataType)
    {
    $q =  '"' + $value + '"'
    }
else
    {
    $q = $value
    }
return $q
}

function GetClobValue($instrId, $response, $colname)
{
$shardId = $response.ShardId
$responseId = $response.Id

$fullUrl = "/consumer/responses/" + $instrId + "/Shard/" + $shardId + "/Row/" + $responseId + "/Column/" + $colname
$res = GetHttpRequest $fullUrl 
if ([string]$res.ErrorCode -ne "")
    {
	return ""
	}
return $res.Value
}

function GetRangeFromString($s)
{
    try
    {
    $s -match '"Range".*?:"(.*?)"' | out-null
	return $matches[1]
    }
    catch
        {
        return "0;0"
        }
}

function GetNextPagePayload($filter, $nextRange)
{
$PAGESIZE = 2000
if (IsNullOrEmpty $filter)
    {
    $payload = @"
	    {
        "PageSize":$($PAGESIZE),
        "Start":$(quotify $nextRange.Value)
        }
"@
    }
  else
    {
        $payload = @"
	    {
        "PageSize":$($PAGESIZE),
        "Start":$(quotify $nextRange.Value),
        "Filter": $($filter)
        }
"@
    }
    return $payload
}

function IsFailedStatus($status)
{
if ($status -eq "Rejected" -or $status -eq "Expired" -or $status -eq "Failed" -or $status -eq "Suspended")
	{
	return $true
	}
else
	{
	return $false
	}
}

function FormatRange($range)
{
return $range + "(" + (FromBase64 $range) + ")"
}

function FetchNextPageOfResults($url, $id, [ref]$nextRange, $valueSet,  $clobCols, $filter)
{

  if ($url.Contains($ERRORURLSUBSTRING))
    {
    $errorResults = $true
    }
  else
    {
    $errorResults = $false
    }
  
  $MAXRETRIES = 200
  $payload = GetNextPagePayload $filter $nextRange
  

$retryCount = 0
$range = $null
$fullUrl = $url + $id

$instrStatus = get-instructionstatus $id
if (IsFailedStatus $instrStatus)
	{
	throw "Instruction has not executed successfully or has expired: Status = " + $instrStatus
	}

while ((IsNullOrEmpty $range) -and $retryCount -lt $MAXRETRIES)
	{

	$res = PostHttpRequest $fullUrl $payload
	if (-not (IsNullOrEmpty $res.ErrorCode))
		{
		return -1
		}
	$range = $res.Range
	$retryCount = $retryCount + 1
	}

$resultCount = 0

if ($clobCols.Count -gt 0)
    {
    $hasClobCols = $true
    }
else
    {
    $hasClobCols = $false
    }
foreach ($response in $res.Responses)
    {
        if (-not $errorResults)
            {
            $value = $response.Values
            if ($hasClobCols)
                {
                foreach ($clobCol in $clobCols.Keys)
                    {
                        # if we (probably) have only a partial result, go get the full clob result
                        if ($value.$clobCol.Length -ge $TACHYONCLOBSIZE)
                            {
                            $clobValue = GetClobValue $id $response $clobCol
                            $value.$clobCol = $clobValue
                            }
                    }
                }
             }
        else
            {
            $value = New-Object PSObject -Property @{
                ErrorData = $response.ErrorData
                Status = $response.Status
                }
            }

        $fqdn = $response.Fqdn

        if (IsNullOrEmpty $fqdn)
            {
            $fqdn = [string](new-guid)
            }

        if (-not $valueSet.ContainsKey($fqdn))
	        {
		    $deviceValues = New-Object System.Collections.Generic.List[System.Object]
	        $deviceValues.Add($value)
            $valueSet[$fqdn] = $deviceValues
            }
        else
            {
   	        $valueSet[$fqdn].Add($value)
            }
    	$resultCount = $resultCount + 1
    }
$nextRange.Value = $res.Range
return $resultCount
}

function FetchNextPageOfResultsRaw($url, $id, [ref]$nextRange,  $valueSet, $filter)
{
$payload = GetNextPagePayload $filter $nextRange
$MAXRETRIES = 200
  
$retryCount = 0
$range = $null


$fullUrl = $url + $id

$TRIMLENGTH = 50
$STARTRANGE = "0;0"

while ((IsNullOrEmpty $range) -and $retryCount -lt $MAXRETRIES)
	{

	$res = PostHttpRequestRaw $fullUrl $payload
   
	if (-not (IsNullOrEmpty $res.ErrorCode))
		{
		return -1
		}
    $resLength = $res.Content.Length
    if ($resLength -ge $TRIMLENGTH)
        {
        $s = $res.Content.Substring(1,$TRIMLENGTH)
        }
    else
        {
        $s = $res.Content
        }

	$range = GetRangeFromString $s

	if ($nextRange.Value -eq $STARTRANGE)
		{
		write-information -MessageData ([string](get-date) + " Range = 0;0, sleep 1")
		start-sleep -seconds 1
		}
	$retryCount = $retryCount + 1
	}

$resultCount = 1
if ($resLength -le $TRIMLENGTH)  # TODO:  bit crude, may need to refine this check - assumed empty result row
    {
    $resultCount = 0
    }
$nextRange.Value = $range
if ($resultCount -ne 0)
    {
    [void]$valueSet.Append($res.Content)
    }
return $resultCount
}

function FetchAggregatedResults($id, [ref]$nextRange, $valueSet, $filter)
{
$payload = GetNextPagePayload $filter $nextRange
$range = $null
while (IsNullOrEmpty $range)
	{
	$fullUrl = "/consumer/responses/" + $id + "/Aggregate"
	$res = PostHttpRequest $fullUrl $payload
	if (-not (IsNullOrEmpty $res.ErrorCode))
		{
		return -1
		}
	$range = $res.Range
    
	}

$resultCount = 0

foreach ($response in $res.Responses)
	{
	if (-not $valueSet.ContainsKey($AGGREGATEKEY))
		{
		$deviceValues = New-Object System.Collections.Generic.List[System.Object]
		$deviceValues.Add($response.Values)
		$valueSet[$AGGREGATEKEY] = $deviceValues
		}
	else
		{
		$valueSet[$AGGREGATEKEY].Add($response.Values)
		}

	$resultCount = $resultCount + 1
	}
	$nextRange.Value = $res.Range
	return $resultCount
}

function MergeFqdn($v)
{
foreach ($item in $v.getenumerator())
    {
    $values = $item.Value
    foreach ($value in $values)
        {
        add-member -MemberType NoteProperty -Name "Fqdn" -Value $item.Key -inputobject $value -force
        }
    }
}

function FetchAggregatedResultsRaw($id, [ref]$nextRange, $valueSet, $filter)
{
$payload = GetNextPagePayload $filter $nextRange

$TRIMLENGTH = 50

$range = $null
while (IsNullOrEmpty $range)
	{
	$fullUrl = "/consumer/responses/" + $id + "/Aggregate"
	$res = PostHttpRequestRaw $fullUrl $payload
	if (-not (IsNullOrEmpty $res.ErrorCode))
		{
		return -1
		}

    $resLength = $res.Content.Length
    if ($resLength -ge $TRIMLENGTH)
        {
        $s = $res.Content.Substring(1,$TRIMLENGTH)
        }
    else
        {
        $s = $res.Content
        }
	$range = GetRangeFromString $s

	}

$resultCount = 1

if ($resLength -le $TRIMLENGTH)  # TODO:  bit crude, may need to refine this check - assumed empty result row
    {
    $resultCount = 0
    }
$nextRange.Value = $range
if ($resultCount -ne 0)
    {
    [void]$valueSet.Append($res.Content)
    }
return $resultCount
}



function RetrieveScope($scope, $active)
{
# If $active specified, add a term to restrict scope to only active devices
if (isAtom $scope)
    {
    $expr = "fqdn like " + "%" + $scope +"%"
    }
else
    {
    $expr = $scope
    }

if ($active)
    {
    #ensure that whatever the expression is will be evaluated as a whole and then ANDed with status = 1
    $expr = "(" + $expr + ") and status=1"
    }

return get-scope -TargetScope $expr
}

function FormatAttribute($attrName, $json)
{
if (HasData $json)
    {
    return "," + (quotify $attrName) + ":" + $json
    }
else
    {
    return ""
    }
}

# get HTML params (?p=v&q=t....) and create JSON suitable for use with platform API

function RetrieveUrlParams($params, $paramDict)
{
$res = "["
$i = 1
foreach ($paramKey in $params.AllKeys)
    {
    # Platform requires that parameters be in the correct case but from a URL this is an annoying limitation because the browser will tend to re-use a matching query string regardless of case e.g if you said .... ?port=80 and it should have
    # been ?Port=80 then the browser will replace what you typed in - and also of course this is just plain tedious to remember. Because PowerShell dictionary key matches are case-insensitive, we can just get the correct casing of the
    # parameter from the dictionary and use that instead
    
    $value = $params[$paramKey]
    # at least one param won't be in the dictionary (scope) so ignore anything we can't match
    if ($paramDict.ContainsKey($paramKey))
        {
        $paramMetaData = $paramDict[$paramKey]
        $name = $paramMetaData.Name #correctly-cased
        $dataType = $paramMetaData.DataType
        if ($i -gt 1)
            {
            $res = $res + ","
            }
        $res = $res + (StringifyParam $name $value $dataType)
        $i = $i + 1
        }
    }
$res = $res + "]"
return $res
}

function HasData($s)
{
if ($s -ne "" -and $null -ne $s -and $s -ne "[]")
    {
    return $true
    }
else
    {
    return $false
    }
}

function WriteRawData($valueSet, $rawFilePath)
{
add-content -path $rawFilePath -value $valueSet.ToString()
[void]$valueSet.Clear()
optimize-memory
return [System.Text.StringBuilder]::new()	
}

function StringifyParam($paramName, $paramValue, $dataType)
{
$strParam = "{" + (Quotify "Name") + ":" + (Quotify $paramName) + "," + (Quotify "Value") + ":" + (Quotify $paramValue $dataType) + "}"
return $strParam
} 

function GetClobCols($instrInfo)
{
$clobCols = @{}
foreach ($entry in $instrInfo.Schema)
    {
    if ($entry.Type -eq "clob")
        {
        $clobCols.add($entry.Name,$entry.Name)
        }
    }
    return $clobCols
}

function GetSchema($schemaObj)
{
$sb = [System.Text.StringBuilder]::new()
$notfirst = $false
foreach ($entry in $schemaObj)
    {
    if ($notfirst)
        {
        [void]$sb.Append(", ")
        }
    [void]$sb.Append($entry.Name)
    [void]$sb.Append(" ")
    [void]$sb.Append($entry.Type)
    if ($entry.Type -eq "string")
        {
        [void]$sb.Append("(" + $entry.Length + ")")
        }
    $notfirst = $true
    }
return $sb.ToString()
}

function ListToPayload($list)
{
$sb = [System.Text.StringBuilder]::new()
$ret = '['
$notfirst = $false
[void]$sb.Append($ret)

foreach ($entry in $list)
    {
    $entry = $entry.Trim()
    if ($notfirst)
        {
	$s = ", " + (quotify $entry)
        [void]$sb.Append($s)
        }
    else
        {
	$s = (quotify $entry)
        [void]$sb.Append($s)
        $notfirst = $true
        }
    }
[void]$sb.Append("]")
return $sb.ToString()
}

# if targetpercent specified, pick a random percent of devices, minimum 1 device
# ExistingTargets is read from the optional tracking file. If specified, then devices in that list aren't eligible to be picked as they have already been processed.


function BuildDeviceList($devices, $targetPercent,$targetCount, $existingTargets)
{
$pickedDevices = @{}
$existingTargetDevices = @{}
$pickableDeviceList = New-Object System.Collections.Generic.List[System.Object]
$pickedDeviceList = New-Object System.Collections.Generic.List[System.Object]
if ($null -eq $existingTargets -or $existingTargets.Count -eq 0)
    {
    $infomsg = "No existing processed targets identified"
    }
else
    {
    $infomsg = "Existing targets already processed: " + $existingTargets.Count
    }
write-information -MessageData ([string](get-date) + " Building target device list from " + $devices.Count + " candidate target devices," + $infomsg)
if ($null -ne $existingTargets -and $existingTargets.Count -gt 0)
    {
    foreach ($existingTarget in $existingTargets)
        {
        $existingTargetDevices[$existingTarget.fqdn] = 1
        }

    foreach ($device in $devices)
        {
        $device = $device.Trim()
        if (-not $existingTargetDevices.containskey($device))
            {
            $pickableDeviceList.add($device)
            }
        }
        $pickableDevices = $pickableDeviceList.ToArray()
    }
else
    {
    $pickableDevices = $devices
    }
    
$deviceCount = $pickableDevices.Count
$fullDeviceCount = $devices.Count
    
write-information -MessageData ([string](get-date) + " Target device list count: " + $pickabledevices.Count)
$pickIt = $true

while ($deviceCount -gt 0 -and $pickIt)
{
    $rnd = get-random -maximum $deviceCount
    $device = $pickableDevices[$rnd].Trim()
    while ($pickedDevices.containsKey($device))
        {
        $rnd = get-random -maximum $deviceCount
        $device = $pickableDevices[$rnd].Trim()
        }
    $pickedDevices[$device] = 1
    $pickedDeviceList.add($device)

if ($targetCount -eq 0)
	{
	$pickIt = ($pickedDevices.Count -lt ($fullDeviceCount * ($TargetPercent / 100)) -and ($pickedDevices.Count -lt $pickableDevices.Count))
	}
else
	{
	$pickIt = (($pickedDevices.Count -lt $TargetCount) -and ($pickedDevices.Count -lt $pickableDevices.Count))
	}
}
write-information -MessageData ([string](get-date) + " Selected target device list count: " + $pickedDeviceList.Count)
return $pickedDeviceList.ToArray()
}

function FetchNextPage($InstructionId, $Raw, $nextRange, $valueSet, $filter, $clobCols, $aggregated)
{
if (-not (IsNullOrEmpty $Raw))
        {
        if ($aggregated)
            {
            $resultCount = FetchAggregatedResultsRaw $instructionId $nextRange $valueSet $filter
            }
        else
            {
            $resultCount = FetchNextPageOfResultsRaw "/consumer/responses/" $instructionId $nextRange $valueSet $filter
            }

        if ($resultCount -gt 0)
	        {
           	$valueSet = WriteRawData $valueSet $raw
		    }
        }
        else
        {
        if ($aggregated)
            {
           	$resultCount = FetchAggregatedResults $instructionId $nextRange $valueSet $filter
            }
        else
            {
            $resultCount = FetchNextPageOfResults "/consumer/responses/" $instructionId $nextRange $valueSet $clobCols $filter
            }
        }
return $resultCount
}

function GetStatistics($id)
{
    $fullUrl = "/consumer/instructionstatistics/Summary/" + $id
    $res = GetHttpRequest $fullUrl
    return $res
}

function GetConsumers($name, $id)
{
    if ($id -eq 0)
	{
	if (IsNullOrEmpty $name)
	    {
	    $fullUrl = "/consumer/consumers"
	    }
	else
	    {
	    $fullUrl = "/consumer/consumers/name/" + (ToBase64 $name)
	    }
	}
else
	{
	    $fullUrl = "/consumer/consumers/Id/" + $id
	}
    $res = GetHttpRequest $fullUrl
    return $res
}


function ProcessResults($Raw, [ref]$nextRange, $valueSet, $instructionId, $clobCols, $filter, $aggregated, $targetDeviceCount)
    {	
    $retryCount = 0
    $MAXRETRIES = 200
        
    $res = GetStatistics $instructionId
    
    if ($res.EstimatedCount -eq 0)
        {
        write-information -MessageData ([string](get-date) + "Estimated target count = 0, exiting")
        return $res
        }

    # If we did not get passed in a target device count, we are being called from a request to get historical data.
    # In this case normally $res.EstimatedCount will have the expected count of devices, but if duplicate FQDNs exist with inactive duplicates, then this count will be too high
    # Therefore we check if the estimated count exceeds the received count. If it does, then either the instruction is still active with data to come back in, or there are inactive FQDNs
    # To handle this, we retrieve the original instruction target list and compute the distinct device count. This then becomes the expected device count.
    if (IsNullOrEmpty $targetDeviceCount)
        {
        if ($res.EstimatedCount - $res.ReceivedCount -eq 0)
            {
            $targetDeviceCount = $res.EstimatedCount
            }
        else
            {
            write-information -MessageData ([string](get-date) + " Estimated Count: " + $res.EstimatedCount + " Received Count: " + $res.ReceivedCount + " - Retrieving distinct target count")
            # this could throw if the original instruction was run from Explorer and did not have a specific target list (whereas everything run from the PowerShell toolkit will have a list)
            try
                {
                $r = get-instructiontargetfqdn -id $InstructionId | sort-object | get-unique
                write-information -MessageData ([string](get-date) + " Distinct Target Count: " + $r.Count)
                $targetDeviceCount = $r.Count
                }
            catch
                {
                write-information -MessageData ([string](get-date) + " Could not retrieve target count as instruction was not originally targetted, reverting to stats estimate: " + $res.EstimatedCount)
                $targetDeviceCount = $res.EstimatedCount #we'll have to use this
                }
            }
        }

# aggregated queries simply return a 0;0 page

    if ($aggregated)
        {
        $res = GetStatistics $instructionId
        $outstandingResponses = $targetDeviceCount - $res.ReceivedCount

         while ($outstandingResponses -gt 0)
            {
            $res = GetStatistics $instructionId
            $outstandingResponses = $targetDeviceCount - $res.ReceivedCount
            write-information -MessageData ([string](get-date) + " Aggregate: Waiting for completion, Target: " + $targetDeviceCount + " Sent: " + $res.SentCount  + " Received: "  + $res.ReceivedCount)
            start-sleep -seconds 1
            }
            $resultCount = FetchNextPage $InstructionId $Raw $nextRange $valueSet $filter $clobCols $aggregated
            write-information -MessageData ([string](get-date) + " Result Count: " + $resultCount + " NextRange: " + $nextRange.Value + " Sent: " + $res.SentCount  + " Received: "  + $res.ReceivedCount + " Total Data: " +  $valueSet.Count)
            return $res
        }

    $resultCount = FetchNextPage $InstructionId $Raw $nextRange $valueSet $filter $clobCols $aggregated
   
    write-information -MessageData ([string](get-date) + " Result Count: " + $resultCount + " NextRange: " + (FormatRange $nextRange.Value) + " Sent: " + $res.SentCount  + " Received: "  + $res.ReceivedCount + " Total Data: " +  $valueSet.Count)
    $outstandingResponses = $targetDeviceCount - $res.ReceivedCount

    $retryCount = 0
    $gotResults = $true

	while ((($retryCount -lt $MAXRETRIES) -and ($outstandingResponses -gt 0)) -or $gotResults)
        {
        $res = GetStatistics $instructionId	
        $resultCount = FetchNextPage $InstructionId $Raw $nextRange $valueSet $filter $clobCols $aggregated
		
        write-information -MessageData ([string](get-date) + " Result Count: " + $resultCount +  " NextRange: " + (FormatRange $nextRange.Value) + " Sent: " + $res.SentCount  + " Received: "  + $res.ReceivedCount + " Total Data: " +  $valueSet.Count)
        $outstandingResponses = $targetDeviceCount - $res.ReceivedCount

        if ($resultCount -eq 0)
            {
            $gotResults = $false
            write-information -MessageData ([string](get-date) + " Result count = 0, retry count: " + $retryCount + ",sleep 1 sec")
            start-sleep -seconds 1
            $retryCount++
            }
        else
            {
            $gotResults = $true
            $retryCount = 0
            }
        }

    return $res
}

function ProcessErrorResults($Raw,$instructionId, $valueSet)
{
    $errorSet = @{}
    $nextRange = "0;0"
	write-information -MessageData ([string](get-date) + " fetch errors")
    $resultCount = 1

    # collect errors into a dictionary, regardless of raw or non-raw mode
    while ($resultCount -gt 0)
		{
        $resultCount = FetchNextPageOfResults "/consumer/ResponseErrors/" $instructionId ([ref]$nextRange) $errorSet
        }

    # in Raw mode, go back and get the errors again as deserialised json and add them to the output file
    if (-not (IsNullOrEmpty $Raw))
	{
    $nextRange = "0;0"
    $valueSet = [System.Text.StringBuilder]::new()	
	write-information -MessageData ([string](get-date) + " fetch errors (raw)")
    $resultCount = 1
	while ($resultCount -gt 0)
		{
        $resultCount = FetchNextPageOfResultsRaw "/consumer/ResponseErrors/" $instructionId ([ref]$nextRange) $valueSet
        if ($resultCount -gt 0)
            {
            $valueSet = WriteRawData $valueSet $raw
            }
        }
    }
    else
    {
        # In non-raw mode, add the error responses to the returned results. A device reporting an error cannot have returned successful results so these will all be new dictionary entries
        foreach ($key in $errorSet.Keys)
        {
    		$deviceValues = New-Object System.Collections.Generic.List[System.Object]
	        $deviceValues.Add($errorSet[$key])
            $valueSet[$key] = $deviceValues
        }
    }
    return $errorSet
}

function GetInstructionResults($Id, $drilldown, $resultfilter, $Raw, $receivedOnly)
{
$instrInfo = get-instructionStatus $id -Full
$clobCols = GetClobCols $instrInfo
$aggregated = $instrInfo.Aggregation
$nextRange = "0;0"
$valueSet = GetValueSet $Raw
$status = $instrInfo.Status

if (IsNullOrEmpty $aggregated)
    {
    $aggregated = $false
    }
else
    {
    $aggregated = $true
    }

if ($status -ne "Sent" -and $status -ne "InProgress" -and $status -ne "Complete" -and $status -ne "Cancelling")
    {
    throw "Status of this instruction is " + $status + " and results cannot be retrieved"
    } 

if (($drilldown -and $aggregated) -and (-not $instrInfo.Keepraw))
    {
    throw "Detailed results are not available because this instruction was launched with KeepRaw = false"
    }

if (-not (IsNullOrEmpty $Resultfilter))
    {
    $filter = (exprToJson $Resultfilter)
    }
else
    {
    $filter = $null
    }

if (-not $drilldown -and $aggregated)
    {
    $aggr = $true
    }
else
    {
    $aggr = $false
    }
# if -ReceivedOnly is specified or if the instruction status is complete, we have all the results we're gonna get
if (((IsNullOrEmpty $receivedOnly) -or ($receivedOnly -eq $false)) -and ($status -ne "Complete"))
    {
    $res = ProcessResults $Raw  ([ref]$nextRange) $valueSet $Id $clobCols $filter $aggr
    }
else
    {
     $r = GetStatistics $Id
     $res = ProcessResults $Raw  ([ref]$nextRange) $valueSet $Id $clobCols $filter $aggr $r.ReceivedCount
    }

if ($res.TotalErrorRespondents -ne 0 -or $res.TotalNotImplementedRespondents -ne 0)
    {
    [void](ProcessErrorResults $false $Id $valueSet)
    }

if (IsNullOrEmpty $raw)
    {
    return $valueSet
    }
return $res
}

# return appropriate valueset and if raw mode, clear output file contents if file exists

function GetValueSet($Raw)
{
if (-not (IsNullOrEmpty $Raw))
	{
	$valueSet = [System.Text.StringBuilder]::new()	
	if (test-path -path $raw)
		{
		clear-content -path $raw
		}
	}
else
	{
	$valueSet = @{}
	}
return $valueSet
}

function GetChildMGs
{
[CmdletBinding()]

Param(
    [Parameter(Mandatory=$true)] [PSObject]$MGList,
    [Parameter(Mandatory=$false)] [string]$Name,
    [Parameter(Mandatory=$false)] [int]$Id
    )
$mgs = New-Object System.Collections.Generic.List[System.Object]
$returnAll = $false
if ((IsNullOrEmpty $Name) -and ($Id -eq 0))
    {
    $returnAll = $true
    }

foreach ($entry in $MGList)
    {
    if ($returnAll)
        {
        [void]$mgs.Add($entry)
        }
    else
        {
        if (-not (IsNullOrEmpty $Name))
            {
            if ($entry.Name -eq $Name)
                {
                [void]$mgs.Add($entry)
                }
            }
        else
            {
            if ($Id -ne 0)
                {
                if ($entry.Id -eq $Id)
                    {
                    [void]$mgs.Add($entry)
                    }
                }
            }
        }
    if ($null -ne $entry.Children)
        {
        $children = GetChildMGs -MGList $entry.Children -Name $Name -Id $Id
        foreach ($child in $children)
            {
            [void]$mgs.Add($child)
            }
        }
    }
return $mgs
}

function RunInstruction
{

[CmdletBinding()]


Param(
    [Parameter(Mandatory=$true, Position=1)] [string]$instruction,
    [Parameter(Mandatory=$true)] [string[]]$scope,
    [Parameter(Mandatory=$true)] [int]$InstTTL,
    [Parameter(Mandatory=$true)] [int]$resultsTTL,
    [Parameter(Mandatory=$false)] [string]$Params,
    [Parameter(Mandatory=$false)] [switch]$drilldown = $false,
    [Parameter(Mandatory=$false)] [switch]$IsTargetted = $false,
    [Parameter(Mandatory=$false)] [string]$Raw = $null,
    [Parameter(Mandatory=$false)] [int]$TargetPercent = 100,
    [Parameter(Mandatory=$false)] [int]$TargetCount = 0,
    [Parameter(Mandatory=$false)] [string]$TargetFile = $null,
    [Parameter(Mandatory=$false)] [switch]$NoWait = $false,
    [Parameter(Mandatory=$false)] [switch]$DynamicScope = $false,
    [Parameter(Mandatory=$false)] [string]$ResultFilter = $null,
    [Parameter(Mandatory=$false)] [switch]$Offload = $false
    )

$paramsJson = ""

$m = GetInstructionMetaDataByName $instruction

if ($m.InstructionType -eq "Action")
    {
    $isAction = $true
    }
else
    {
    $isAction = $false
    }
$isServerSide = IsServerSideInstruction $m

# if param string is a URl param string i.e ?foo=pow&zap=x.... then parse
if (HasData $params)
    {
    if ($params.StartsWith("?"))
        {
        # get the parameter definitions and make a dictionary keyed by parameter name then get the params as JSON along with parameter metadata (datatype)
       
        if ($null -ne $m)
            {
            $paramDefs = $m.Parameters
            }
        $paramDefDict = CollectionToDictionary $paramDefs "Name"
        $paramsJson = RetrieveUrlParams $params $paramDefDict
        }
    else
        # otherwise, assume it's a JSON string already
        {
        $paramsJson = $params
        }
    }

# tableoptimizationtype specifies read optimisation. This is much more efficient and greatly reduces the overhead on the database server. However the server should be running SQL2019 or later to avoid insert hotspot contention issues        
# keepraw set to false unless we request drilldown

if ($drilldown)
    {
    $keepRaw = '"true"'
    }
else
    {
    $keepRaw = '"false"'
    }

if ($offload)
	{
	$payload = @"
		{
		"DefinitionName": $(quotify $instruction),
		"OffloadResponses": true,
		"InstructionTtlMinutes": $($instTTL),
		"ResponseTtlMinutes": $($resultsTTL),
		"TableOptimizationType":1,
		"KeepRaw": $($keepRaw)
		$(FormatAttribute "Parameters" $paramsJson)
"@

	}
else
	{
	$payload = @"
		{
		"DefinitionName": $(quotify $instruction),
		"OffloadResponses": false,
		"InstructionTtlMinutes": $($instTTL),
		"ResponseTtlMinutes": $($resultsTTL),
		"TableOptimizationType":1,
		"KeepRaw": $($keepRaw)
		$(FormatAttribute "Parameters" $paramsJson)
"@

	}

# if a tracking file was specified, read it in now

if (-not (IsNullOrEmpty $targetFile))
    {
    if (test-path $targetFile)
        {
        $existingTargets = get-content $targetFile | convertfrom-json
        # check if any existing entries, that the Id for the first one matches the instruction name here, otherwise this file isn't the right one
        if ($existingTargets.Count -gt 0)
            {
            $fileInstrId = $existingTargets[0].Id
            $fileInstr = get-instructionStatus $fileInstrId -Full
            $fileInstrName = $fileInstr.Name
            if ($instruction -ne $fileInstrName)
                {
                throw "The target file specified contains entries for instruction " + $fileInstrName + " but the instruction being invoked is " + $instruction
                }
            }
        }
    }
# to ensure we only target active devices, we convert scope into a list of devices then always use the targetted API. Unless we specify DynamicScope. In that case we just pass the supplied scope expression into the non-targetted API
if ($TargetPercent -eq 100 -and $TargetCount -eq 0)
    {
    if (-not $DynamicScope -and -not $isServerSide)
	{
	    $url = "/consumer/instructions/targeted"
	    if ($isTargetted -eq $null -or $isTargetted -eq $false)
        	    {
			write-information -MessageData ([string](get-date) + " About to retrieve responding devices for scope")
	       		$targettedDevices = get-respondingdevice -targetscope $scope[0] -Active -AsArray
        		$payload += ',"Devices":' + (ListToPayload $targettedDevices)
			write-information -MessageData ([string](get-date) + " Responding devices for scope retrieved")
        	    }
	        else
        	    {
	            $targettedDevices = $scope
        	    $payload += ',"Devices":' + (ListToPayload $targettedDevices)
            	}
	}
    else
	{
	$url = "/consumer/instructions"
	$payload += ',"Scope":' + (RetrieveScope $scope[0])
	}

    }
else
    {
    $expectingDeviceList = $true
    $url = "/consumer/instructions/targeted"
    if ($isTargetted -eq $null -or $isTargetted -eq $false)
        {
        # PowerShell 'helpfully' returns a string if the array has one element, which we do not want
        [array]$scopeDevices = get-respondingdevice -TargetScope $scope[0] -Active | ForEach-Object {$($_.fqdn)}
        $targettedDevices =  BuildDeviceList $scopeDevices $targetPercent $targetCount $existingTargets
        $payload += ',"Devices":' + (ListToPayload $targettedDevices)
        }
    else
        {
        $targettedDevices = BuildDeviceList $scope $targetPercent $targetCount $existingTargets
        $payload += ',"Devices":' + (ListToPayload $targettedDevices)
        }
    }
$payload += "}"
if (($isTargetted -or $expectingDeviceList) -and $targettedDevices.Count -eq 0)
    {
    write-host "No targetted devices selected"
    return $null
    }

$instrInfo = PostHttpRequest $url $payload
if ($null -eq $instrInfo)
	{
	return $null
	}
$instructionId = $instrInfo.Id
$script:gLastInstructionId = $instructionId

if ($instructionId -eq 0)
	{
	return $null
	}

# If NoWait specified return immediately
if ($NoWait)
    {
    return $instructionId
    }

# build a set of columns which are clob values (if any), as these will require extra processing when result pages are processed
# TODO: review interim solution that prevents raw mode if clob values exist

$clobCols = GetClobCols $instrInfo
if ($clobCols.Count -gt 0 -and (-not (IsNullOrEmpty $raw)))
    {
    throw "Cannot retrieve raw data for instructions that have CLOB columns in their result set"
    }

$aggregated = $instrInfo.Aggregation
if ($aggregated -eq "" -or $null -eq $aggregated -or $drilldown -eq $true)
	{
    $aggregated = $false
    }
else
	{
    $aggregated = $true
	}

# if instruction is awaiting authentication, loop

$status = Get-InstructionStatus -Id $InstructionId

while ($status -ne "InProgress")
	{
	write-information -MessageData ([string](get-date) + " Instruction Status:" + $status + ".Waiting for instruction to transition to InProgress,sleep 1")
	$status = Get-InstructionStatus -Id $InstructionId
    if (isFailedStatus $status)
        {
        throw "Instruction execution failed"
        }
	Start-Sleep 1
	}

$nextRange = "0;0"

$valueSet = GetValueSet $raw

if (-not (IsNullOrEmpty $Resultfilter))
    {
    $filter = (exprToJson $Resultfilter)
    }
else
    {
    $filter = $null
    }

if ($isServerSide)
    {
    $res = ProcessResults $Raw  ([ref]$nextRange) $valueSet $instructionId $clobCols $filter $aggregated
    }
else
    {
    $res = ProcessResults $Raw  ([ref]$nextRange) $valueSet $instructionId $clobCols $filter $aggregated $targettedDevices.Count
    }

    # see how many respondents reported an issue. We collate these into a separate dictionary, errorSet, so that when tracking targetted rollouts we can report which devices received an instruction but reported an error
    # In raw mode we incur a slight overhead by retrieving this data twice; once to cleanly collect the error set and then a second time to get the raw results to add to the raw output file

$hadErrs = $false
$notFirst = $false

if (-not (IsNullOrEmpty $targetfile))
    {
    if (test-path -path $targetFile)
        {
        clear-content $targetFile
        }
    set-content -path $targetFile -value "[" 
    }
    

if ($res.TotalErrorRespondents -ne 0 -or $res.TotalNotImplementedRespondents -ne 0)
    {
    $hadErrs = $true
    $errs = ProcessErrorResults $Raw $instructionId $valueSet
    if (-not (IsNullOrEmpty $targetfile))
       {
        foreach ($errKey in $errs.Keys)
            {
            foreach ($errItem in $errs[$errKey])
                {
                $value = New-Object PSObject -Property @{
                        fqdn = $errKey
        	            Id = $instrInfo.Id
			            CreatedTimestampUTC = $instrInfo.CreatedTimeStampUTC
			            CreatedBy = $instrInfo.CreatedBy
                        Status = $errItem.Status
                        ErrorData = $errItem.ErrorData
                        }
                 $json = convertto-json $value
                 if ($notFirst)
                    {
                    add-content -path $targetFile -value ","
                    }
                 else
                    {
                    $notFirst = $true
                    }

                 add-content -path $targetFile -value $json
               }
            }
        }

    }


if (-not (IsNullOrEmpty $targetfile))
    {
    # write back out all the processed targets again
    foreach ($existingTarget in $existingTargets)
    {
        $json = convertto-json $existingTarget
        if ($notFirst)
                {
                add-content -path $targetFile -value ","
                }
        else
                {
                $notFirst = $true
                }

        add-content -path $targetFile -value $json
    }

    # append all the devices in the target list that didn't report an error, then add the errorred devices
    foreach ($device in $targettedDevices)
        {
        $device = $device.Trim()
        # write it out if it wasn't in the error list
        if (-not ($hadErrs -and $errs.ContainsKey($device)))
            {
            $value = New-Object PSObject -Property @{
                        fqdn = $device
        	            Id = $instrInfo.Id
			            CreatedTimestampUTC = $instrInfo.CreatedTimeStampUTC
			            CreatedBy = $instrInfo.CreatedBy
                        Status = 0
                        ErrorData = ""
                        }
            $json = convertto-json $value
            if ($notFirst)
                    {
                    add-content -path $targetFile -value ","
                    }
            else
                    {
                    $notFirst = $true
                    }

            add-content -path $targetFile -value $json
            }
        }
        add-content -path $targetfile -value "]"
    }
    

    if (-not (IsNullOrEmpty $Raw))
	{
	return $res # give user instruction statistics as result, because main data was written to output file
	}
else
	{
	    return $valueSet
	}
}

function NormaliseParamCase($paramValue, $allowedValues)
{
    foreach ($allowedValue in $allowedValues)
        {
        # PS is case-insensitive
        if ($paramValue -eq $allowedValue)
            {
            $paramValue = $allowedValue
            return $paramValue
            }
        }
    return $paramValue
}

function BuildParams($metadata, $boundparams, $defaultProps)
{
    if ($null -eq $metadata -or $metadata.count -eq 0)
        {
        return "[]"
        }

    $res = "["
    $i = 1
    foreach ($m in $metadata)
        {
        #handle params with embedded spaces
        $paramName = $m.Name.Replace(" ","_")
        $dataType = $m.DataType
	$paramValue = ""

	# doesn't appear possible for a cmdlet to have a mandatory dynamic param with a default, so we pass in any default overrides as a separate dictionary
	if ($null -ne $defaultProps -and $null -ne $defaultProps[$paramName])
	    {
	    $paramValue = $defaultProps[$paramName]
	    }

    if ($null -ne $boundparams)
        {
        #TODO: different parameter types?
        $paramValue = [string]$boundparams[$paramName]
        }

    if ($paramValue -eq "" -and $m.DefaultValue -ne "" -and $null -ne $m.DefaultValue)
        {
        $paramValue = $m.DefaultValue
        }

    if ($m.ControlType -eq "ValuePicker")
        {
        # ensure case of the param is regularised as some of the APIs are case-sensitive
        $paramValue = NormaliseParamCase $paramValue $m.Validation.AllowedValues
        }

        if ($paramValue -ne "")
            {
            if ($i -gt 1)
                {
                $res += ","
                }
# reverse the space to underscore conversion so we can send the param to platform as originally defined
            $tachyonParam = $paramName.Replace("_"," ")
            $res += (StringifyParam $tachyonParam $paramValue $dataType)
            $i++
            }
    }
    $res += "]"
    if ($res -eq "[]")
        {
        return $null
        }
        return $res
}

#see how many devices fall into scope and return count


function GetRespondingDevices($scope)
{
$res = PostHttpRequest "/consumer/Devices/Scope" $scope
return $res
}

function GetAllDevices()
{
$res = GetHttpRequest "/consumer/Devices"
return $res
}


function SearchInstructions($searchTerm)
{

$srch = $searchTerm + "%"

$payload = @"
	{
        "Start": 1,
        "PageSize":10000,
        "Filter": {
        "Attribute": "ReadablePayload",
        "Operator": "LIKE",
        "Value": "$($srch)"
        }
    }
"@

$res = PostHttpRequest "/consumer/InstructionDefinitions/Search" $payload
return $res.Items
}

function SearchInstructionsByDesc($searchTerm)
{
if (IsNullOrEmpty $searchTerm)
	{
	return $null
	}
$url = "/consumer/InstructionDefinitions/Search/" + (ToBase64 $searchTerm) + "?InstructionType=0&InstructionType=1"
$res = GetHttpRequest $url
return $res
}

function GetInstructionSetId($name)
{
$res = GetInstructionSet $name
return $res.Id
}

function GetInstructionSet($name)
{
$url = "/Consumer/InstructionSets/Name/" + $name
$res = GetHttpRequest $url
return $res
}


function CreateOrUpdateInstructionSet ($instructionSet, $id, $description, $icon)
{
$desc = $description
if (IsNullOrEmpty $desc)
    {
    $desc = ""
    }

if (IsNullOrEmpty $icon)
    {
        if ($id -ne 0)
            {
            $payload = @"
                 {
                 "Id":$($Id),
                 "Name": $(quotify $instructionSet),
                 "Description": $(Quotify $desc)
                 }
"@
            }
        else
            {
            $payload = @"
                 {
                 "Name":$(quotify $instructionSet),
                 "Description": $(Quotify $desc)
                 }
"@
            }
    }
else
    {
    $filepath = GetFullPath $Icon
    $bytes = [System.IO.File]::ReadAllBytes($filePath)
    if ($bytes.length -eq 0)
        {
        throw "Unable to read the specified icon file"
        }
    $iconBase64 = [Convert]::ToBase64String($bytes)

    if ($id -ne 0)
        {
        $payload = @"
            {
            "IconInBase64": $(quotify $iconBase64),
            "UseIcon": true,
            "Name": $(quotify $instructionSet),
            "Id": $($Id),
            "Description": $(quotify $desc)
            }
"@
        }
    else
        {
        $payload = @"
            {
            "IconInBase64": $(quotify $iconBase64),
            "UseIcon": true,
            "Name": $(quotify $instructionSet),
            "Description": $(quotify $desc)
            }
"@
        }
    }
$url = "/Consumer/InstructionSets"
if ($id -eq 0)
    {
    $res = PostHttpRequest $url $payload
    }
else
    {
    $res = PutHttpRequest $url $payload
    }
return $res
}

function DeleteInstructionSet($id, $deleteContent)
{
if ($deleteContent)
    {
    $url = "/consumer/InstructionSets/Id/" + $id + "?deleteContent=true"
    }
else
    {
    $url = "/consumer/InstructionSets/Id/" + $id + "?deleteContent=false"
    }

$res = DeleteHttpRequest $url
return $res
}


function UploadInstruction($instruction)
{
$addhdrs = @{"Content-Type" ="multipart/form-data; boundary=xyzzy"}
$res = PostHttpRequest "/consumer/ProductPacks" $instruction $addhdrs
return $res
}

function UploadInstructionToSetName($instruction, $setName)
{
$setId = GetInstructionSetId $setName

if ($null -ne $setId)
	{
	$res = UploadInstructionToSetId $instruction $setId
	}
else
	{
	throw "Instruction set " + $setName + " could not be located"
	}
return $res
}	

	

function MoveToSet($instrid, $setid)
{

$payload = '{
  "SetId": ' + $setid + 
  ',"InstructionDefinitionIds": [' +
    $instrid + 
 ']}'

$res = PostHttpRequest "/consumer/InstructionSets/Contents" $payload
return $res

}

function GetInstructionMetadataByName($instructionName)
{
$url = "/Consumer/InstructionDefinitions/Name/" + $instructionName
$res = GetHttpRequest $url
$res.InstructionType = DecodeInstructionType $res.InstructionType
return $res
}

function GetInstructionMetadataById($id)
{
$url = "/Consumer/InstructionDefinitions/Id/" + $Id
$res = GetHttpRequest $url
$res.InstructionType = DecodeInstructionType $res.InstructionType
return $res
}


#build a dictionary from a collection, selecting an arbitrary (unique per entry) property of the collection object as the dictionary key

function CollectionToDictionary($collection, $keyProp)
{
$dict = @{}

foreach ($item in $collection)
    {
    $dict.Add($item.$keyProp,$item)        
    }
return $dict
}

function DecodeInstructionStatus($status)
{
$ret = switch ($status)
    {
    0 {"Created"}
    1 {"InApproval"}
    2 {"Rejected"}
    3 {"Approved"}
    4 {"Sent"}
    5 {"InProgress"}
    6 {"Complete"}
    7 {"Expired"}
    8 {"Cancelling"}
    9 {"Cancelled"}
    10 {"Failed"}
    11 {"Suspended"}
    12 {"Authenticating"}
    }
return $ret
}

function DecodeInstructionType($type)
{
$ret = switch ($type)
    {
    0 {"Question"}
    1 {"Action"}
    }
return $ret
}

function DecodeWorkflowState($state)
{
$ret = switch ($state)
    {
    0 {"New"}
    1 {"RiskAssessment"}
    2 {"PendingApproval"}
    3 {"Processing"}
    4 {"InProgress"}
    5 {"Completing"}
    6 {"Cancelling"}
    7 {"Rejecting"}
    8 {"Closed"}
    9 {"Failed"}
    10 {"Suspended"}
    11 {"Authenticating"}
    }
return $ret
}

function MultipartWrap($output)
{
$mimeprefix = "--xyzzy" + "`r`n" + 'Content-Disposition: form-data; name="' + $output +'"; filename="' + $output + '"' + "`r`n" + 'Content-Type: text/xml' + "`r`n`r`n"
$mimesuffix ="`r`n--xyzzy--"

$inst = $mimeprefix
$inst = $inst + (get-content -Raw $output) + $mimesuffix
return $inst
}


function GetActiveInstructions()
{
$instSets = get-instructionSet
$instrs = New-Object System.Collections.Generic.List[System.Object]
foreach ($instSet in $instSets)
	{
	$id = $instSet.Id
    $url = "/Consumer/Instructions/Inflight/InstructionSet/" + $id + "?dataSourceFilter=All"
    $res = GetHttpRequest $url
    if ($res.Items.Count -gt 0)
        {
        foreach ($instr in $res.Items)
            {
            $instrs.Add($instr)
            }
        }
	}
return $instrs
}

# The result in $r is a dictionary keyed by the device name. Each entry has an ExitCode and and Output value.
# For scripts, the Output value is whatever the script returns
# For queries and SCALE fragments, the Output value is a JSON encoding of the result

#foreach ($key in $r.Keys)
#    {
#    $entry = $r[$key]
#    write-host $key
#    write-host $entry.ExitCode
#    write-host $entry.Output
#    }


function OutputInstructionResults($r)
{
foreach ($key in $r.Keys)
    {
    $entry = $r[$key]
    write-host "Target:   " $key
    write-host "ExitCode: " $entry.ExitCode
    try
	{
	convertfrom-json $entry.Output
	}
    catch
	{
	write-host $entry.Output
	}
    write-host
    }
}

function GetInstNameFromFile($fileName)
{
[xml]$xml = get-content $fileName
return $xml.InstructionDefinition.Name
}

function CheckParamsInconsistent ($TargetScope, $targetFqdns, $TargetPercent, $TargetCount, $TargetFile, $Raw, $Csv, $DynamicScope)
{
$msg = ""
if ((-not (IsNullOrEmpty $targetscope)) -and (-not (IsNullOrEmpty $targetFqdns)))
    {
    $msg = "Only one of -TargetScope or -TargetFqdns can be specified"
    return $msg
    }

if ($DynamicScope -and (-not (IsNullOrEmpty $targetFqdns)))
    {
    $msg = "Only one of -DynamicScope or -TargetFqdns can be specified"
    return $msg
    }

if ($DynamicScope -and ($targetpercent -ne 100 -or $targetCount -ne 0))
    {
    $msg = "Cannot specify -DynamicScope if either -TargetPercent or -TargetCount are specified"
    return $msg
    }


if ($targetpercent -ne 100 -and $targetCount -ne 0)
    {
    $msg = "Only one of -TargetPercent or -TargetCount can be specified"
    return $msg
    }

if ((-not (IsNullOrEmpty $targetFile)) -and ($targetPercent -eq 100 -and $targetCount -eq 0))
    {
    $msg = "Cannot specify a progress tracking file with -TargetFile unless either -TargetCount or -TargetPercent are specified and have non-default values"
    return $msg
    }

if ((-not (IsNullOrEmpty $Raw)) -and (-not (IsNullOrEmpty $Csv)))
    {
    $msg = "Only one of -Raw or -Csv can be specified"
    return $msg
    }

return $msg    
}

function ProcessSearchChars($line, $canSelect, [ref]$retPressed)
{
$e = [char]27
$idle = 0
while ($true)
    {
    if ([Console]::KeyAvailable)
	{
	    $key = $Host.UI.RawUI.ReadKey() 
	    if ($key.VirtualKeyCode -eq 13)
		{
		$retPressed.Value = $true
		return $line
		}
   	    if ($key.VirtualKeyCode -eq 8)
	        {
		if ($line.length -gt 0)
			{
			$line = $line.Substring(0,$line.length - 1)
			write-host "$e[0K"
			}
		}

        if ($key.VirtualKeyCode -gt 31)
		{
	    	$line += $key.Character
		}

	if ($canSelect -eq $true -and ($key.VirtualKeyCode -ge 48 -and $key.VirtualKeyCode -le 57))
		{
		$retPressed.Value = $true
		return $line
		}
	$outstr = "$e[3;0f" + $line
        write-host $outstr -NoNewLine
	}
    else
	{
	start-sleep -milliseconds 100
	if ([Console]::KeyAvailable -eq $false)
		{
		$idle++
		}
	else
		{
		$idle = 0
		}
	if ($idle -gt 10)
		{
		break
		}
	}
    }
return $line
}

function MapType($dataType)
{
if ($dataType -eq "string")
    {
    return "[string]"
    }

if ($dataType -eq "int")
    {
    return "[int]"
    }

if ($dataType -eq "float")
    {
    return "[double]"
    }

return "[string]"
}

function GetValidateSet($paramMetadata)
{
$validEntries = ""
$notFirst = $false
foreach ($allowedValue in $paramMetadata.Validation.AllowedValues)
    {
    if ($notFirst)
        {
        $validEntries += ","
        }
    $notFirst = $true
    $validEntries += quotify $allowedValue $paramMetadata.DataType
    }
return "[ValidateSet(" + $validEntries + ")]"
}

function SendInstructionAuthToken($id, $token)
{
$url = "/consumer/Authentication/Instruction/Token/"
$payload = @"
	     {
		"Id": $Id,
		"Token": $(quotify $Token)
      	     }
"@
$res = PostHttpRequest $url $payload
return $res
}

function SendScheduledInstructionAuthToken($id, $token)
{
$url = "/consumer/Authentication/ScheduledInstruction/Token/"
$payload = @"
	     {
		"Id": $Id,
		"Token": $(quotify $Token)
      	     }
"@
$res = PostHttpRequest $url $payload
return $res
}

function ApproveOrDenyInstruction($Id, $approve, $comment)
{
$url = "/consumer/Approvals/Instruction"
	
if (IsNullOrEmpty $comment)
	{
	$comment = "This instruction was approved via the PowerShell integration toolset"
	}

if ($approve)
	{
	$flag = "true"
	}
else
	{
	$flag = "false"
	}

$payload = @"
	     {
		"InstructionId": $Id,
		"Comment": $(quotify $Comment),
		"Approved":$(quotify $flag)
      	     }
"@
$res = PostHttpRequest $url $payload
return $res
}

function ApproveOrDenyScheduledInstruction($Id, $approve, $comment)
{
$url = "/consumer/Approvals/ScheduledInstruction"
	
if (IsNullOrEmpty $comment)
	{
	$comment = "This instruction was approved via the PowerShell integration toolset"
	}

if ($approve)
	{
	$flag = "true"
	}
else
	{
	$flag = "false"
	}

$payload = @"
	     {
		"ScheduledInstructionId": $Id,
		"Comment": $(quotify $Comment),
		"Approved":$(quotify $flag)
      	 }
"@
$res = PostHttpRequest $url $payload
return $res
}

function GetCmdletFromXml($xml)
{
$m =$xml -match "\[.*?Cmdlet=([\w|\-]+)\W"
if ($m)
    {
    return $matches[1]
    }
return ""
}

function SearchRules($Name)
{
$url = "/Consumer/Rules/Shallow/Search"
$payload = @"
 {
  "Start": 1,
  "PageSize": 2000,
  "Filter": {
    "Attribute": "Name",
    "Operator": "LIKE",
    "Value": "$($Name)"
  }
}
"@
$res = PostHttpRequestPaged $url $payload
return $res.Items
}


function GetRuleLite($rule)
{
$ruleLite = New-Object PSObject -Property @{
       	        Id = $Rule.Id
               	Name = $Rule.Name
		Enabled = $Rule.Enabled
		UsesUnlicensedFragment = $Rule.UsesUnlicensedFragment
                }
return $ruleLite
}

################### begin scope parser functions #########################

function normaliseToken($tok)
{
# trim leading and trailing spaces, normalise embedded spaces to a single space
    $tok = $tok -replace "^\s+|\s+$",""
    return $tok -replace "\s+"," "
}

# returns $null for end of tokens and "" for a bad token otherwise next token

function getNextToken($in,[ref]$pos)
{
$p = $pos.Value
if ($null -eq $in -or $p -ge $in.Length)
    {
    return $null
    }
while ((peek $in $p) -eq " " -and $p -lt $in.Length)
    {
    $p++
    }
if ($p -ge $in.Length)
    {
    $pos.Value = $p
    return $null
    }

if ((restofline $in $p) -match "^(\(|\)|==?|<>|!=|>=?|<=?|\s+like\s+|\s+not\s+like\s+|\s+in\s+|\s+not\s+in\s+|\s+is\s+null\s+|\s+is\s+not\s+null\s+)") #operator
    {
    $p += $matches[1].length
    $pos.Value = $p
    return normaliseToken $matches[1]
    }

#support word chars plus -,:,. and \ for atoms or anything inside square brackets - we also support embedded commas in order to handle IN value lists
if ((restofline $in $p) -match "^([\w\-\:\.\\%,]+|\[.*?\])(\W+|$)") #atom
    {
    $p += $matches[1].length
    $pos.Value = $p
    $m = $matches[1]
    # literals can have spaces if escaped with square brackets
    if ($m.Substring(0,1) -eq "[" -and $m.substring($m.Length - 1 ,1) -eq "]")
        {
        $m = $m.substring(1,$m.length - 2)
        }
    return $m
    }

$pos.Value = $p
return ""
}

function peek($in,$pos)
    {
    return $in.substring($pos,1)
    }

function restofline($in,$pos)
    {
    return $in.substring($pos,$in.length - $pos)
    }

function isBoolean($in)
{
if ($in -match "^(and|or|not)$")
    {
    return $true
    }
return $false
}

function isComparison($in)
{
if ($in -match "^(==?|<>|!=|>=?|<=?|like|not like|in|not in|is null|is not null)$")
    {
    return $true
    }
return $false
}

function isOperator($in)
{
if ((isBoolean $in) -or (isComparison $in))
    {
    return $true
    }
return $false
}

function isAtom($in)
{
if ($in -match "^([\w\-\.%]+)$")
    {
    return $true
    }
return $false
}

# only one function currently implemented - NOT

function isFunction($in)
{
if ($in -eq "not")
    {
    return $true
    }
return $false
}

function isTerm($in)
{
if (-not (isOperator $in) -and (-not (isParen $in)))
    {
    return $true
    }
return $false
}

function isParen($in)
{
    if ($in -eq "(" -or $in -eq ")")
        {
        return $true
        }
    return $false
}


function translateOperator($in)
{
if ($in -eq "=")
    {
    return "=="
    }
return $in
}

function isSpecialOp($tok)
{
if ($tok -match "is null|is not null")
    {
    return $true
    }
return $false
}

function processToken($tok, $outq, $opstack)
    {
    $opPrecedence = @{"not" = 4; "=" = 3; "==" = 3; ">" = 3; "<" = 3; "<>" = 3; "!=" = 3; ">=" = 3; "<=" = 3; "like" = 3; "not like" = 3; "in" = 3; "not in" = 3; "is null"=3; "is not null"=3; "and" = 2; "or" = 1}
    if (isTerm $tok)
        {
        $outq.enqueue($tok)
        return
        }
   
     if (isFunction $tok)
        {
        $opStack.Push($tok)
        return
        }
            
     if (isOperator $tok)
        {
        if ($opStack.Count -gt 0) 
            {
            $tos = $opStack.Peek()
            while (($opStack.Count -gt 0) -and ((isOperator $tos) -and ($opPrecedence[$tos] -gt $opPrecedence[$tok])) -and ($tos -ne "("))
                {
                $outq.enqueue($opStack.Pop())
                if ($opStack.Count -gt 0)
                    {
                    $tos = $opStack.Peek()
                    }
                else
                    {
                    $tos = $null
                    }
                }
            }

        $opStack.Push($(translateoperator $tok))
        # for some operators like 'is null' 'is not null' we push an empty value onto the stack as a comparison, since the APIs processing expression trees disregards these
        if (isSpecialOp $tok)
            {
            $outq.enqueue("")
            }
     
        return        
        }

     if ($tok -eq "(")
        {
        $opstack.push($tok)
        return
        }

     if ($tok -eq ")")
        {
        while ($opStack.Peek() -ne "(")
            {
            if ($opStack.Count -eq 0)
                {
                throw "mismatched parentheses in expression"
                }
            $outq.Enqueue($opStack.Pop())
            }
        $opStack.Pop()
        }
    }

function toScopeTerm($operator, $operands)
{
$scopeTerm = "{`r`n" + (quotify "Operator") + ":" + (quotify $operator.ToUpper()) + ",`r`n" +
                (quotify "Operands") + ":[`r`n"

$notfirst = $false
foreach ($operand in $operands)
    {
    if ($notfirst)
        {
        $scopeTerm += "," + (getExpr $operand)
        }
    else
        {
        $notFirst = $true
        $scopeTerm += (getExpr $operand)
        }
    }  
$scopeTerm += "]`r`n}`r`n"      
return $scopeTerm            
}

function toScopeOperand($operand)
{
    $scopeTerm = "{`r`n" + (quotify "Attribute") + ":" + (quotify $operand.Attribute) +  ",`r`n"  + 
                        (quotify "Operator") + ":" + (quotify $operand.Operator) +  ",`r`n"  + 
                        (quotify "Value") + ":" + (quotify $operand.Value) +  "`r`n}`r`n"
    return $scopeTerm
}

function getExpr($operand)
{
if ($null -ne $operand.Expr)
    {
    return $operand.Expr
    }
return toScopeOperand $operand
}

function rpnToScope($rpn)
{
$operands = New-Object Collections.Generic.Stack[Object]

$currentOperand = new-object PSObject -Property @{
    Attribute=$null 
    Operator=$null
    Value=$null
    Expr=$null
    }


foreach ($item in $rpn)
    {
    if (isBoolean $item)
        {

        if ($item -ne "not")
            {
                $tos = $operands.Pop()
                $arg = $operands.Pop()
               $tos.Expr = toScopeTerm $item  @($tos,$arg)
            }
        else
            {
               $tos = $operands.Pop()
               $tos.Expr = toScopeTerm $item @($tos)
            }

        $operands.Push($tos)
        continue
        }

    if (isOperator $item)
        {
        # we have an operand term. This completes the tuple {attribute,value,operand} so we can now push this onto the stack and create a new current operand object

        $currentOperand.Operator = $item
        # handle the special case of tagtxt scope attributes [we'll assume a filter expression probably never uses a column called tagtxt since this code is reused]
        if ($currentOperand.Attribute -eq "tagtxt")
            {
            $currentOperand.Operator = ""
            }
        $operands.push($currentOperand)
        $currentOperand = new-object PSObject -Property @{
            Attribute=$null 
            Operator=$null
            Value=$null
            Expr=$null
        }

        continue
        }

    #assume we always get the attribute and then the value i.e foo=2 and not 2=foo. Otherwise this would fail, but no reasonable person would type that in.	
    if ($null -eq $currentoperand.attribute)
        {
        $currentOperand.Attribute = $item
        continue
        }

    # else must be value
        $currentOperand.Value = $item
    }
    $tos = $operands.Pop()
    return getExpr $tos
}

# this is the primary parser function; it takes a human-readable expression and returns scope or filter JSON

function exprToJson($expr)
{

$outq = new-object Collections.Generic.Queue[string]
$opstack = new-object Collections.Generic.Stack[string]

   

$p = 0
$tok = getNextToken $expr ([ref]$p)
if ($tok -eq "")
    {
    throw "unexpected token parsing " + $expr
    }
while ($null -ne $tok)
    {
    [void](processToken $tok $outq $opstack) #cast to void or it writes to the output stream which'll drive you crazy trying to debug why results are wrong
    $tok = getNextToken $expr ([ref]$p)
    if ($tok -eq "")
        {
        throw "unexpected token parsing " + $expr
        }
    }

while ($opStack.Count -gt 0)
    {
    $v = $opStack.Pop()
    if (isParen $v)
        {
        throw "mismatched parentheses in expression"
        }
    $outq.Enqueue($v)
    }


$scope = (rpnToScope $outq)
return $scope
}


################### end scope parser functions ###########################

function getParentJson($ParentId)
{
if ($ParentId -eq 0)
    {
    return "null"
    }
else
    {
    return '{"Id" : ' + $ParentId + '}'
    }
}

function BuildRuleParams($paramsRaw)
{
$params = New-Object System.Collections.Generic.List[System.Object]

foreach ($p in $paramsRaw)
    {
    $param = New-Object PSObject -Property @{
                            Name = $p.Name
                            Value = $p.Value
                            }
    [void]$params.add($param)
    }
return $params
}

function BuildDynamicFragParams($dict, $frag, $OFFSET)
{
    if (-not (IsNullOrEmpty $frag.ParameterJson))
        {
        $fragParams = $frag.ParameterJson | convertfrom-json
        return BuildDynamicParamsForRule $dict $frag.Name $fragParams $OFFSET
        }
}

function ProcessDynamicArgsForRule($triggerTemplateId, $checkFragmentId, $PreconditionFragmentId, $FixFragmentId, $OFFSET)
{
    $dict = new-object System.Management.Automation.RuntimeDefinedParameterDictionary
    $paramList = New-Object System.Collections.Generic.List[System.Object]
    if (($null -ne $triggerTemplateId) -and (($triggerTemplateId -ne 0) -or ($triggerTemplateId.Count -gt 0)))
    {
    foreach ($tempId in $TriggerTemplateId)
        {
        $trig = get-triggertemplate -id $tempId
        $params = BuildDynamicParamsForRule $dict $trig.Name $trig.UserParameters $OFFSET 
        foreach ($p in $params)
            {
            [void]$paramList.Add($p)
            }
        }
    }
    if (($null -ne $CheckFragmentId) -and ($CheckFragmentId -ne 0))
        {
        $checkfrag = get-fragment -id $CheckFragmentId
        if ($checkfrag.type -ne 1)
            {
            throw "The specified fragment is not a check fragment"
            }

        $params = BuildDynamicFragParams $dict $CheckFrag $OFFSET
        foreach ($p in $params)
            {
            [void]$paramList.Add($p)
            }
        }
    if (($null -ne $PreconditionFragmentId) -and ($PreconditionFragmentId -gt 0))
	{
        $preconfrag = get-fragment -id $PreconditionfragmentId
        if ($preconfrag.type -ne 3)
            {
            throw "The specified fragment is not a precondition fragment"
            }

	    $params = BuildDynamicFragParams $dict $PreconFrag $OFFSET
	    foreach ($p in $params)
		    {
		    [void]$paramList.Add($p)
		    }
	}

    if ($null -ne $FixFragmentId -and $FixFragmentId -gt 0)
	{
        $fixfrag = get-fragment -id $FixFragmentId
        if ($fixfrag.type -ne 2)
            {
            throw "The specified fragment is not a fix fragment"
            }

	    $params = BuildDynamicFragParams $dict $FixFrag $OFFSET
	    foreach ($p in $params)
		    {
		    [void]$paramList.Add($p)
		    }
	}
    $ret = New-Object PSObject -Property @{
        Dict = $dict
        Metadata = $paramList
        }
    return $ret
}

# builds an updateable rule model that will be accepted by the rule update API from a raw rule model returned by the API
function BuildUpdateableRuleModel($rule)
{
$trigs = New-Object System.Collections.Generic.List[System.Object]

foreach ($trigger in $rule.Triggers)
    {
    $trig = New-Object PSObject -Property @{
            TriggerTemplateId = $trigger.TriggerTemplateId
            UserParameters = @(BuildRuleParams $trigger.UserParameters) # note coercion to array for all these calls; this is so a single element result is correctly stored as an array of one element
            }
    [void]$trigs.add($trig)
    }

$model = New-Object PSObject -Property @{
            Id = $rule.Id
            Type = $rule.Type
            Name = $rule.Name
            Description = $rule.Description
            PreConditionFragmentId = $rule.PreconditionFragment.Id
            PreConditionParameters = @(BuildRuleParams $rule.PreconditionParameters)
            FixFragmentId = $rule.FixFragment.Id
            FixParameters = @(BuildRuleParams $rule.FixParameters)
            CheckFragmentId = $rule.CheckFragment.Id
            CheckParameters = @(BuildRuleParams $rule.CheckParameters)
            Triggers=$trigs
            Enabled=$rule.Enabled
            }
return $model
}

function MapPrincipal($SourceName, $DomainMapping, $UserMapping)
{
# is sourcename in domain\user format?. If not, return unchanged
if (-not $sourcename.contains("\"))
	{
	return $sourceName
	}
$useranddomain = $sourcename.split("\")
$domain = $useranddomain[0]
$user = $useranddomain[1]

if (IsNullOrEmpty $UserMapping)
	{
	# Users map directly
	$mappedUser = $user
	}
else
	{
	if ($UserMapping.gettype().Name -eq "HashTable")
		{
		# hash mapping, if user portion of the source name matches, then if there is a mapped entry, remap to that otherwise return original source name unchanged
		$mappedUser = $UserMapping[$user]
		if (IsNullOrEmpty $mappedUser)
			{
			return $sourceName
			}
		}
	}

if ($DomainMapping.gettype().Name -eq "string")
	{
	# simple mapping, everybody maps to the same UPN suffix
	$mappedName = $mappeduser + "@" + $DomainMapping
	return $mappedName
	}
else
	{
	if ($DomainMapping.gettype().Name -eq "HashTable")
		{
		# hash mapping, we should have a set of key = value entries
		# If the domain portion of the source name matches, then if there is a mapped entry, remap to that, otherwise return original source name unchanged
		$mappedDomain = $DomainMapping[$domain]
		if (IsNullOrEmpty $mappedDomain)
			{
			return $sourceName
			}
		}
		return $mappedUser + "@" + $mappedDomain
	}


return $SourceName
}

function GetPrincipalMaps($DomainMapping, $UserMapping, $fileMapping)
{
	$mapHash = @{}
	$principals = get-principal
    if (-not (IsNullOrEmpty $fileMapping))
        {
       	foreach ($principal in $principals)
		    {
		    $pname = $principal.PrincipalName
            $toname = $fileMapping[$pname]
            if ($null -eq $toname)
                {
                $toname = $pname
                }
            $mapHash[$pname] = $toname                            
            }
            return $mapHash
        }

# otherwise use passed mapping hashtables to map

	foreach ($principal in $principals)
		{
		$pname = $principal.PrincipalName
        $mapHash[$pname] = MapPrincipal $pname $DomainMapping $UserMapping
		}
    	return $mapHash
}

function UpdatePrincipalMaps($mapList, $whatIf)
{
    $principals = get-principal | where-object {(-not $_.SystemPrincipal) -and (-not $_.IsGroup)}
    if ($whatIf)
        {
        $maps = @{}
        }
    foreach ($principal in $principals)
        {
        $fromName = $principal.PrincipalName
        $toName = $mapList[$fromName]
        if ($null -ne $fromName -and $toName -ne $fromName)
            {
            try
                {
                if ($whatIf)
                    {
                    write-host "would update principal -id " $principal.Id " -Account " $fromName  " -PrincipalName " $toName
                    $maps[$fromName] = $toName
                    }
                else
                    {
                    update-principal -id $principal.Id -PrincipalName $toName
                    }
                }
            catch
                {
                write-host "Error occurred updating principal account name for Id: " $principal.Id "to name: " $toName " Error reported was:- "  $_
                }
            }
        }

    if ($whatIf)
        {
        return $maps
        }
}

function MapListToCsv($mapList, $outPath)
{
$maps = New-Object System.Collections.Generic.List[System.Object]
foreach ($key in $mapList.Keys)
    {
    $a = [ordered] @{
	    From = $key
        To = $mapList[$key]
        }
    $m = New-Object PSObject -Property $a
    [void]$maps.add($m)
    }
    $t = $maps | convertto-csv -NoTypeInformation | Select-Object -Skip 1 | set-content -Path $OutPath
    return
}

#################### end of internal helper functions ####################

#################### exported cmdlet functions only below this point ####################

function Get-SLAManagementGroupRule
{
<#
.SYNOPSIS

Parses a management group rule expression and returns each term as an object. 


.PARAMETER Expression

Specifies the expression to be translated into a set of rules

.EXAMPLE

Get-1ESLAManagementGroupRule -Expression "[ReportProductCatalog.Vendor] = Vendor1 or [ReportProductCatalog.Vendor] = Vendor2" 

.NOTES

Expression entities such as Product Catalog Vendor can be delimited either by quotes or square brackets. To obtain a list of valid entities, use the Get-1ESLAManagementGroupRuleAttribute cmdlet

#>
[CmdletBinding()]
Param(
     [Parameter(Mandatory=$true)] [string]$Expression
     )

$rules = get-Scope -TargetScope $Expression
return $rules

}



function Remove-SLAManagementGroup
{
[CmdletBinding()]
Param
    (
    [Parameter(Mandatory=$true)] [int]$Id
    )
    $url="/Admin/ManagementGroupsEx"
    $payload=@"
    {
    "ManagementGroupId": $Id
    }
"@
    $res = DeleteHttpRequest $url $payload
    return $res
}

function Set-ProxyCredentials
{
<#
.SYNOPSIS

Sends account credentials to the platform Proxy Server for storage. The proxy will then use these credentials if configured appropriately, when forwarding requests to the platform.


.PARAMETER Credential

Specifies the credentials to be stored. If not passed as a pre-existing credentials object, you will be securely prompted for them

.PARAMETER ApiToken

The Api Token which authorises credential storage. Note that this is not the same token value as is used for other proxy communications, for security reasons. You should obtain this from the proxy administrator

.NOTES

For security reasons this cmdlet will not return details of any failure. Consult the proxy log file if necessary when troubleshooting.

#>
[CmdletBinding()]
Param(
     [Parameter(Mandatory=$true)] [PSCredential]$credential,
     [Parameter(Mandatory=$true)] [string]$ApiToken
     )
# get the credentials and build a string from them
$nwcreds = $credential.GetNetworkCredential()
$acct = $nwcreds.Domain + "\\" + $nwcreds.UserName
$payload = @"
	{
	"Account" : "$($acct)",
	"Password" : "$($nwcreds.Password)"
	}
"@

$url = "/Home/StoreCredentials"
$addHeaders = @{
        "X-Credential-Token" = "$($ApiToken)"
	}

$res = PostHttpRequest $url $payload $addHeaders
return $res
}

function Set-Server
{
	
<#
.SYNOPSIS

Sets the platform server

.PARAMETER Server
Specifies the URL of the platform server to use

.PARAMETER ApiToken
Specifies the API token to be used when connecting to the Platform Proxy Server instead of directly to the platform

.PARAMETER Credential
Specifies a PowerShell credential which will be used to connect to the platform server when Windows authentication is configured on the server
If not specified, then the connection is made in the context of the current user account

.PARAMETER AppId
Specifies the application Id of an identity provider used to authenticate

.PARAMETER CertSubject
If an application Id is specified, defines the subject of a certificate in the local machine personal cert store used to sign authentication tokens. This certificate must be associated with the application on the identity provider whose Id was provided in the AppId parameter

.PARAMETER CertThumbprint
If an application Id is specified, defines the thumbprint of a certificate in the local machine personal cert store used to sign authentication tokens. This certificate must be associated with the application on the identity provider whose Id was provided in the AppId parameter

.PARAMETER Principal
If supplied, specifies the principal (as a UPN e.g bob.smith@acmecorp.com) that the authentication token is associated with.

.PARAMETER UseBasicAuth
If supplied, specifies that the connection to the platform server or proxy be made using basic authentication over HTTPS. You must specify appropriate account credentials using the -Credential parameter if using this option

.PARAMETER BypassAuth
If supplied, skips all authentication and just sets the internal location of the platform server. This is intended for troubleshooting purposes when testing platform configuration

.PARAMETER AsPlatform
If supplied, requests that the connection be made as a platform component. The supplied certificate subject or thumbprint must refer to a suitable certificate in the local machine personal cert store that can be used to sign a platform token assertion

.PARAMETER KeyVaultUrl
If supplied, specifies the URL to the Azure keyvault from which the signing certificate for authentication is to be retrieved.
for example, mykeyvault.vault.azure.net

.PARAMETER ManagedIdentity
If supplied, specifies the managed identity under which the Azure keyvault will be accessed; this parameter is mandatory if the KeyVaultUrl parameter is specified. Example: 4022133b-af0a-4c19-bf27-64f68db5aae5

.PARAMETER CertName
If supplied, specifies the name of the certificate in the Azure keyvault to be used to sign the authentication request
Example: Corellian. Note that this is NOT the subject of the certificate, as the Azure Key Vault stores certificates by an independent name

.EXAMPLE

Set-1EServer myserver.urth.local

.NOTES
To be prompted for a set of credentials when using the -Credential option, you can specify -Credential (get-credential) on the command line. Or you can store them in a variable and pass that

When specifying a Principal, there must be appropriate certificate mapping entries for that principal. See the add-1Ejwtprincipalmapping cmdlet documentation for more details on certificate mapping

Azure Key Vault retrieval is not supported for legacy PowerShell and an exception is thrown.
For Azure Key Vault retrieval you must have copies of the following assemblies in the folder in which the PS toolkit runs. These are not currently
supplied with the toolkit. You can obtain these by using the nuget install-package cmdlet and then copying the appropriate DLLs for the framework in use to the local folder. Note that you may need the -SkipDependencies option when using install-package to avoid the reporting of dependency loops

The assemblies required are:-

Azure.Identity.dll
Azure.Security.KeyVault.Certificates.dll
Azure.Security.KeyVault.Secrets.dll
Azure.Core.dll
Microsoft.Identity.Client.dll

#>

[CmdletBinding()]
Param(
     [Parameter(Mandatory=$true)] [string]$Server,
     [Parameter(Mandatory=$false)] [string]$ApiToken,
     [Parameter(Mandatory=$false)] [PSCredential]$Credential,
     [Parameter(Mandatory=$false)] [string]$AppId,
     [Parameter(Mandatory=$false)] [string]$CertSubject,
     [Parameter(Mandatory=$false)] [string]$CertThumbprint,
     [Parameter(Mandatory=$false)] [switch]$AsPlatform,
     [Parameter(Mandatory=$false)] [string]$Principal,
     [Parameter(Mandatory=$false)] [switch]$UseBasicAuth,
     [Parameter(Mandatory=$false)] [switch]$BypassAuth,
     [Parameter(Mandatory=$false)] [string]$KeyVaultUrl,
     [Parameter(Mandatory=$false)] [string]$ManagedIdentity,
     [Parameter(Mandatory=$false)] [string]$CertName
     )
$script:TACHYONURL = $server
$script:TACHYONVER = ""
$script:CLIENTCERT = $null
$script:USEPROXY = $false
$script:CREDENTIAL = $credential
$script:USEBASICAUTH = $false
$script:AUTHTOKEN = GetEmptyToken
$script:PROXYVIANTLM = $false

if ($BypassAuth)
    {
    return
    }

if (-not (IsNullOrEmpty $KeyVaultUrl))
	{
	if ((IsNullOrEmpty $ManagedIdentity) -or (IsNullOrEmpty $CertName))
		{
		throw "You must specify a managed identity and certificate name when specifying an Azure credential vault URL"
		}
	}


# See if we are connecting via the proxy. If we are, then if a subsequent call to retrieve consumer info succeeds, the proxy is transparently
# negotiating NTLM inbound to platform-neutral auth outbound.
# In that case we need do nothing else. Note: we don't set USEPROXY. This is because the proxy is managing authentication outbound for us, and so we rely only on our NTLM credentials, just as we would if connecting to a legacy system directly
if ($UseBasicAuth)
    {
    if (IsNullOrEmpty $Credential)
        {
        throw "You must specify credentials when connecting via basic authentication"
        }
    $script:USEBASICAUTH = $true
    }
try
    {
    $res = GetProxyInfo
    # If this throws, either we're not connecting to the proxy or it wanted a client cert
    # Otherwise, we now try and get consumer info. If that succeeds, we are in with NTLM auth (or possibly basic auth) and the proxy will be transparent
    # Otherwise we need to supply an API token
    try
        {
        $res = GetConsumerInfo
        setServerInfo $res
        if ($script:USEBASICAUTH)
            {
            write-information -MessageData ([string](get-date) + " Successfully connected to proxy using basic authentication inbound")
            }
        else
            {
            $script:PROXYVIANTLM = $true
            write-information -MessageData ([string](get-date) + " Successfully connected to proxy using NTLM authentication inbound")
            }
        return
        }
    catch
        {
        # Some other error implies proxy would like an API token
        if (IsNullOrEmpty $ApiToken)
            {
            throw "Proxy did not connect via NTLM authentication or client certs, and no Api Token was supplied"
            }
        $script:USEPROXY = $true #assume we did reach the proxy but it requires alternative authentication to NTLM
        $script:PROXYAPITOKEN = $ApiToken
        $script:CLIENTCERT = $null
        try
            {
            $res = GetConsumerInfo
            setServerInfo $res
            write-information -MessageData ([string](get-date) + " Successfully connected to proxy using supplied API token")
            return
            }
        catch
            {
            throw "Proxy did not connect with the supplied API token. Error reported was: " + $_;
            }
        }        
    }
catch
    {
    # either not connected to proxy or we needed a client cert; error code will tell us which
    if ($_.ToString().ToLower().Contains("error 403.7"))
        {
        # proxy exists but requires client cert
        # try client certs
        $script:USEPROXY = $true
        if (ConnectProxyWithClientCerts)
             {
             $res = GetConsumerInfo
             setServerInfo $res
             write-information -MessageData ([string](get-date) + " Successfully connected to proxy using client certificate")
             return
             }
             $script:USEPROXY = $false
             throw "Proxy requires client certificate but no suitable certificate was found"
        }
    }

# If we drop through to here we are not connecting via the proxy

# are we connecting directly to a modern-auth capable server?. If so then we MUST authenticate using modern auth 
# (if the server supports the metadata endpoint but returns no data, we can assume it's modern-auth capable but not configured to enable modern auth and so we drop through)

try
    {
    try
        {
        write-information -MessageData ([string](get-date) + " Attempting to retrieve metadata endpoint for identity provider")
	# On Win Server 2016, Azure may reject the request unless TLS 1.2 is used. We don't want to jigger with TLS default choices unless necessary, so if this throws, we'll
	# try forcing 1.2 and retry
	# Note: when connecting for SaaS provisioning we might hit a server which DOES have a metadata endpoint but which has NOT yet had its IdP configured. In this case we want to succeed but only if the -AsPlatform param is specified
	# since in that case we can get a platform token regardless.

	try
		{
		$metadataEndpoint = GetMetadataEndpoint
        	write-information -MessageData ([string](get-date) + " Retrieved metadata endpoint: " + $metadataEndpoint)
		try
			{
		        $tokenEndpoint = GetTokenEndpoint $metaDataEndpoint
        		write-information -MessageData ([string](get-date) + " Retrieved token endpoint: " + $tokenEndpoint)
			}
		catch
			{
        		write-information -MessageData ([string](get-date) + " Error attempting to retrieve token endpoint from metadata endpoint, Error was: " + $_)
			}
		}
	catch
		{
		write-information -MessageData ([string](get-date) + " Error reported connecting to metadata endpoint. Will retry with TLS 1.2 forced")
		# force TLS 1.2. We need to preserve current setting because with some OS versions in the PowerShell ISE debugging environment, the returned value isn't SystemDefault
		# which otherwise you would normally be able to reset to.
		$script:CURRENTTLSSETTING = [Net.ServicePointManager]::SecurityProtocol
		[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 
		$metadataEndpoint = GetMetadataEndpoint
        	write-information -MessageData ([string](get-date) + " Retrieved metadata endpoint: " + $metadataEndpoint)
		try
			{
		        $tokenEndpoint = GetTokenEndpoint $metaDataEndpoint
        		write-information -MessageData ([string](get-date) + " Retrieved token endpoint: " + $tokenEndpoint)
			}
		catch
			{
        		write-information -MessageData ([string](get-date) + " Error attempting to retrieve token endpoint from metadata endpoint, Error was: " + $_)
			}

        	write-information -MessageData ([string](get-date) + " Retrieved endpoint: " + $tokenEndpoint)
		}
        }
    catch
        {
        # not platform-neutral auth. The test below will fail and we will drop through to try other options
	# Reset TLS level to default as we changed it to 1.2 to try and connect. 
	if (-not (IsNullOrEmpty $script:CURRENTTLSSETTING))
		{
		[Net.ServicePointManager]::SecurityProtocol = $script:CURRENTTLSSETTING
	       	write-information -MessageData ([string](get-date) + " Reset TLS level to default")
		}
       	write-information -MessageData ([string](get-date) + " Retrieved endpoint: " + $tokenEndpoint)
        write-information -MessageData ([string](get-date) + " Unable to retrieve metadata endpoint for identity provider, will fall through to other authentication mechanisms")
        }
# have to have at least metadata endpoint if trying to get platform token, otherwise, must have token endpoint for full modern auth
    if (((-not (IsNullOrEmpty $metadataEndpoint) -and ($AsPlatform)) -or (-not (IsNullOrEmpty $tokenEndpoint))))
        {
        # assume modern auth if this does not throw and returns something. 
        # If we are connecting via the proxy, then this will also have done the authentication for us and we are either using NTLM auth inbound or a persistent API key or a cert.

        if (-not (IsNullOrEmpty $appId) -or $AsPlatform)
            {
            # If we specified Azure KeyVault get cert from there
    	    if (-not (IsNullOrEmpty $KeyVaultUrl))
		{
		$cert = Get-CertificateFromKeyVault $KeyVaultUrl $ManagedIdentity $CertName
		}  		

	    if ($AsPlatform)
		{
		    #get a platform token
		    if (-not (IsNullOrEmpty $CertThumbprint))
			{
			    $authToken = get-PlatformToken -CertThumbprint $CertThumbprint
			}
	            else
			{
			    if (-not (IsNullOrEmpty $cert))
				{
				$authToken = get-PlatformToken -Certificate $Cert
				}
			    else
				{
			        $authToken = get-PlatformToken -CertSubject $CertSubject
				}
			}

		}
	    else
		{
	          try
        	        {
			if (IsNullOrEmpty $cert)
				{
				# thumbprint has precedence over certsubject, I'm not bothering to gate them exclusively
				if (-not (IsNullOrEmpty $CertThumbprint))
					{
					$cert = GetCertByThumbprint $CertThumbprint
					}
				else
					{
			    	        $cert = GetCertBySubject $CertSubject	
					}
				}
        	        }
            	catch
                	{
	                throw "Unable to retrieve certificate by subject: " + $CertSubject + " or by thumbprint: " + $CertThumbPrint + ", Error returned was: " + $_
        	        }
		    #get an auth token using a JWT (external integration)	
	            $authToken = GetAuthToken $cert $principal $tokenEndpoint $AppId
		}
            $authTokenDecoded = DecodeAuthToken $authToken
    	    $script:AUTHTOKEN = New-Object PSObject -Property @{
			Token = $authToken
			ExpiryTime = GetTokenExpiryUTC $authToken
			IssueAppId = $AppId
			IssueCertSubject = $CertSubject
			IssueCertThumbPrint = $CertThumbprint
			IssuePrincipal = $authTokenDecoded.UserName # this is NOT necessarily the requested principal due to mapping
			TokenType = $authTokenDecoded.Type
	    }
            $res = GetConsumerInfo
            setServerInfo $res
            return
            }
        else
            {
            # If we did not have an appId, or were requesting a platform token, try interactive login instead
            write-information -MessageData ([string](get-date) + " Attempting to interactively authenticate with identity provider")
            $tok = GetInteractiveToken $Server
		$authTokenDecoded = DecodeAuthToken $tok
	        $script:AUTHTOKEN = New-Object PSObject -Property @{
			Token = $tok
			ExpiryTime = GetTokenExpiryUTC $tok
			IssueAppId = $null
			IssueCertSubject = $null
			IssueCertThumbprint = $null
			IssuePrincipal = $authTokenDecoded.UserName
			TokenType = $authTokenDecoded.Type
		}
            write-information -MessageData ([string](get-date) + " Authentication token retrieved successfully")
            $res = GetConsumerInfo
            setServerInfo $res
            }
        }
}
catch
    {
    $errmsg = "An error was reported while attempting platform-neutral authentication. Error was: " + $_
    write-information -MessageData ([string](get-date) + " " + $errmsg)
    throw $errmsg
    }

# We are not connecting via the proxy, or directly to a modern auth server, so this must be a direct connection to a legacy NTLM server

try
    {
    # This call to the platform requires no authorization (i.e RBAC permissions). If it succeeds, we're talking directly to the platform
    write-information -MessageData ([string](get-date) + " Attempting connection to platform via NTLM authentication")
    $res = GetConsumerInfo
    write-information -MessageData ([string](get-date) + " NTLM connection succeeded")
    setServerInfo $res
    return
    }
catch
    {
    throw "Unable to connect to the platform server directly using NTLM authentication. Error reported was: " + $_
    }
}

function Get-CertificateFromKeyVault
{
<#
.SYNOPSIS

Retrieves an X509 certificate from the Azure Key Vault

.EXAMPLE

Get-1ECertificateFromKeyVault

.PARAMETER KeyVaultUrl
Specifies the Url to the Key Vault (e.g mykeyvault.vault.azure.net)

.PARAMETER ManagedIdentity
Specifies the managed identity to be used to retrieve the certificate from the key vaule

.PARAMETER CertName
Specifies the certificate name to be retrieved

.NOTES
See the notes regarding the Azure Key Vault for the Set-1EServer cmdlet.

#>

[CmdletBinding()]
Param(
  [Parameter(Mandatory=$true)] [string]$KeyVaultUrl,
  [Parameter(Mandatory=$true)] [string]$ManagedIdentity,
  [Parameter(Mandatory=$true)] [string]$CertName
)
$fullUrl = "https://" + $KeyVaultUrl
$cert = GetCertFromAzureVault $fullUrl $ManagedIdentity $CertName
return $cert
}

function Get-AuthToken
{
<#
.SYNOPSIS

Retrieves the current authentication token (if any).

.EXAMPLE

Get-1EAuthToken

.PARAMETER Decode
If specified, decodes the token (discarding the signature portion) and returns it as a PowerShell object

.NOTES

An authentication token is only returned if authentication has been performed via platform-neutral authentication

#>
[CmdletBinding()]
Param(
  [Parameter(Mandatory=$false)] [switch]$Decode
)
if ($Decode)
	{
    return DecodeAuthToken $script:AUTHTOKEN.Token
	}
return $script:AUTHTOKEN
}


function Get-Server
{
<#
.SYNOPSIS

Gets the current platform server

.EXAMPLE

Get-1EServer 

#>

[CmdletBinding()]
Param()
return $script:TACHYONURL
}


function Set-DefaultConsumer
{
	
<#
.SYNOPSIS

Sets the default platform consumer to be used when communicating via the platform API

.EXAMPLE

Set-1EDefaultConsumer Explorer

.PARAMETER Name
Specifies the name of the consumer to be used
#>

[CmdletBinding()]
Param(
     [Parameter(Mandatory=$true)] [string]$Name
     )

[void](Get-Consumer -Name $Name) #just to ensure that the consumer is valid, will throw if not

$script:TACHYONCONSUMER = $Name
}

function Get-DefaultConsumer
{
<#
.SYNOPSIS

Gets the current default consumer used when communicating via the platform API

.EXAMPLE

Get-1EDefaultConsumer

#>

[CmdletBinding()]
Param()
return $script:TACHYONCONSUMER
}

function Get-ToolkitVersion
{
<#
.SYNOPSIS

Gets the release of the PowerShell toolkit

.EXAMPLE

Get-1EToolkitVersion

#>

[CmdletBinding()]
Param()
return $script:TOOLKITVERSION
}



function Get-Version
{
<#
.SYNOPSIS

Gets the current platform server version

.EXAMPLE

Get-1EVersion

#>

[CmdletBinding()]
Param()
return $script:TACHYONVER
}



# NOTE: You cannot debug this function in the PowerShell ISE. It does not support the single char get requests made while searching

function Search-Instruction
{
<#
.SYNOPSIS

Interactively searches for a platform instruction

.NOTES

You cannot debug this function in the PowerShell ISE. It does not support the single character console get requests made while searching

.EXAMPLE

Search-1EInstruction

.EXAMPLE

Search-1EInstruction -CreateCmdlet

.EXAMPLE

Search-1EInstruction -Targetscope "fqdn like %endpoint1% or fqdn like %endpoint2%"

.EXAMPLE

Search-1EInstruction -TargetFqdns @("endpoint1.mydomain.local","endpoint2.mydomain.local")


.PARAMETER PromptDefaults
Specifies that instruction parameters with defaults should be prompted for

.PARAMETER Drilldown
Specifies that aggregating instruction results should be displayed as detail results rather than aggregated (the default)

.PARAMETER CreateCmdlet
Specifies that instead of executing the instruction when it is selected from the search list, a Powershell cmdlet should be created from it instead

.PARAMETER Export
Specifies that the instruction results should be exported to a file

.PARAMETER TargetScope
Specifies the scope of the target. The scope defines attributes such as fqdns, operating system version etc associated with the endpoints to which the instruction should be sent when executed

.PARAMETER TargetFqdns
Specifies one or more endpoint fqdns which will be the targets of the instruction selected. This parameter is mutually exclusive with TargetScope


#>

[CmdletBinding(DefaultParameterSetName='TargetScope')]

Param(
     [Parameter(Mandatory=$false)] [switch]$PromptDefaults=$false,
     [Parameter(Mandatory=$false)] [switch]$Drilldown=$false,
     [Parameter(Mandatory=$false)] [switch]$CreateCmdlet=$false,
     [Parameter(Mandatory=$false)] [switch]$Export=$false,
     [Parameter(Mandatory=$false, ParameterSetName='TargetScope')] [string]$TargetScope,
     [Parameter(Mandatory=$false, ParameterSetName='TargetFqdns')] [string[]]$TargetFqdns
     )

$e = [char]27
$greeting = "$e[0;0f$e[2J$e[7mPlatform Search: Enter instruction description to search interactively->$e[0m$e[3;0f" #clear screen and go home, inverse, prompt, normal, go line 3
write-host $greeting -NoNewLine -ForegroundColor cyan
$line = ""
$lastline = $line
$res = $null
if ($CreateCmdLet -and $Export)
	{
	throw "You cannot specify both -CreateCmdlet and -Export at the same time"
	}

while ($true)
	{
	$retPressed = $false
	$canSelect = $false
	if ($null -ne $res -and $res.Instructions.Count -gt 0 -and $res.Instructions.Count -le 10)
		{
		$canSelect = $true
		}
	
	$line = ProcessSearchChars $line $canSelect  ([ref]$retPressed)

	if ($retPressed -eq $true)
		{
		if ($line -eq "")
			{
			break
			}
		if ($null -ne $res -and ($res.Instructions.Count -eq 1 -or $canSelect -eq $true))
			{
			break
			}
		}
	if ($line -ne $lastline)
		{
		$lastline = $line
		$res = SearchInstructionsByDesc $line
		if ($null -ne $res -and $res.Instructions.Count -ge 1 -and $res.Instructions.Count -le 10)
			{
			$fgColour = "green"
			}
		else
			{
			$fgColour = "cyan"
			}
		write-host $greeting -ForegroundColor $fgColour
		#write-host $line
		write-host "$e[5;0f"
		$index = 0
		foreach ($i in $res.Instructions)
			{
			if ($i.InstructionType -eq 0)
				{
				$fgLineCol = "green"
				}
			else
				{
				$fgLineCol = "darkyellow"
				}
		
			if ($res.Instructions.Count -le 10 -and $res.Instructions.Count -gt 1)
				{
			        write-host $index  ": "  $i.ReadableName -foregroundColor $fgLineCol
				}
			else
				{
				if ($res.Instructions.Count -gt 1)
					{
				        write-host $i.ReadableName 
					}
				else
					{
				        write-host $i.ReadableName  -foregroundColor $fgLineCol
					}
				}
			$index++
			}
	
		$outstr = "$e[3;0f" + $line
		write-host $outstr -NoNewLine #rewrite search text
		}
	}
	# selected an instruction. If rightmost char in line is digit 0 - 9 then this is instruction to run from the list - or if only one instruction, then this is the one to run
	if ($line -eq "" -or ($null -ne $res -and $res.Instructions.Count -eq 1))
		{
		$selIndex = 0
		}
	else
		{
		try
			{
			$selIndex = [int]$line.substring($line.length -1 , 1)
			}
		catch
			{
			$selIndex = 0
			}	
		}

	if (($null -ne $res) -and ($selIndex -lt $res.Instructions.Count) -and ($res.Instructions[$selIndex].Name -ne ""))
		{
		write-host "$e[0;0f$e[2J" # go home,clear
		$instrName = $res.Instructions[$selIndex].Name
		if ($res.Instructions[$selIndex].InstructionType -eq 0)
			{
			$instrType = "Question"
			$fcol = "green"
			}
		else
			{
			$instrType = "Action"
			$fcol = "darkyellow"
			}
		write-host "Instruction Name: " $instrName "[" $instrType "]" -foregroundColor $fcol

		if ($CreateCmdlet -eq $false -and $Export -eq $false)
			{
			$arguments = @{}
			if ($promptdefaults)
				{
				$arguments.Add("PromptDefaults",$true)
				}
			if ($drilldown)
				{
				$arguments.Add("Drilldown",$true)
				}
			if ($targetscope -ne "")
				{
				$arguments.Add("TargetScope",$TargetScope)
				}

			if ($null -ne $TargetFqdns)
				{
				$arguments.Add("TargetFqdns",$TargetFqdns)
				}

			$r = Invoke-Instruction $instrName @arguments
			}
		else
			{
			if ($createCmdlet)
				{
				write-host "Cmdlet to create: " -NoNewLine 
				$cmdlet = read-host
				$r = New-CmdLet -Instruction $instrName -Cmdlet $cmdlet
				return $r
				}
			else
				{
				write-host "Export file name (should have .zip extension): " -NoNewLine 
				$exportFile = read-host
				$r = Export-Instruction -Names $instrName -File $exportFile
				return $r
				}
			}
		}

	return $r
}


function Invoke-Instruction
{
<#
.SYNOPSIS

Invokes a platform instruction

.EXAMPLE

Invoke-1EInstruction 1E-Explorer-TachyonCore-GetCurrentInstalledMemoryDetails


.PARAMETER Instruction

Specifies the name of the instruction to be invoked

.PARAMETER TargetScope

Specifies the scope of the target. The scope defines attributes such as fqdns, operating system version etc associated with the endpoints to which the instruction should be sent when executed

.PARAMETER TargetFqdns

Specifies one or more endpoint fqdns which will be the targets of the instruction selected. This parameter is mutually exclusive with TargetScope

.PARAMETER PromptDefaults

Specifies that instruction parameters with default values will be prompted for


.PARAMETER Drilldown

Specifies that aggregating instruction results should be displayed as detail results rather than aggregated (the default)

.PARAMETER InstTTL

Specifies the instruction time to live in minutes. The instruction terminates when this time is reached

.PARAMETER ResultsTTL

Specifies the instruction results time to live in minutes. Results are deleted from the platform store when this time is reached

.PARAMETER Raw

Specifies that instruction results should be directly written to the file specified. For large result sets this can be faster, and use less memory

.PARAMETER Csv

Specifies that instruction results should be returned as a Csv file. This parameter is mutually exclusive with Raw

.PARAMETER ResultFilter

Specifies a result filter expression that can be used to filter down the results returned

.PARAMETER TargetPercent

Specifies a target percentage of endpoints to be used when performing a staged rollout. TargetFile must be specified for this parameter to take effect

.PARAMETER TargetCount

Specifies a target count of endpoints to be used when performing a staged rollout. TargetFile must be specified for this parameter to take effect. This parameter is mutually exclusive with TargetPercent

.PARAMETER NoWait

Specifies that the cmdlet should return immediately after submitting the instruction, rather than wait for results. The instruction ID is returned as the result.

.PARAMETER DynamicScope

Specifies that the scope expression should not be statically evaluated to a fixed initial set of devices. This means that any devices which fall into the specified scope but which become active during instruction execution will be included in the result set. See notes.

.PARAMETER Offload

If specified, indicates that results from the instruction should be offloaded, rather than stored in the platform response database. Normally these results would be sent over a consumer which has an offloading endpoint defined to accept them

.NOTES

Platform instructions have their own parameters. These will be added as additional dynamic PowerShell parameters based on the instruction definition in the platform.
If you specify the -DynamicScope parameter it is possible for the cmdlet to run until it reaches its timeout, if there are duplicate device FQDNs in the platform database. This is because one or more of the duplicates will be inactive and unable to contribute results, but the instruction statistics will count these as potential responders
To avoid this you can use the -NoWait parameter and choose to subsequently query results using the Get-1EInstructionResult cmdlet, which will return the available results at any point in time.

#>

[CmdletBinding(SupportsShouldProcess=$true, DefaultParameterSetName='targetscope')]

#note - TargetScope and TargetFqdns params mutually exclusive as are TargetPercent and TargetCount

Param(

    [Parameter(Mandatory=$true, Position=1)]

    [string]$instruction,

    [Parameter(Mandatory=$true, ParameterSetName = 'targetscope')]
    [string]$TargetScope,

    [Parameter(Mandatory=$true, ParameterSetName = 'targetfqdns')]
    [string[]]$TargetFqdns,

    [Parameter(Mandatory=$false)] [switch]$PromptDefaults = $false,
    [Parameter(Mandatory=$false)] [switch]$Drilldown = $false,
    [Parameter(Mandatory=$false)] [int]$InstTTL = 60,
    [Parameter(Mandatory=$false)] [int]$ResultsTTL = 120,
    [Parameter(Mandatory=$false)] [string]$Raw = $null,
    [Parameter(Mandatory=$false)] [string]$Csv = $null,
    [Parameter(Mandatory=$false)] [string]$ResultFilter = $null,

    [Parameter(Mandatory=$false)]
    [ValidateRange(1,100)]
    [int]$TargetPercent = 100,

    [Parameter(Mandatory=$false)]
    [ValidateRange(1, [int]::MaxValue)]
    [int]$TargetCount = 0, # note; default is allowed to lie outside validation range, this is a design decision not a bug

    [Parameter(Mandatory=$false)] [string]$TargetFile = $null,
    [Parameter(Mandatory=$false)] [switch]$NoWait = $false,
    [Parameter(Mandatory=$false)] [switch]$DynamicScope = $false,
    [Parameter(Mandatory=$false)] [switch]$Offload = $false
    )

DynamicParam {
    $OFFSET = 15 #Change if fixed param count above changes (note: include -Whatif and remember TargetFqdns|TargetScope are one param, mutually exclusive as are targetpercent|targetcount and raw|csv!. Unfortunately $PSBoundParams doesn't reflect params that will subsequently be prompted for if not supplied and so we don't know how many there are programmatically
    $ret = BuildDynamicParams $instruction $OFFSET
    return $ret.Dict
    }

Process
    {	
    # I could not get named parameter sets to enforce interlocks so do it manually
    $msg = CheckParamsInconsistent $TargetScope $targetFqdns $TargetPercent $TargetCount $targetFile $Raw $Csv $DynamicScope
    if ($msg -ne "")
        {
        throw $msg
        }
    Optimize-Memory
    $defaultProps = @{} 
    if ($PromptDefaults)
	{
	foreach ($p in $ret.Metadata)
		{
         # prompt if there's a default, and if the parameter was passed in specifically, it is set to the default value (i.e from an auto-generated cmdlet that uses invoke-instruction)
		if (-not (IsNullOrEmpty $p.DefaultValue) -and ($PSBoundParameters -eq $null -or ($PSBoundParameters -ne $null -and $PSBoundParameters[$p.Name] -eq $p.DefaultValue )))
			{
			write-host $p.Name ":[" $p.DefaultValue "] " -NoNewLine
			$line = read-host
			if ($line -ne "")
				{
				$defaultProps[$p.Name]=$line
				}
			}
		}
	}
    $params = BuildParams $ret.Metadata $PSBoundParameters $defaultProps
    if ($null -ne $TargetFqdns)
        {
        $scope = $TargetFqdns
        $isTargetted = $true
        }
    else
        {
        $isTargetted = $false
        $scope = $TargetScope
        }

    $arguments = @{}

    if ($isTargetted)
	{
	$arguments.Add("IsTargetted",$true)
	}

   if ($drilldown)
	{
	$arguments.Add("Drilldown",$true)
	}

    if ($Nowait)
	{
	$arguments.Add("NoWait",$true)
	}

   if (-not (IsNullOrEmpty $Raw))
	{
	$arguments.Add("Raw",$raw)
	}

   if (-not (IsNullOrEmpty $ResultFilter))
	{
	$arguments.Add("ResultFilter",$Resultfilter)
	}

   if (-not (IsNullOrEmpty $DynamicScope))
	{
	$arguments.Add("DynamicScope",$DynamicScope)
	}


   if ($null -ne $params)
    {
    $arguments.Add("Params",$params)
    }

   if ($Offload)
    {
    $arguments.Add("Offload",$true)
    }
    
    if ($pscmdlet.ShouldProcess($instruction))
        {
        $r = RunInstruction -Instruction $instruction -Scope $scope -InstTTL $instTTL -ResultsTTL $resultsTTL -TargetPercent $targetPercent -TargetCount $targetCount -TargetFile $targetFile  @arguments
	if (-not (IsNullOrEmpty $Csv))
		{
		$r = Get-ResultAsCsvFile -InputObject $r -Path $Csv
		}
        return $r
        }
    else
        {

        if (-not $isTargetted)
            {
	    if (-not $DynamicScope)
		{
	            return (Get-RespondingDevice -TargetScope $TargetScope -Active)
		}
		else
		{
		   return (Get-RespondingDevice -TargetScope $TargetScope)
		}
            }
        else
            {
	    $ret = New-Object System.Collections.Generic.List[System.Object]           
            foreach ($fqdn in $TargetFqdns)
                {
                $v = New-Object PSObject -Property @{Fqdn = $fqdn}
                $ret.Add($v)
                }
            return $ret.ToArray()
            }
        }
    }
}

function Get-RespondingDeviceCount
{
<#
.SYNOPSIS

Returns a count of devices that correspond to the supplied TargetScope parameter

.EXAMPLE

Get-1ERespondingDeviceCount -Targetscope "fqdn like %abc%"


.PARAMETER TargetScope
Specifies the scope of the target. The scope defines attributes such as fqdns, operating system version etc associated with the endpoints to which an instruction should be sent when executed

.PARAMETER Active
Specifies that only active devices (currently connected) are included

#>


[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [string]$TargetScope,
     [Parameter(Mandatory=$false)] [switch]$Active = $false
     )
$scope = RetrieveScope $TargetScope $Active
$res = PostHttpRequest "/consumer/Devices/ApproxTarget" $scope
$count = $res.TotalDevicesOnLine
return $count
}


function Get-RespondingDevice
{
<#
.SYNOPSIS

Returns a list of devices that correspond to the supplied TargetScope parameter

.EXAMPLE

Get-1ERespondingDevice -Targetscope "fqdn like %abc%"


.PARAMETER TargetScope
Specifies the scope of the target. The scope defines attributes such as fqdns, operating system version etc associated with the endpoints to which an instruction should be sent when executed

.PARAMETER Full
Specifies that full information should be returned for each device, rather than a summary

.PARAMETER Active
Specifies that only active devices (currently connected) are included

.PARAMETER AsArray
Specifies that the device fqdns are returned directly as a string array


#>

[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [string]$TargetScope,
     [Parameter(Mandatory=$false)] [switch]$Full,
     [Parameter(Mandatory=$false)] [switch]$Active = $false,
     [Parameter(Mandatory=$false)] [switch]$AsArray = $false
     )
$scope = RetrieveScope $TargetScope $Active
$res = GetRespondingDevices $scope

if ($Full)
	{
	return $res
	}

if ($AsArray)
	{
	return $res | select-object -ExpandProperty fqdn
	}

#by default, if Full not specified, project this down to just return FQDNs because although the full metadata per device is available, if we use -whatif with targetting (fqdns) we have no corresponding API to get the device metadata and would end up making thousands
#of API calls to get it - so better to just return the bare minimum we can for both scenarios

return $res | select-object -Property fqdn
}

function Get-Device
{
<#
.SYNOPSIS

Returns a list of all devices known to the platform at this time, or information on a specific device specified by FQDN

.EXAMPLE

Get-1EDevice

.PARAMETER Full
Specifies that full information is returned for each device as opposed to a summary. This parameter is ignored if an FQDN is specified. In that case, full information for the device is always returned

.PARAMETER Fqdn
Specifies a device fqdn for which information is to be returned. The -Full parameter is ignored if this parameter is specified and full information for the device is always returned

#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$false)] [switch]$Full,
     [Parameter(Mandatory=$false)] [string]$Fqdn
     )
if (IsNullOrEmpty $Fqdn)
    {
    $res = GetAllDevices

    if ($Full)
	    {
	    return $res
	    }

#by default, if Full not specified, project this down to just return FQDNs because although the full metadata per device is available, if we use -whatif with targetting (fqdns) we have no corresponding API to get the device metadata and would end up making thousands
#of API calls to get it - so better to just return the bare minimum we can for both scenarios

    $ret = New-Object System.Collections.Generic.List[System.Object]           

    foreach ($device in $res)
         {
        $v = New-Object PSObject -Property @{Fqdn = $device.Fqdn}
        $ret.Add($v)
        }
    return $ret.ToArray()
    }
else
    {
    $ret = GetDeviceInfo $fqdn
    return $ret
    }
}

function New-CmdletFromFile
{
<#
.SYNOPSIS

Processes one or more instruction XML files and creates cmdlets from them. The files must be appropriately marked up with a cmdlet name in the XML metadata

.EXAMPLE

New-1ECmdletFromFile -Folder c:\myinstructions


.PARAMETER -Folder

Specifies the folder to search for instruction XML files

.PARAMETER -OutFile

Specifies an optional file into which all the cmdlets should be merged. If this is not specified, individual cmdlet output files are created for each instruction XML files


#>
[CmdletBinding(SupportsShouldProcess=$true)]

Param(
     [Parameter(Mandatory=$true)] [string]$Folder,
     [Parameter(Mandatory=$false)] [string]$OutFile = $null
     )

$files = get-childitem -path $Folder -filter "*.xml" -recurse
if ($pscmdlet.ShouldProcess($folder))
    {
    foreach ($file in $files)
	    {
	    $filepath = $Folder + "\" + $file
	    try
		    {
		    new-cmdlet -file $filepath -outfile $Outfile
		    }
	    catch
		    {
		    write-host -foregroundcolor red "Unable to create cmdlet from file " + $filepath 
		    }
        }
    }
else
    {
    # return a csv set which documents the instructions and the associated cmdlet
    $metadata = New-Object System.Collections.Generic.List[System.Object]
    foreach ($file in $files)
	    {
	    $filepath = $Folder + "\" + $file
	    try
		    {
            $xml = get-instructionxml $filepath
            $value = New-Object PSObject -Property @{
                Name = $xml.Name
                Description = $xml.Description
                ReadablePayload = $xml.ReadablePayload
                InstructionType = $xml.InstructionType
                Version = $xml.Version
                CmdLet = GetCmdletFromXml $xml.Comments
                }
            [void]$metadata.Add($value)
            }
        catch
            {
            }
        }
        return $metadata
    }
}

function New-CmdLet

{

<#
.SYNOPSIS

Creates a new cmdlet file from a platform instruction

.EXAMPLE

New-1ECmdlet -Instruction 1E-Explorer-TachyonCore-GetCurrentInstalledMemoryDetails -CmdLet Get-1EMemoryDetails


.PARAMETER -Instruction

Specifies the name of the platform instruction to use

.PARAMETER -CmdLet

Specifies the name of the cmdlet to create from the instruction

.PARAMETER -File

Specifies an optional override name for the output file for the cmdlet. if not specified, the output file name is based on the cmdlet name


#>
[CmdletBinding(DefaultParameterSetName='Default')]

Param(
     [Parameter(Mandatory=$true, ParameterSetName='Default')] [string]$instruction,
     [Parameter(Mandatory=$true, ParameterSetName='File')] [string]$file,

     [Parameter(Mandatory=$true, ParameterSetName='Default')]
     [Parameter(Mandatory=$false, ParameterSetName='File')]
            [string]$cmdlet,

     [Parameter(Mandatory=$false)] [string]$outfile
     )

$isAggregated =  $false

if (-not (IsNullOrEmpty $instruction))
    {
    $instMetadata = getinstructionmetadatabyname $instruction
    if ($null -eq $instMetadata)
        {
        throw "Unable to retrieve instruction metadata"
        }

    $metadata = $instMetadata.Parameters
    if (-not (IsNullOrEmpty $instMetadata.Aggregation))
        {
        $isAggregated =  $true
        }
    }
else
    {
    if (-not (test-path -path $file))
        {
        throw "The specified input file could not be opened"
        }
    $instMetadata=get-instructionxml $file
    if ($null -ne $instMetadata.AggregationJson)
        {
        $isAggregated = $true
        }
    $instruction = $instMetadata.Name
    if (IsNullOrEmpty $cmdlet)
        {
        $cmdlet= getCmdletFromXml $instMetadata.Comments
        if ($cmdlet -eq "")
            {
            throw "Unable to retrieve cmdlet name from instruction XML file"
            }
	    }
    $xmlParams = $instMetadata.ParameterJson.InnerText 
    if ($null -ne $xmlParams)
        {
        $metadata = $xmlParams | convertfrom-json
        }
    }


               
if ($cmdlet.IndexOf("\") -ge 0)
    {
    $cmdletName = [io.path]::GetFileNameWithoutExtension($cmdlet)
    }
else
    {
    $cmdletName = $cmdlet.Replace(".psm1","")
    }

# note: this will need changing if invoke-instruction's fixed params get changed

$text = @"
function $($cmdletName)
{
[CmdletBinding(SupportsShouldProcess=`$true, DefaultParameterSetName='TargetScope')]

Param(
    [Parameter(Mandatory=`$true, ParameterSetName='TargetScope')] [string]`$TargetScope,
    [Parameter(Mandatory=`$true, ParameterSetName='TargetFqdns')] [string[]]`$TargetFqdns,
    [Parameter(Mandatory=`$false)] [string]`$Resultfilter = `$null,
    [Parameter(Mandatory=`$false)] [string]`$TargetFile = `$null,
    [Parameter(Mandatory=`$false)] [int]`$TargetPercent = 100,
    [Parameter(Mandatory=`$false)] [int]`$TargetCount = 0,
    [Parameter(Mandatory=`$false)] [switch]`$PromptDefaults = `$false,
    [Parameter(Mandatory=`$false)] [switch]`$Nowait = `$false,
    [Parameter(Mandatory=`$false)] [string]`$Raw = `$null,
    [Parameter(Mandatory=`$false)] [int]`$InstTTL = 0,
    [Parameter(Mandatory=`$false)] [int]`$ResultsTTL = 0
"@

if ($isAggregated)
    {
    $text += "`r`n,[Parameter(Mandatory=`$false)] [switch]`$Drilldown = `$false"
    }



foreach ($p in $metadata)
	{
    # replace spaces with underscores in param names
    $paramName = $p.Name.Replace(" ","_")

    if ($p.ControlType -eq "valuePicker")
        {
        $validateSet = GetValidateSet $p
        }
    else
        {
        $validateSet = ""
        }

	if (-not (IsNullOrEmpty $p.DefaultValue))
		{
		$line = ",`r`n[Parameter(Mandatory=`$false)] " + $validateSet +  (MapType $p.DataType) +  " $" + $paramName + "=" + '"' + $p.DefaultValue + '"'
		}
	else
		{
		$line = ",`r`n[Parameter(Mandatory=`$true)] " + $validateSet + (MapType $p.DataType) + " $"  + $paramName
		}
		$text += $line
	}
$text += "`r`n)`r`n"

$switchText = @"
`$instruction = "$($instruction)"
`$arguments = @{}
if (`$promptdefaults)
	{
	`$arguments.Add("PromptDefaults",`$true)
	}
if (`$drilldown)
	{
	`$arguments.Add("Drilldown",`$true)
	}
if (`$nowait)
	{
	`$arguments.Add("Nowait",`$true)
	}
if (`$raw -ne `$null)
	{
	`$arguments.Add("Raw",`$Raw)
	}
if (`$TargetScope -ne `$null -and `$TargetScope -ne "")
	{
	`$arguments.Add("TargetScope",`$TargetScope)
	}
if (`$TargetCount -ne 0)
	{
	`$arguments.Add("TargetCount",`$TargetCount)
	}
if (`$TargetFile -ne `$null)
	{
	`$arguments.Add("TargetFile",`$TargetFile)
	}
if (`$TargetPercent -ne 100)
	{
	`$arguments.Add("TargetPercent",`$TargetPercent)
	}
if (`$ResultFilter -ne `$null)
	{
	`$arguments.Add("ResultFilter",`$ResultFilter)
	}
if (`$TargetFqdns -ne `$null -and `$TargetFqdns -ne "")
	{
	`$arguments.Add("TargetFqdns",`$TargetFqdns)
	}
if (`$InstTTL -ne 0)
	{
	`$arguments.Add("InstTTL",`$InstTTL)
	}
if (`$ResultsTTL -ne 0)
	{
	`$arguments.Add("ResultsTTL",`$ResultsTTL)
	}
if (-not `$pscmdlet.ShouldProcess(`$instruction))
	{
	`$arguments.Add("Whatif",`$true)
	}
if (`$informationPreference -eq "Continue")
	{
	`$arguments.Add("InformationAction","Continue")
	}
"@

$text += $switchText + "`r`n"

# note: the auto-generated code interpolates the command prefix from the psd1 module file. (normally '1E')

$moduleText = @"
try
	{
	`$server = get-${CMDPREFIX}server
	}
	catch
	{
	import-module .\${MODULEFILE} -force -global
	}
"@

$text += $moduleText + "`r`n"
$text += "return Invoke-${CMDPREFIX}Instruction `$instruction @arguments"


foreach ($p in $metadata)
	{
    # replace spaces with underscores in param names
    $paramName = $p.Name.Replace(" ","_")

	$text += " -"  + $paramName +  ' $' + $paramName 
	}
$text += "`r`n}`r`n"
$text += "Export-ModuleMember -Function " + $cmdletName
if (-not (IsNullOrEmpty $outfile))
    {
    add-content -Path $($outfile) -Value $text
    }
else
    {
    if ($cmdlet.IndexOf(".psm1") -ge 0)
        {
        set-content -Path $($cmdlet) -Value $text
        }
    else
        {
        set-content -Path $($cmdlet + ".psm1") -Value $text
        }
    }
return "Cmdlet " + $cmdlet + " created successfully"
}	



function Set-InstructionSetIcon
{
<#
.SYNOPSIS

Associates the specified icon with the defined instruction set

.EXAMPLE

Set-1EInstructionSetIcon -InstructionSet NewSet -Icon <path to icon file>


.PARAMETER InstructionSet

Specifies the name of the instruction set to be updated

.PARAMETER Icon

Specifies the path to the icon file to be associated with the instruction set


#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [string]$InstructionSet,
     [Parameter(Mandatory=$true)] [string]$Icon
     )	


$set = GetInstructionSet $instructionSet
$res = CreateOrUpdateInstructionSet $set.Name $set.Id $set.Description $icon
return $res
}


function New-InstructionSet
{
<#
.SYNOPSIS

Creates the named instruction set and returns its platform Id. If the instruction set already exists, an error is thrown

.EXAMPLE

New-1EInstructionSet -InstructionSet NewSet


.PARAMETER InstructionSet

Specifies the name of the instruction set to be created 

.PARAMETER Description

Specifies the description of the instruction set to be created 

.PARAMETER Icon

Specifies the path to an icon file to be associated with the instruction set


#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [string]$InstructionSet,
     [Parameter(Mandatory=$false)] [string]$Description,
     [Parameter(Mandatory=$false)] [string]$Icon
     )	

$r = CreateOrUpdateInstructionSet $instructionSet 0 $description $icon
$setid = $r.Id
return $setid
}

function Remove-InstructionSet
{
<#
.SYNOPSIS

Removes the specified instruction set. 

.EXAMPLE

Remove-1EInstructionSet -Name MyNewSet


.PARAMETER Id

Specifies the platform Id of the instruction set to remove


.PARAMETER Name

Specifies the platform name of the instruction set to remove

.PARAMETER DeleteInstructions

Specifies that any instructions which belong to the set to remove are deleted. If not specified, these instructions are instead moved to the 'Unassigned' instruction set but not deleted


#>
[CmdletBinding(DefaultParameterSetName='Name')]

param(
     [Parameter(Mandatory=$true,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$true,ParameterSetName='Name')] [string]$Name,
     [Parameter(Mandatory=$false)] [switch]$deleteInstructions = $false
     )

if (-not (IsNullOrEmpty $name))
    {
    $id = GetInstructionSetId $name
    }
$r = DeleteInstructionSet $Id $deleteInstructions
return $r
}

function Get-InstructionInSet
{
<#
.SYNOPSIS

Returns a list of the instructions that belong to the specified instruction set

.EXAMPLE

Get-1EInstructionInSet -InstructionSet MyNewSet


.PARAMETER InstructionSet

Specifies the name of the instruction set to query


#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [string]$InstructionSet
     )	
#ensure server-side instructions are returned as well
$url = "/Consumer/InstructionDefinitions/InstructionSet/Name/" + $InstructionSet + "?dataSourceFilter=ALL"
$res = GetHttpRequest $url
return $res
}

function Remove-Instruction
{
<#
.SYNOPSIS

Removes (deletes) the specified instruction

.EXAMPLE

Remove-1EInstruction -Name 1E-Explorer-InstructionToRemove


.PARAMETER Id

Specifies the platform Id of the instruction to remove

.PARAMETER Name

Specifies the platform names of the instruction to remove

#>
[CmdletBinding(DefaultParameterSetName='Name')]


Param(
     [Parameter(Mandatory=$true,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$true,ParameterSetName='Name')] [string]$Name
     )

if (-not (IsNullOrEmpty $name))
    {
    $Id = Get-InstructionId $name
    }
$url = "/Consumer/InstructionDefinitions/Id/" + $Id
$res = DeleteHttpRequest $url
return $res
}


function Get-InstructionId
{
<#
.SYNOPSIS

Gets the platform Id of the specified instruction

.EXAMPLE

Get-1EInstructionId -Instruction 1E-Explorer-TachyonCore-GetCurrentInstalledMemoryDetails


.PARAMETER Instruction

Specifies the name of the instruction


#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [string]$Instruction
     )

$url = "/Consumer/InstructionDefinitions/Name/" + $instruction
$res = GetHttpRequest $url
return $res.Id
}

function Get-AllPolicy
{
[CmdletBinding()]

Param(
     )

$url = "/Consumer/Policies/Shallow/search"
$payload = @"
 {
  "Start": 1,
  "PageSize": 2000,
  "Filter": {
    "Attribute": "Name",
    "Operator": "LIKE",
    "Value": "%"
  }
}
"@
$res = PostHttpRequestPaged $url $payload
return $res.Items
}

function Get-PolicyAssignment
{
<#
.SYNOPSIS

Returns all management group to guaranteed state policy assignments

.EXAMPLE

Get-1EPolicyAssignment


#>
[CmdletBinding()]

Param(
     )
$url = "/Consumer/PolicyAssignments"
$res = GetHttpRequest $url
return $res

}

function Get-PolicyDeviceStatus
{
<#
.SYNOPSIS

Returns a summary of device compliance for all active policies

.EXAMPLE

Get-1EPolicyDeviceStatus


.PARAMETER Id

If specified, restricts the returned list to device compliance information for the policy whose platform Id is specified by this parameter


#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$false)] [int]$Id=0
     )
if ($id -eq 0)
	{
	$url = "/Consumer/Policy/Dashboard/DeviceStatus"
	}
else
	{
	$policy = get-policy -Id $Id
	if (IsNullOrEmpty $policy)
		{
		throw "The policy specified does not exist"
		}
	$url = "/Consumer/Policy/Dashboard/DeviceStatus/" + $Id
	}

$res = GetHttpRequest $url
return $res

}


function Get-PolicyRuleStatus
{
<#
.SYNOPSIS

Returns a summary of rule compliance for all active guaranteed state policies

.EXAMPLE

Get-1EPolicyRuleStatus


.PARAMETER Id

If specified, restricts the returned list to rule compliance information for the policy whose platform Id is specified by this parameter


#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$false)] [int]$Id=0
     )
if ($id -eq 0)
	{
	$url = "/Consumer/Policy/Dashboard/PolicyRuleStatus"
	}
else
	{
	$policy = get-policy -Id $id
	if (IsNullOrEmpty $policy)
		{
		throw "The policy specified does not exist"
		}
	$url = "/Consumer/Policy/Dashboard/PolicyRuleStatus/" + $Id
	}

$res = GetHttpRequest $url
return $res

}

function Get-PolicyRuleDeviceStatus
{
<#
.SYNOPSIS

Returns a detailed list of devices and their compliance status with respect to the policy (and optionally rule) specified

.EXAMPLE

Get-1EPolicyRuleDeviceStatus -Id 3


.PARAMETER Id

Defines the policy for which compliance status for devices is to be returned

.PARAMETER RuleId

If specified, returns compliance status only for devices relative to the specified rule (if applicable)


#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id,
     [Parameter(Mandatory=$false)] [int]$RuleId
     )
$policy = get-policy -Id $id
if (IsNullOrEmpty $policy)
	{
	throw "The policy specified does not exist"
	}

$payload = @"
{
  "Start": 1,
  "PageSize": 200,
  "Filter": null
}
"@

if ((IsNullOrEmpty $RuleId) -or ($RuleId -eq 0))
	{
	$url = "/Consumer/Policy/View/DevicePolicyRuleStatus/PolicyId/" + $Id + "/Search"
	}
else
	{
	$rules = get-policyrule -id $Id | where-object {$_.Id -eq $RuleId}
	if ($rules.Count -eq 0)
		{
		throw "The specified rule Id is not associated with the specified policy"
		}

	$url = "/Consumer/Policy/View/DevicePolicyRuleStatus/PolicyId/" + $Id + "/ruleid/" + $RuleId +  "/Search"
	}
$res = PostHttpRequestPaged $url $payload
return $res

}


function Get-Principal
{
<#
.SYNOPSIS

Returns a list of all RBAC principals 

.EXAMPLE

Get-1EPrincipal


.PARAMETER Id

If specified, returns only the principal information for the principal whose platform Id is specified

.PARAMETER Account

If specified, returns only the principal information for the principal whose name is specified


#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$false)] [string]$Account,
     [Parameter(Mandatory=$false)] [int]$Id
)

if (-not (IsNullOrEmpty $Account))
    {
    $url = "/Consumer/Principals"
    $res = GetHttpRequest $url
    $r = $res | where-object {$_.PrincipalName -eq $Account}
    if (IsNullOrEmpty $r)
        {
        throw "Principal cannot be located"
        }
    return $r
    }

if ($id -eq 0)
	{
	$url = "/Consumer/Principals"
	}
else
	{
	$url = "/Consumer/Principals/" + $Id
	}
$res = GetHttpRequest $url
return $res
}

function Add-Principal
{
<#
.SYNOPSIS

Adds a new RBAC principal

.EXAMPLE

Add-1EPrincipal -Account mydomain\myuser

Add-1EPrincipal -Account myuser@myorg.com


.PARAMETER Account

Specifies an account associated with the principal

.PARAMETER Email

Specifies an email address associated with the principal

.PARAMETER DisplayName

Specifies a display name to be used for the principal in the platform Explorer application

.PARAMETER IsGroup

Specifies that the principal is a group, rather than a user. The default is that the principal is defined as a user

#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [string]$Account,
     [Parameter(Mandatory=$false)] [string]$Email,
     [Parameter(Mandatory=$false)] [string]$DisplayName,
     [Parameter(Mandatory=$false)] [switch]$IsGroup=$false
)

$acct = $account.replace("\","\\")

if (($script:TACHYONMAJORVER -lt 8) -or (($script:TACHYONMAJORVER -eq 8) -and ($script:TACHYONMINORVER -lt 2)))
    {
    $sid = GetSid $account
    if (IsNullOrEmpty $sid)
    	{
    	throw "Unable to retrieve SID for specified account"
    	}
    $prefix = @"
        {
        "PrincipalName": "$($acct)",
        "ExternalId": "$($sid)",
        "Enabled": true,
        "SystemPrincipal": false,
        "Origin": "Identity",
"@
    }
else
    {
    $prefix = @"
        {
        "PrincipalName": "$($acct)",
        "Enabled": true,
        "SystemPrincipal": false,
        "Origin": "Identity",
"@
    }

# TODO: support firstname, lastname, isgroup, systemprincipal,enabled,  possibly remove identity

$suffix = @"
 "IsGroup": $($IsGroup.ToString().ToLower())
}
"@
$infill = ""
if (-not (IsNullOrEmpty $Email))
	{
	$infill = @"
	"Email": "$($Email)",
"@
	}
if (-not (IsNullOrEmpty $DisplayName))
	{
	$infill += @"
	"DisplayName": "$($DisplayName)",
"@
	}

$payload = $prefix + $infill + $suffix

$url = "/Consumer/Principals"
$res = PostHttpRequest $url $payload
return $res
}

function Update-Principal
{
<#
.SYNOPSIS

Updates properties of an existing principal

.EXAMPLE

Update-1EPrincipal -Id 4 -Email mynewemail@myorg.com


.PARAMETER Account

Specifies an account associated with the principal

.PARAMETER Id

Specifies the Id of the principal

.PARAMETER Email

Specifies an email address associated with the principal

.PARAMETER DisplayName

Specifies a display name to be used for the principal in the platform Explorer application

.PARAMETER PrincipalName

Specifies a new account name for the principal


#>
[CmdletBinding(DefaultParameterSetName='Name')]

Param(
     [Parameter(Mandatory=$true, ParameterSetName='Name')] [string]$Account,
     [Parameter(Mandatory=$true, ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$false)] [string]$Email,
     [Parameter(Mandatory=$false)] [string]$DisplayName,
     [Parameter(Mandatory=$false)] [string]$PrincipalName
)

if (-not (IsNullOrEmpty $Account))
	{
	$principal = get-principal | where-object {$_.PrincipalName -eq $Account}
	if (IsNullOrEmpty $principal)
		{
		throw "The specified principal could not be found"
		}
	}
else
	{
	$principal = get-principal -Id $Id
	}

if (-not (IsNullOrEmpty $Email))
	{
	$principal.Email = $Email
	}

if (-not (IsNullOrEmpty $DisplayName))
	{
	$principal.DisplayName = $DisplayName
	}

if (-not (IsNullOrEmpty $PrincipalName))
	{
	$principal.PrincipalName = $PrincipalName
	}

$payload = convertto-json $principal

$url = "/Consumer/Principals"
$res = PutHttpRequest $url $payload
return $res
}


function Add-Role
{
<#
.SYNOPSIS

Adds the role specified by the name and description. 

.EXAMPLE

Add-1ERole -Name MyNewRole -Description NewRole


.PARAMETER Name

Specifies the name of the new role to be added

.PARAMETER Description

Specifies the description associated with the new role

.PARAMETER CanBeDelegated

If specified, indicates that the role can be delegated. The default is FALSE

.NOTES

CanBeDelegated = $false means only a Person who has Security -> Write on All Devices Management Group (i.e a so called ‘Global Security Admin’ type of person) can assign that Role.
CanBeDelegated = $true means you need Security -> Read on a management group to assign, or delegate, the role to another principal
CanBeDelegated must be false if any of the permissions for the role use global securable types. The Get-1ESecurableType cmdlet will return whether a securable type is global or not in the IsGlobal member

#>

[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [string]$Name,
     [Parameter(Mandatory=$true)] [string]$Description,
     [Parameter(Mandatory=$false)] [switch]$CanBeDelegated = $false
)
$url = "/Consumer/Roles"
$payload = @"
{
"Name": $(quotify $Name),
"Description": $(quotify $Description)
"@
if ($CanBeDelegated)
	{
	$payload += ",`r`n" + '"CanBeDelegated":"true"'
	}
$payload += "}"

$res = PostHttpRequest $url $payload
return $res
}

function Remove-Role
{
<#
.SYNOPSIS

Removes the role specified by the name or id

.EXAMPLE

Remove-1ERole -Name MyNewRole


.PARAMETER Name

Specifies the name of the role to be removed

.PARAMETER Id

Specifies the id of the role to be removed

.PARAMETER Force

If specified, removes the role from any principal that has been assigned it. 

.PARAMETER WhatIf

If specified, returns the principals which have been assigned the role (if any)


#>

[CmdletBinding(SupportsShouldProcess=$true, DefaultParameterSetName='Name')]

Param(
     [Parameter(Mandatory=$true, ParameterSetName='Name')] [string]$Name,
     [Parameter(Mandatory=$true, ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$false)][switch]$Force
)

$roleId = $Id
if (-not (IsNullOrEmpty $Name))
    {
    $r = get-role -Name $Name
    $roleId = $r.Id
    }

if (-not $pscmdlet.ShouldProcess("Remove-Role"))
{
    $res = get-roleprincipal -id $roleId
    return $res
}

if ($Force)
    {
    $res = get-roleprincipal -id $roleId
    foreach ($r in $res)
        {
        $x = remove-rolefromprincipal -id $r.PrincipalId -RoleId $roleId
        }
    }

$url = "/Consumer/Roles/" + $roleId
$res = DeleteHttpRequest $url 
return $res
}

function Remove-Principal
{
<#
.SYNOPSIS

Removes a platform RBAC principal

.EXAMPLE

Remove-1EPrincipal -Id 3


.PARAMETER Id

Specifies the platform Id of the principal to remove.

.PARAMETER Account

Specifies the name of the principal to remove

.PARAMETER Force

If specified, any roles associated with the principal are removed. If not specified, attempting to remove a principal with allocated roles will result in an error

.PARAMETER WhatIf

If specified, returns the roles (if any) associated with the principal


#>
[CmdletBinding(SupportsShouldProcess=$true, DefaultParameterSetName='Name')]

Param(
     [Parameter(Mandatory=$true, ParameterSetName='Name')] [string]$Account,
     [Parameter(Mandatory=$true, ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$false)][switch]$Force
)

if (-not (IsNullOrEmpty $Account))
    {
    $principal = get-principal -Account $Account
    $Id = $principal.Id
    }
else
    {
    $principal = get-principal -Id $Id
    }

if (-not $pscmdlet.ShouldProcess("Remove-Principal"))
{
    $res = get-principalrole -id $Id
    return $res
}

if ($Force)
	{
        $res = get-principalrole -id $Id
	foreach ($r in $res)
		{
		$x = remove-rolefromprincipal -Id $id -RoleId $r.RoleId
		}
	}

$payload = "[" + $id +"]" 
$url = "/Consumer/Principals"
$res = DeleteHttpRequest $url $payload
return $res
}

function Get-PrincipalRole
{
<#
.SYNOPSIS

Returns the RBAC roles (if any) associated with the specified principal

.EXAMPLE

Get-1EPrincipalRole -Id 3

.PARAMETER Id

Specifies the platform Id of the principal whose roles are to be returned

#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id
     )
$principal = get-principal -Id $Id
if (IsNullOrEmpty $principal)
	{
	throw "The specified principal does not exist"
	}
$url = "/Consumer/Roles/Principal/" + $Id
$res = GetHttpRequest $url
return $res
}

function Get-RolePrincipal
{
<#
.SYNOPSIS

Returns the platform RBAC principals who are associated with a given role

.EXAMPLE

Get-1ERolePrincipal -Id 32


.PARAMETER Id

Specifies the platform Id of the role for which principals are to be returned


#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id
     )
$role = get-role -Id $Id
if (IsNullOrEmpty $role)
	{
	throw "The specified role does not exist"
	}
$url = "/Consumer/Principals/Role/" + $Id
$res = GetHttpRequest $url
return $res
}

function Get-PermissionForRole
{
<#
.SYNOPSIS

Gets the permissions that have been assigned to the specified role

.EXAMPLE

Get-1EPermissionForRole -Id 52


.PARAMETER Id

Specifies the platform Id of the role


#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id
     )
$url = "/Consumer/Permissions/Role/" + $Id
$res = GetHttpRequest $url
return $res
}



function Add-PermissionToRole
{
<#
.SYNOPSIS

Adds the permission defined by the securable type and operation to the specified role

.EXAMPLE

Add-1EPermissionToRole -Id 52 -TypeId 6 -OperationId 12


.PARAMETER Id

Specifies the platform Id of the role

.PARAMETER TypeId

Specifies the platform Id of the securable type

.PARAMETER OperationId

Specifies the platform Id of the securable operation

.PARAMETER SecurableId

Specifies the securable Id of the the securable type. This is currently only applicable for securable type "Instruction Set". See notes

.NOTES

When you specify a securable type whose Id corresponds to the platform "InstructionSet" securable type, then the SecurableId parameter allows you to specify which instruction set you are associating the permission with
If you do not specify a SecurableId parameter for an instruction set, then the permission is granted to all instruction sets.
Otherwise the SecurableId parameter should correspond to the Id of an instruction set that you wish to grant the permission to.
Use the Get-1EInstructionSet cmdlet to retrieve a list of instruction sets and their associated Ids


#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id,
     [Parameter(Mandatory=$true)] [int]$TypeId,
     [Parameter(Mandatory=$true)] [int]$OperationId,
     [Parameter(Mandatory=$false)] [int]$SecurableId
     )

$url = "/Consumer/Permissions/Single"
$payload = @"
{
"RoleId": $Id,
"SecurableTypeId": $TypeId,
"OperationId": $OperationId,
"Allowed": "true"
"@
if ($SecurableId -ne 0)
	{
	$payload += ",`r`n" + '"SecurableId":' + $($SecurableId)
	}

$payload += "}"


$res = PostHttpRequest $url $payload
return $res
}


function Remove-Permission
{
<#
.SYNOPSIS

Removes the permission defined by its platform Id

.EXAMPLE

Remove-1EPermission -Id 263


.PARAMETER Id

Specifies the platform Id of the permission



#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id
     )

$url = "/Consumer/Permissions/" + $Id

$res = DeleteHttpRequest $url
return $res
}



function Get-Permission
{
<#
.SYNOPSIS

Returns the permission whose platform Id is specified, or the set of permissions associated with the specified Securable Type Id

.EXAMPLE

Get-1EPermission -TypeId 1


.PARAMETER Id

Specifies the platform Id of the permission to return

.PARAMETER TypeId

Specifies the platform Id of the securable type for which all available permissions are to be returned


#>
[CmdletBinding(DefaultParameterSetName='Id')]

Param(
     [Parameter(Mandatory=$true,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$true,ParameterSetName='TypeId')] [int]$TypeId
     )
if ($Id -gt 0)
	{
	$url = "/Consumer/Permissions/" + $Id
	}
else
	{
	$url = "/Consumer/Permissions/Securable/" + $TypeId
	}
$res = GetHttpRequest $url
return $res
}



function Get-OperationForSecurableType
{
<#
.SYNOPSIS

Returns a set of operations that a valid for the given securable type

.EXAMPLE

Get-1EOperationForSecurableType -Id 14


.PARAMETER Id

Specifies the platform Id of the securable type for which valid operations are to be returned

.PARAMETER Name

Specifies the name of the securable type for which valid operations are to be returned

#>
[CmdletBinding(DefaultParameterSetName='Id')]

Param(
     [Parameter(Mandatory=$false,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$false,ParameterSetName='Name')] [string]$Name
)
if (-not (IsNullOrEmpty $Name))
	{
	$url = "/Consumer/ApplicableOperations/SecurableTypeName/" + $Name
	}
else
	{
	$url = "/Consumer/ApplicableOperations/SecurableTypeId/" + $id
	}
$res = GetHttpRequest $url
return $res

}

function Get-SecurableType
{
<#
.SYNOPSIS

Returns all securable types, or a single securable type

.EXAMPLE

Get-1ESecurableType


.PARAMETER Id

If specified, defines the platform Id of the securable type to return information for

.PARAMETER Name

If specified, defines the name of the securable type to return information for

#>
[CmdletBinding(DefaultParameterSetName='Id')]

Param(
     [Parameter(Mandatory=$false,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$false,ParameterSetName='Name')] [string]$Name
)
if (-not (IsNullOrEmpty $Name))
	{
	$url = "/Consumer/SecurableTypes/Name/" + $Name
	}
else
	{
	if ($Id -eq 0)
		{
		$url = "/Consumer/SecurableTypes"
		}
	else
		{
		$url = "/Consumer/SecurableTypes/" + $Id
		}
	}
$res = GetHttpRequest $url
return $res
}

function Get-ManagementGroupForRole
{
<#
.SYNOPSIS

Retrieves the management groups (if any) associated with the specified role

.EXAMPLE

Get-1EManagementGroupForRole -Id 52


.PARAMETER Id

Specifies the platform Id of the role to query

#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id
	 )
if ($script:TACHYONMAJORVER -ge 8)
    {
    throw "This cmdlet is not available for this version of the platform"
    }
$url = "/Consumer/Roles/" + $id + "/ManagementGroups"
$res = GetHttpRequest $url
return $res.ManagementGroups
}

function Add-RoleToPrincipal
{
<#
.SYNOPSIS

Adds a role to a principal

.EXAMPLE

Add-1ERoleToPrincipal -Id 5 -RoleId 13


.PARAMETER Id

Specifies the platform Id of the principal to which the role should be added

.PARAMETER RoleId

Specifies the platform Id of the role to be added to the principal

#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id,
     [Parameter(Mandatory=$true)] [int]$RoleId
     )
$roles = get-principalrole -id $Id | where-object {$_.RoleId -eq $RoleId}
if (-not (IsNullOrEmpty $roles))
	{
	throw "This principal has already been assigned the specified role"
	}

$url = "/Consumer/PrincipalRoles/Role/" + $RoleId
$payload = "[" + $id + "]"
$res = PostHttpRequest $url $payload
return $res
}

function Get-PrincipalRoleManagementGroup
{
<#
.SYNOPSIS

Returns the roles for each management group associated with each principal

.EXAMPLE

Get-1EPrincipalRoleManagementGroup

.PARAMETER PrincipalId

Specifies the platform Id of the principal for which the information should be returned

.PARAMETER RoleId

Specifies the platform Id of the role for which the information should be returned

.PARAMETER ManagementGroupId

Specifies the platform Id of the management group for which the information should be returned

.PARAMETER PrincipalName

Specifies the name of the principal for which the information should be returned

.PARAMETER RoleName

Specifies the name of the role for which the information should be returned

.NOTES

This cmdlet is not available in versions of the platform prior to version 8 and will throw an error if run against an older version of the platform.
#>

[CmdletBinding(DefaultParameterSetName='Name')]
Param(
     [Parameter(Mandatory=$false, ParameterSetName = 'Id')] [int]$PrincipalId,
     [Parameter(Mandatory=$false, ParameterSetName = 'Id')] [int]$RoleId,
     [Parameter(Mandatory=$false, ParameterSetName = 'Id')] [int]$ManagementGroupId,
     [Parameter(Mandatory=$false, ParameterSetName = 'Name')] [string]$PrincipalName,
     [Parameter(Mandatory=$false, ParameterSetName = 'Name')] [string]$RoleName
)

if ($script:TACHYONMAJORVER -lt 8)
    {
    throw "This cmdlet is not available for this version of the platform"
    }

$argcount = 0
if ($PrincipalId -ne 0)
    {
    $argcount++
    }

if ($RoleId -ne 0)
    {
    $argcount++
    }

if ($ManagementGroupId -ne 0)
    {
    $argcount++
    }

if ($argcount -gt 1)
    {
    throw "Only one of PrincipalId, RoleId or ManagementGroupId may be specified"
    }

if ((-not (IsNullOrEmpty $PrincipalName)) -and (-not (IsNullOrEmpty $RoleName)))
    {
    throw "Only one of PrincipalName or RoleName may be specified"
    }

$url = "/Consumer/PrincipalRoleManagementGroups"

if ($PrincipalId -ne 0)
    {
    $url += "/Principal/Id/" + $PrincipalId
    }

if ($RoleId -ne 0)
    {
    $url += "/Role/Id/" + $RoleId
    }

if ($ManagementGroupId -ne 0)
    {
    $url += "/ManagementGroup/Id/" + $ManagementGroupId + "/true"
    }

if (-not (IsNullOrEmpty $PrincipalName))
    {
    $url += "/Principal/Name/" + (ToBase64 $PrincipalName)
    }

if (-not (IsNullOrEmpty $RoleName))
    {
    $url += "/Role/Name/" + (ToBase64 $RoleName)
    }

$res = GetHttpRequest $url
return $res
}

function Add-PrincipalRoleManagementGroup
{
<#
.SYNOPSIS

Associates the specified role and principal with the specified management group

.EXAMPLE

Add-1EPrincipalRoleManagementGroup -PrincipalId 6 -RoleId 37 -ManagementGroupId 1

.PARAMETER PrincipalId

Specifies the platform Id of the principal to be associated with the specified management group

.PARAMETER RoleId

Specifies the platform Id of the role to be associated with the specified management group

.PARAMETER ManagementGroupId

Specifies the platform Id of the management group to which the principal and role specified should be associated
#>

[CmdletBinding()]
Param(
     [Parameter(Mandatory=$true)] [int]$PrincipalId,
     [Parameter(Mandatory=$true)] [int]$RoleId,
     [Parameter(Mandatory=$true)] [int]$ManagementGroupId
)

if ($script:TACHYONMAJORVER -lt 8)
    {
    throw "This cmdlet is not available for this version of the platform"
    }

$payload = @"
[
  {
    "PrincipalId": $PrincipalId,
    "RoleId": $RoleId,
    "ManagementGroupId": $ManagementGroupId
  }
]
"@
$url = "/Consumer/PrincipalRoleManagementGroups"
$res = PostHttpRequest $url $payload
# TODO: currently returns silence from API if entry already present; see if this can be fixed
if (IsNullOrEmpty $res)
    {
    throw "The specified role and principal are already associated with this management group"
    }
return $res
}

function Remove-PrincipalRoleManagementGroup
{
<#
.SYNOPSIS

Removes the specified role and principal from the specified management group

.EXAMPLE

Remove-1EPrincipalRoleManagementGroup -PrincipalId 6 -RoleId 37 -ManagementGroupId 1

.PARAMETER PrincipalId

Specifies the platform Id of the principal to be removed from the specified management group

.PARAMETER RoleId

Specifies the platform Id of the role to be removed from the specified management group

.PARAMETER ManagementGroupId

Specifies the platform Id of the management group to which the principal and role specified should be associated

.NOTE

Roles and principals are added and removed from management groups as a pair. Removing a role/principal pair from a management group does not affect other pairs, even if they share a common role or principal

#>

[CmdletBinding()]
Param(
     [Parameter(Mandatory=$true)] [int]$PrincipalId,
     [Parameter(Mandatory=$true)] [int]$RoleId,
     [Parameter(Mandatory=$true)] [int]$ManagementGroupId
)

if ($script:TACHYONMAJORVER -lt 8)
    {
    throw "This cmdlet is not available for this version of the platform"
    }

$payload = @"
[
  {
    "PrincipalId": $PrincipalId,
    "RoleId": $RoleId,
    "ManagementGroupId": $ManagementGroupId
  }
]
"@
$url = "/Consumer/PrincipalRoleManagementGroups"
$res = DeleteHttpRequest $url $payload
return $res
}

function Remove-RoleFromPrincipal
{
<#
.SYNOPSIS

Removes the specified role from the principal

.EXAMPLE

Remove-1ERoleFromPrincipal -Id 5 -RoleId 13


.PARAMETER Id

Specifies the platform Id of the principal from which the role is to be removed

.PARAMETER RoleId

Specifies the platform Id of the role to remove from the principal

#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id,
     [Parameter(Mandatory=$true)] [int]$RoleId
     )
$roles = get-principalrole -id $Id | where-object {$_.RoleId -eq $RoleId}
if (IsNullOrEmpty $roles)
	{
	throw "This principal does not have the specified role"
	}

$url = "/Consumer/PrincipalRoles/Role/" + $RoleId
$payload = "[" + $id + "]"
$res = DeleteHttpRequest $url $payload
return $res
}


function Get-Role
{
<#
.SYNOPSIS

Retrieves all roles defined in the platform RBAC subsystem, or information on a single role, defined by its platform Id or name

.EXAMPLE

Get-1ERole

.PARAMETER Id

If specified, defines the platform Id of the role to retrieve information for

.PARAMETER Name

If specified, defines the name of the role to retrieve information for


#>
[CmdletBinding(DefaultParameterSetName ='Id')]

Param(
     [Parameter(Mandatory=$false,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$false,ParameterSetName='Name')] [string]$Name
     )

if ($id -eq 0)
    {
    $url = "/Consumer/Roles"
    if (-not (IsNullOrEmpty $Name))
        {
        $res = GetHttpRequest $url | where-object {$_.Name -eq $Name}
        if (IsNullOrEmpty $res)
            {
            throw "The specified role name could not be found"
            }
        return $res
        }
    }

if ($id -ne 0)
	{
	$url = "/Consumer/Roles/" + $Id
	}

$res = GetHttpRequest $url
return $res
}


function Get-AdminPrincipal
{
<#
.SYNOPSIS

Return all principals who have administrator rights

.EXAMPLE

Get-1EAdminPrincipal

#>
[CmdletBinding()]

Param(
     )
$url = "/Consumer/Principals/PermissionsAdmins"
$res = GetHttpRequest $url
return $res
}


# deploy as an allowed verb only in PS6, so using Send instead

function Send-Policy
{
<#
.SYNOPSIS

Sends (deploys) all active Guaranteed State policies. Any changes to these policies made since they were last deployed are published to all affected endpoints

.EXAMPLE

Send-1EPolicy

#>
[CmdletBinding()]

Param(
     )

	$url = "/Consumer/Policy"
	$res = PostHttpRequest $url
	return $res
}

function Get-PolicyEffectiveness
{
<#
.SYNOPSIS

Returns a summary by rule count of the effectiveness of all Guaranteed State policies, or the policy whose platform Id is specified.

.EXAMPLE

Get-1EPolicyEffectiveness

.PARAMETER Id

Specifies the platform Id of a specific Guaranteed State policy

.NOTES

The information returned summarises the count of rules which fall into each category (Disabled, Effective, Ineffective, Unassigned)

#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$false)] [int]$Id=0
     )
if ($id -eq 0)
	{
	$url = "/Consumer/Policy/Dashboard/PolicyEffectiveness"
	}
else
	{
	$policy = get-policy -Id $id
	if (IsNullOrEmpty $policy)
		{
		throw "The policy specified does not exist"
		}
	$url = "/Consumer/Policy/Dashboard/PolicyEffectiveness/" + $Id
	}

$res = GetHttpRequest $url
return $res

}


function Get-PolicyRuleRemediation
{
<#
.SYNOPSIS

Returns the remediation status over time for all Guaranteed State policies, or the policy specified by the optional Id parameter

.EXAMPLE

Get-1EPolicyRuleRemediation -Days 7


.PARAMETER Days

Specifies the number of days for which results should be returned

.PARAMETER Id

Specifies the platform Id of the Guaranteed State policy for which results should be returned.

#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [ValidateRange(1,366)][int]$Days,
     [Parameter(Mandatory=$false)] [int]$Id=0
     )
if ($id -eq 0)
	{
	$url = "/Consumer/Policy/Dashboard/PolicyRuleRemediation/" + $Days
	}
else
	{
	$policy = get-policy -Id $id
	if (IsNullOrEmpty $policy)
		{
		throw "The policy specified does not exist"
		}
	$url = "/Consumer/Policy/Dashboard/PolicyRuleRemediation/" + $Days + "/" + $Id
	}

$res = GetHttpRequest $url
return $res

}


function Enable-Policy
{
<#
.SYNOPSIS

Enables the specified Guaranteed State policy

.EXAMPLE

Enable-1EPolicy -Id 3


.PARAMETER Id

Specifies the platform Id of the policy to be enabled

#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id
     )
$url = "/Consumer/Policies/" + $Id + "/Enable/true"
$res = PostHttpRequest $url
return $res
}

function Disable-Policy
{
<#
.SYNOPSIS

Disables the specified Guaranteed State policy

.EXAMPLE

Disable-1EPolicy -Id 3


.PARAMETER Id

Specifies the platform Id of the policy to be disabled

#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id
     )
$url = "/Consumer/Policies/" + $Id + "/Enable/false"
$res = PostHttpRequest $url
return $res
}


function Get-PolicyChange
{
<#
.SYNOPSIS

Show all pending changes that will be applied if Guaranteed State policy deployment is requested

.EXAMPLE

Get-1EPolicyChange

#>
[CmdletBinding()]

Param(
     )
$url = "/Consumer/Policy/Changes"
$res = GetHttpRequest $url
return $res

}

function Add-PolicyAssignment
{
<#
.SYNOPSIS

Adds the specified management group to the Guaranteed State policy

.EXAMPLE

Add-1EPolicyAssignment -Id 2 -ManagementGroupId 3


.PARAMETER Id


Specifies the platform Id of the Guaranteed State policy

.PARAMETER ManagementGroupId

Specifies the platform Id of the management group to be added to the policy


#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id,
     [Parameter(Mandatory=$true)] [int]$ManagementGroupId
     )
$payload = @"
{
  "PolicyId": $($id),
  "ManagementGroupId": $($ManagementGroupId)
}
"@
$policyassignments = get-policyassignment | where-object {$_.PolicyId -eq $Id -and $_.ManagementGroupId -eq $ManagementGroupId}
if (-not (IsNullOrEmpty $policyAssignments))
	{
	throw "The specified management group is already associated with the policy"
	}
$url = "/Consumer/PolicyAssignments"
$res = PostHttpRequest $url $payload
return $res
}

function Remove-PolicyAssignment
{
<#
.SYNOPSIS

Removes the specified management group from the Guaranteed State policy

.EXAMPLE

Remove-1EPolicyAssignment -Id 2 -ManagementGroupId 3


.PARAMETER Id


Specifies the platform Id of the Guaranteed State policy

.PARAMETER ManagementGroupId

Specifies the platform Id of the management group to be removed from the policy


#>

[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id
     )
$url = "/Consumer/PolicyAssignments/" + $Id
$res = DeleteHttpRequest $url
return $res
}

function Set-Manifest
{
<#
.SYNOPSIS

Creates a manifest XML file suitable for use with an integrated product pack.

.EXAMPLE

Set-Manifest -Name MyManifest -Description MyManifest -Icon somefile.ico

.PARAMETER Name

Specifies the name of the manifest

.PARAMETER Description

Specifies the description of the manifest

.PARAMETER Icon

If specified, defines an icon file to be associated with the manifest

.PARAMETER Path

Specifies the name and path of the manifest file to be created

#>

[CmdletBinding()]
Param(
     [Parameter(Mandatory=$true)] [string]$Name,
     [Parameter(Mandatory=$true)] [string]$Description,
     [Parameter(Mandatory=$false)][string]$Icon,
     [Parameter(Mandatory=$true)] [string]$Path
     )
$res = ManifestToXml $Name $Description $Icon
set-content -Path $path -Value $res
return
}

function Export-Policy
{
<#
.SYNOPSIS

Exports the specified Guaranteed State policy along with all rules, fragments and trigger templates associated with the policy and creates a file suitable for use with the product pack import tool
You can then import the policy and its associated entities into another platform server instance using the product pack import tool

.EXAMPLE

Export-Policy -Name MyPolicy


.PARAMETER Id

Specifies the platform Id of the policy to export

.PARAMETER Name

Specifies the name of the policy to export

.PARAMETER Path

Specifies the path to a file which will contain the exported policy and its associated entities


#>

[CmdletBinding(DefaultParameterSetName='Name')]
Param(
     [Parameter(Mandatory=$true,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$true,ParameterSetName='Name')] [string]$Name,
     [Parameter(Mandatory=$true)][string]$Path
     )

$tmpDir = GetTempDir
if (IsNullOrEmpty $tmpDir)
    {
    throw "Unable to create temporary directory"
    }

$ruleDir = New-Item -ItemType Directory -Path (Join-Path $tmpdir "Rules")
$fragDir = New-Item -ItemType Directory -Path (Join-Path $tmpdir "Fragments")
$fragDirCheck = New-Item -ItemType Directory -Path (Join-Path $fragdir "Check")
$fragDirFix = New-Item -ItemType Directory -Path (Join-Path $fragdir "Fix")
$fragDirPrecon = New-Item -ItemType Directory -Path (Join-Path $fragdir "Precondition")
$polDir = New-Item -ItemType Directory -Path (Join-Path $tmpdir "Policies")
$trgDir = New-Item -ItemType Directory -Path (Join-Path $tmpdir "TriggerTemplates")
try
    {
    if (-not (IsNullOrEmpty $Name))
        {
        $x = get-policy -name $Name -asxml -path (join-path $polDir ($Name + ".xml"))
        $policy = get-policy -name $Name
        }
    else
        {
        $policy = get-policy -id $Id
        $x = get-policy -id $policy.Id -asxml -path (join-path $polDir ($policy.Name + ".xml"))
        }
    }
catch
    {
    $x = remove-item $tmpdir -recurse
    throw "Unable to retrieve specified policy"
    }

set-manifest -name $policy.name -description $policy.description -path (join-path $tmpdir "manifest.xml")

foreach ($rule in $policy.rules)
    {
    get-rule -id $rule.id -asxml -path (join-path $ruledir  ("Rule-" + $rule.Name + ".xml"))
    write-information -MessageData ([string](get-date) + " Exporting Rule: " + $rule.Name + " to folder: " + $ruleDir)
    if (-not (IsNullOrEmpty $rule.PreConditionFragment))
        {
            export-fragment -id $rule.PreConditionFragment.Id -file (join-path $fragDirPrecon ($rule.PreconditionFragment.Name + ".xml"))
        }

    if (-not (IsNullOrEmpty $rule.CheckFragment))
        {
            export-fragment -id $rule.CheckFragment.Id -file (join-path $fragDirCheck ($rule.CheckFragment.Name + ".xml"))
        }

    if (-not (IsNullOrEmpty $rule.FixFragment))
        {
            export-fragment -id $rule.FixFragment.Id -file (join-path $fragDirFix ($rule.FixFragment.Name + ".xml"))
        }

    foreach ($trigger in $rule.Triggers)
        {
        $trigtemplate = get-triggertemplate -id $trigger.triggertemplateid
        $x = get-triggertemplate -id $trigger.triggertemplateid -asxml -path (join-path $trgDir ("TriggerTemplate-" + $trigtemplate.Name + ".xml"))
        }
        
    }
Compress-Archive -Path (join-path $tmpdir "*") -DestinationPath $Path
$x = remove-item $tmpdir -recurse
}

function Get-Rule
{
<#
.SYNOPSIS

Retrieves the Guaranteed State rule specified either by platform Id or rule name

.EXAMPLE

Get-1ERule -Name MyRule


.PARAMETER Id

Specifies the platform Id of the rule to retrieve

.PARAMETER Name

Specifies the name of the rule to retrieve

.PARAMETER AsXml

Specifies that the result is returned as an XML string rather than a PowerShell object, suitable for saving as an XML file that can be used in an importable product pack

.PARAMETER Path

Specifies the name and path to a file which will be created (or overwritten) with the result


#>



[CmdletBinding(DefaultParameterSetName='Name')]
Param(
     [Parameter(Mandatory=$true,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$true,ParameterSetName='Name')] [string]$Name,
     [Parameter(Mandatory=$false)][switch]$AsXml = $false,
     [Parameter(Mandatory=$false)][string]$Path
     )
if (-not (IsNullOrEmpty $Name))
	{
	$rule = get-allrule | where-object {$_.Name -eq $Name} 
	$id = $rule.id
	}
$url = "/Consumer/Rules/" + $Id
$res = GetHttpRequest $url 
if ($AsXml)
    {
    $res = RuleToXml $res
    }
if (-not (IsNullOrEmpty $Path))
    {
    set-content -Path $path -Value $res
    return
    }
return $res
}

function Remove-Rule
{
<#
.SYNOPSIS

Removes (deletes) the Guaranteed State rule specified either by platform Id or rule name

.EXAMPLE

Remove-1ERule -Name MyRule

.PARAMETER Id

Specifies the platform Id of the rule to remove

.PARAMETER Name

Specifies the name of the rule to remove

.PARAMETER Force

Specifies that any Guaranteed State policy which includes the rule will have the rule removed from the policy. If not specified, any attempt to remove a rule which is associated with any policy will raise an exception


#>


[CmdletBinding(DefaultParameterSetName='Name', SupportsShouldProcess=$true)]
Param(
     [Parameter(Mandatory=$true,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$true,ParameterSetName='Name')] [string]$Name,
     [Parameter(Mandatory=$false)] [switch]$Force = $false
    )
    if (-not (IsNullOrEmpty $Name))
	{
	$rule = get-rule -Name $Name
	$id = $rule.Id
	}

if (-not $pscmdlet.ShouldProcess($Id))
{
	return get-rulepolicy -Id $Id
}
    if (-not $Force)
	{
	$pol = get-rulepolicy -Id $Id
	if (-not (IsNullOrEmpty $pol))
		{
		throw "This rule is associated with one or more active policies. Use -Force option to force delete"
		}
	}
$url = "/Consumer/Rules/" + $Id + "?force=true"
$res = DeleteHttpRequest $url 
return $res
}

function Get-TriggerTemplate
{
<#
.SYNOPSIS

Retrieves the Trigger Template specified either by platform Id or name

.EXAMPLE

Get-1ETriggerTemplate -Name MyTemplate


.PARAMETER Id

Specifies the platform Id of the trigger template to retrieve

.PARAMETER Name

Specifies the name of the trigger template to retrieve

.PARAMETER AsXml

Specifies that the result is returned as an XML string rather than a PowerShell object, suitable for saving as an XML file that can be used in an importable product pack

.PARAMETER Path

Specifies the name and path to a file which will be created (or overwritten) with the result


#>


[CmdletBinding(DefaultParameterSetName='Name')]
Param(
     [Parameter(Mandatory=$true,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$true,ParameterSetName='Name')] [string]$Name,
     [Parameter(Mandatory=$false)][switch]$AsXml = $false,
     [Parameter(Mandatory=$false)][string]$Path
     )
if (-not (IsNullOrEmpty $Name))
	{
	$template = get-alltriggertemplate | where-object {$_.Name -eq $Name}
	$id = $template.Id
	}
$url = "/Consumer/TriggerTemplates/" + $Id
$res = GetHttpRequest $url 
if ($AsXml)
    {
    $res =  TriggerTemplateToXml $res
    }

if (-not (IsNullOrEmpty $Path))
    {
    set-content -Path $path -Value $res
    return
    }
return $res
}


function Get-AllTriggerTemplate
{
<#
.SYNOPSIS

Retrieves all trigger templates

.EXAMPLE

Get-1EAllTriggerTemplate

#>

[CmdletBinding()]
Param(
     )

$url = "/Consumer/TriggerTemplates"
$res = GetHttpRequest $url 
return $res
}

function Get-Fragment
{
<#
.SYNOPSIS

Gets the Guaranteed State fragment specified either by platform Id or name

.EXAMPLE

Get-1EFragment -Name MyFragment

.PARAMETER Id

Specifies the platform Id of the fragment to retrieve

.PARAMETER Name

Specifies the name of the fragment to retrieve

#>
[CmdletBinding(DefaultParameterSetName='Name')]
Param(
     [Parameter(Mandatory=$true,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$true,ParameterSetName='Name')] [string]$Name
     )
if (-not (IsNullOrEmpty $Name))
	{
	$fragment = get-allfragment | where-object {$_.Name -eq $Name}
	$id = $fragment.Id
	}

$url = "/Consumer/Fragments/" + $Id
$res = GetHttpRequest $url 
return $res
}

function Get-Policy
{
<#
.SYNOPSIS

Gets the Guaranteed State policy specified either by platform Id or name

.EXAMPLE

Get-1EPolicy -Name MyPolicy

.PARAMETER Id

Specifies the platform Id of the policy to retrieve

.PARAMETER Name

Specifies the name of the policy to retrieve

.PARAMETER AsXml

Specifies that the result is returned as an XML string rather than a PowerShell object, suitable for saving as an XML file that can be used in an importable product pack

.PARAMETER Path

Specifies the name and path to a file which will be created (or overwritten) with the result


#>
[CmdletBinding(DefaultParameterSetName='Name')]
Param(
     [Parameter(Mandatory=$true,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$true,ParameterSetName='Name')] [string]$Name,
     [Parameter(Mandatory=$false)][switch]$AsXml = $false,
     [Parameter(Mandatory=$false)][string]$Path
     )
if (-not (IsNullOrEmpty $Name))
	{
	$policy = get-allpolicy | where-object {$_.Name -eq $Name}
	$id = $policy.Id
	}

$url = "/Consumer/Policies/" + $Id
$res = GetHttpRequest $url 

if ($AsXml)
    {
    $res = PolicyToXml $res
    }

if (-not (IsNullOrEmpty $Path))
    {
    set-content -Path $path -Value $res
    return
    }

return $res
}


function Remove-Policy
{
<#
.SYNOPSIS

Removes (deletes) the Guaranteed State policy specified either by platform Id or name

.EXAMPLE

Remove-1EPolicy -Name MyPolicy

.PARAMETER Id

Specifies the platform Id of the policy to remove

.PARAMETER Name

Specifies the name of the policy to remove

#>
[CmdletBinding(DefaultParameterSetName='Name')]
Param(
     [Parameter(Mandatory=$true,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$true,ParameterSetName='Name')] [string]$Name
     )
if (-not (IsNullOrEmpty $Name))
	{
	$policy = get-policy -Name $Name
	$id = $policy.Id
	}
$url = "/Consumer/Policies/" + $Id
$res = DeleteHttpRequest $url 
return $res
}

function Add-PolicyRule
{
<#
.SYNOPSIS

Adds the specified rule to a Guaranteed State policy

.EXAMPLE

Add-1EPolicyRule -Id 3 -RuleId 4

.PARAMETER Id

Specifies the platform Id of the policy to which the rule is to be added

.PARAMETER RuleId

Specifies the platform Id of the rule to add to the policy

#>

[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)] [int]$Id,
    [Parameter(Mandatory=$true)] [int]$RuleId
     )
# this will throw with a meaningful error if rule not found
[void](get-rule -Id $RuleId)
$policy = get-policy -id $Id
$policyRules = $policy.Rules
$found = $false
foreach ($policyRule in $policyRules)
	{
	if ($policyRule.Id -eq $ruleId)
		{
		$found = $true
		break
		}
	}
if ($found)
	{
	throw "Specified rule is already associated with the policy"
	}

$payload = "[" + $RuleId + "]"
$url = "/Consumer/Policies/" + $id + "/Rules"
[void](PostHttpRequest $url $payload)
$rules = New-Object System.Collections.Generic.List[System.Object]
$policyRules = get-policyrules -Id $Id
foreach ($policyRule in $policyRules)
	{
	$ruleLite = getRuleLite $policyRule
	[void]$rules.Add($ruleLite)
	}
return $rules.ToArray()
}


function Remove-PolicyRule
{
<#
.SYNOPSIS

Removes the specified rule from a Guaranteed State policy

.EXAMPLE

Remove-1EPolicyRule -Id 3 -RuleId 4

.PARAMETER Id

Specifies the platform Id of the policy from which the rule is to be removed

.PARAMETER RuleId

Specifies the platform Id of the rule to remove from the policy

.NOTES

The rule itself is not deleted. It is only removed from the rule collection of the specified policy

#>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)] [int]$Id,
    [Parameter(Mandatory=$true)] [int]$RuleId
     )
# this will throw with a meaningful error if rule not found
[void](get-rule -Id $RuleId)
$policy = get-policy -id $Id
$policyRules = $policy.Rules
$found = $false
foreach ($policyRule in $policyRules)
	{
	if ($policyRule.Id -eq $ruleId)
		{
		$found = $true
		break
		}
	}
if (-not $found)
	{
	throw "Specified rule is not associated with the policy"
	}

$url = "/Consumer/Policies/" + $id + "/Rules/" + $RuleId
[void](DeleteHttpRequest $url)
$rules = New-Object System.Collections.Generic.List[System.Object]
$policyRules = get-policyrules -Id 11
foreach ($policyRule in $policyRules)
	{
	$ruleLite = getRuleLite $policyRule
	[void]$rules.Add($ruleLite)
	}
return $rules.ToArray()
}

function Get-PolicyRule
{
<#
.SYNOPSIS

Retrieves the rules associated with the specified policy

.EXAMPLE

Get-1EPolicyRule -Id 3

.PARAMETER Id

Specifies the platform Id of the policy for which the rules are to be listed

.PARAMETER Full

Specifies that the full rule information is to be retrieved, rather than a summary

#>

[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)] [int]$Id,
    [Parameter(Mandatory=$false)] [switch]$Full
     )

$policy = get-policy -Id $Id
$rules = New-Object System.Collections.Generic.List[System.Object]
foreach ($policyRule in $policy.Rules)
	{
	if ($Full)
		{
		[void]$rules.Add($policyRule)
		}
	else
		{
	        $ruleLite = GetRuleLite $policyRule
		[void]$rules.Add($ruleLite)
		}
	}
return $rules.ToArray()
}

function Add-Policy
{
<#
.SYNOPSIS

Adds the specified Guaranteed State policy

.EXAMPLE

Add-1EPolicy -Name NewPolicy -Description "A new policy" 

.PARAMETER Name

Specifies the name of the new policy. Names must be unique across policies

.PARAMETER Description

Specifies the description for the new policy

.PARAMETER Disabled

Specifies that the new policy should be created in the disabled state (enabled = false)

#>

[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true)] [string]$Name,
    [Parameter(Mandatory=$true)] [string]$Description,
    [Parameter(Mandatory=$false)] [switch]$Disabled = $false
     )
if ($Disabled)
	{
	$enabled = "false"
	}
else
	{
	$enabled = "true"
	}
$payload = @"
	{
	  "Name": "$($Name)",
	  "Description": "$($Description)",
	  "Enabled": $($enabled),
	  "Rules": [
	  ]
	}
"@
$url = "/Consumer/Policies"
$res = PostHttpRequest $url $payload
return $res
}

function Get-SystemTopography
{
<#
.SYNOPSIS

Returns information about the platform server topography (i.e, information on key components)

.EXAMPLE

Get-1ESystemTopography

#>

[CmdletBinding()]
Param(
     )

$url = "/Consumer/SystemInformation/GetSystemTopography"
$res = GetHttpRequest $url 
return $res.DataStores
}

function Get-AllRule
{
<#
.SYNOPSIS

Retrieves all Guaranteed State rules

.EXAMPLE

Get-1EAllRule

.PARAMETER Unlicensed

Specifies that only unlicensed rules are to be returned

#>

[CmdletBinding()]

Param(
    [Parameter(Mandatory=$false)] [switch]$Unlicensed = $false
     )

if (-not $Unlicensed)
	{
	# we don't call the /consumer/rules api here because it is too verbose
	return SearchRules "%"
	}
else
	{
	$url = "/Consumer/Rules/Unlicensed"
	$res = GetHttpRequest $url 
	return $res
	}
}


function Get-RuleHistory
{
<#
.SYNOPSIS

Retrieves the revision history for the specified rule

.PARAMETER Id

Specifies the Id of the rule for which history is to be retrieved

.PARAMETER Revision

If specified, returns information only about the specified revision for the rule

.PARAMETER Full

Specifies that the full information about each revision of the rule is returned. If not specified, a summary for each revision is returned instead

.EXAMPLE

Get-1ERuleHistory -Id <Id>


#>

[CmdletBinding()]

Param(
    [Parameter(Mandatory=$true)] [int]$Id,
    [Parameter(Mandatory=$false)] [int]$Revision,
    [Parameter(Mandatory=$false)] [switch]$Full = $false
     )

if ($Revision -gt 0)
	{
	$url = "/Consumer/RuleRevisionHistory/" + $Id + "/Revision/" + $Revision
	}
else
	{
	$url = "/Consumer/RuleRevisionHistory/" + $Id
	}
$res = GetHttpRequest $url 

if ($Full)
	{
	return $res
	}	
else
	{
	$res = $res |select-object -Property Name,Description,Revision,CreatedTimeStampUtc,LastProcessedTimeStampUtc,ModifiedBy
	return $res
	}
}

function Publish-Fragment
{
<#
.SYNOPSIS

Publishes (uploads) the specified Guaranteed State fragment file to the platform server

.EXAMPLE

Publish-1EFragment -File MyNewFragment.xml

.PARAMETER File

Specifies the file name of the fragment XML file to publish

.NOTES

From platform version 5.1 onwards, fragment files are required to be signed with an appropriate code signing certificate, as was always the case with instruction XML files

#>

[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [string]$File
     )
$inst = MultipartWrap $file
$r = UploadFragment $inst
return $r
}

function Remove-Fragment
{
<#
.SYNOPSIS

Removes (deletes) the specified Guaranteed State fragment

.EXAMPLE

Remove-1EFragment -Id 3

.PARAMETER Id

Specifies the platform Id of the fragment to remove

.PARAMETER Force

If specified, causes any rule that uses the fragment to also be removed. Otherwise, if an attempt is made to remove a fragment which is associated with one or more rules, an exception is raised

#>

[CmdletBinding(SupportsShouldProcess=$true)]

Param(
     [Parameter(Mandatory=$true)] [int]$Id,
     [Parameter(Mandatory=$false)] [switch]$Force
     )
if ($pscmdlet.ShouldProcess($Id))
{
	if ($force)
		{
		$deletedRules = New-Object System.Collections.Generic.List[System.Object]
		$fragRules = get-fragmentrule -id $Id
		foreach ($rule in $fragRules)
			{
			remove-rule -id $rule.Id -Force
			[void]$deletedRules.Add($rule)
			}
		$url = "/Consumer/Fragments/" + $Id
		$res = DeleteHttpRequest $url
		return $deletedRules.ToArray()
		}
}
else
{
		$deletedRules = New-Object System.Collections.Generic.List[System.Object]
		$fragRules = get-fragmentrule -id $Id
		foreach ($rule in $fragRules)
			{
			[void]$deletedRules.Add($rule)
			}
		return $deletedRules.ToArray()
}	
$url = "/Consumer/Fragments/" + $Id
$res = DeleteHttpRequest $url
return $res
}

function Get-FragmentParameter
{
<#
.SYNOPSIS

Gets the parameters (if any) available for a fragment in a form directly suitable for use with the Add-1ERule cmdlet

.EXAMPLE

Get-1EFragmentParameter -Id 17

.PARAMETER Id

Specifies the Id of the fragment whose parameters are to be returned


#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id
     )
$frag = get-fragment -id $Id
$paramList = New-Object System.Collections.Generic.List[System.Object]
if (IsNullOrEmpty $frag.ParameterJson)
    {
    return $paramList
    }
$fragParams = $frag.ParameterJson | convertfrom-json
foreach ($param in $fragparams)
    {
    $p = New-Object PSObject -Property @{
            Name = TransformParamName $param.Name $frag.Name
            DataType = $param.DataType
            }
    [void]$paramList.Add($p)
    }
return $paramList
}

function Get-TriggerTemplateParameter
{
<#
.SYNOPSIS

Gets the parameters (if any) available for a trigger template in a form directly suitable for use with the Add-1ERule cmdlet

.EXAMPLE

Get-1ETriggerTemplateParameter -Id 17

.PARAMETER Id

Specifies the Id of the Trigger Template whose parameters are to be returned


#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id
     )
$trig = get-triggertemplate -id $Id
$paramList = New-Object System.Collections.Generic.List[System.Object]
if ($null -eq $trig.UserParameters -or $trig.UserParameters.Count -eq 0)
    {
    return $paramList
    }
$trigParams = $trig.UserParameters 
foreach ($param in $trigparams)
    {
    $p = New-Object PSObject -Property @{
            Name = TransformParamName $param.Name $trig.Name
            DataType = $param.DataType
            }
    [void]$paramList.Add($p)
    }
return $paramList
}



function Get-FragmentRule
{
<#
.SYNOPSIS

Gets the rules which use a specified Guaranteed State fragment

.EXAMPLE

Get-1EFragmentRule -Id 3

.PARAMETER Id

Specifies the platform Id of the fragment for which rules are to be returned

#>

[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id
     )

return get-allrule | where-object {$_.CheckFragmentId -eq $id -or $_.FixFragmentId -eq $id -or $_.PreConditionFragmentId -eq $Id}
}

function Add-Rule
{
<#
.SYNOPSIS

Creates a new rule, attaching it to one or more trigger templates and a check fragment. You can optionally specify a precondition and fix fragment to be associated with the rule

.EXAMPLE

Add-1ERule -Name MyNewRule -Description "A new rule" -TriggerTemplateIds @(17,4) -CheckFragmentId 17

.PARAMETER Name

Specifies the name of the rule to be created

.PARAMETER Description

Specifies the description of the rule to be created

.PARAMETER TriggerTemplateIds

Specifies one or more trigger templates to be associated with the rule. At least one trigger template is required

.PARAMETER CheckFragmentId

Specifies the Id of a check fragment to be associated with the rule. The rule must have a check fragment

.PARAMETER PreconditionFragmentId

Optionally specifies the Id of a precondition fragment to be associated with the rule. 

.PARAMETER FixFragmentId

Optionally specifies the Id of a fix fragment to be associated with the rule. If a fix fragment Id is specified, the rule is created as a fix rule, otherwise, it is created as a check rule


.PARAMETER Disable

Specifies that the rule is to be created in a disabled state. Otherwise it is created enabled

.NOTES

Trigger templates and fragments may have parameters. If these parameters have default values, then these are automatically used when creating the rule.
If these parameters do not have default values, then you will be prompted to supply them. Parameters have the format <template or fragment name>?<parameter name> so that, for example

add-1Erule -name newrule14 -Description fff -triggertemplateids 16 -checkfragmentid 1 -WindowsSecurityEventLog?Query xx -WindowsSecurityEventLog?AuditSubcategoryGuid 3123 _1E_GuaranteedState_Check_MEMCM_AssignedSite?SiteCode 122

We are supplying some parameters here on the command line. Because each fragment or template name is unique, the combination of the name and the parameter allows us to pass unique parameters to the cmdlet.
Note that where the name begins with a digit we must add an underscore on the front to prevent PowerShell from failing to recognise the parameter.

You can override default parameter values by supply an explicit value on the command line.

To determine the parameters available for a fragment or a trigger template, use the get-1Etriggertemplateparameter or get-1Efragmentparameter cmdlet.

#>


Param(
     [Parameter(Mandatory=$true)] [string]$Name,
     [Parameter(Mandatory=$true)] [string]$Description,
     [Parameter(Mandatory=$true)] [int]$CheckFragmentId,
     [Parameter(Mandatory=$true)] [int[]]$TriggerTemplateIds,
     [Parameter(Mandatory=$false)] [int]$PreconditionFragmentId,
     [Parameter(Mandatory=$false)] [int]$FixFragmentId,
     [Parameter(Mandatory=$false)] [switch]$Disable
     )

DynamicParam {
    $OFFSET = 4 #Change if fixed param count above changes 
    # we need the mandatory checkfragmentid param here and if the user hasn't already put it on the command line, by the time we get prompted, it's too late
    if ((IsNullOrEmpty $checkfragmentId) -or $CheckfragmentId -eq 0)
        {
        throw "You must specify a check fragment id"
        }

    $ret = ProcessDynamicArgsForRule $triggerTemplateIds $checkFragmentId $PreconditionFragmentId $FixFragmentId $OFFSET
    return $ret.Dict
    }

Process
{
$params = BuildParams $ret.Metadata $PSBoundParameters | convertfrom-json

$checkfrag = get-fragment -id $CheckFragmentId
$checkfragparams = GetEntityParams $params $checkfrag.Name

$preconfragparams = @()
if ($preconditionFragmentId -ne 0)
    {
    $preconfrag = get-fragment -id $PreconditionFragmentId
    $preconfragparams = GetEntityParams $params $preconfrag.Name
    }

$fixfragparams = @()
if ($fixFragmentId -ne 0)
    {
    $fixfrag = get-fragment -id $FixFragmentId
    $fixfragparams = GetEntityParams $params $fixfrag.Name
    }

If ($TriggerTemplateIds.Count -eq 0)
    {
    throw "At least one trigger template is required"
    }

$trigs = New-Object System.Collections.Generic.List[System.Object]
$procTrigs = @{}
$index = 0
foreach ($template in $TriggerTemplateIds)
    {
    $t = get-triggertemplate -id $template
    # we can specify a trigger template multiple times, so we need to check this
    if ($null -ne $procTrigs[$t.Name])
        {
        $paramname = findNewName $procTrigs $t.Name ([ref]$index)
        }
    else
        {
        $paramname = $t.Name
        }
    $procTrigs[$paramname] = $paramname
    $paramname = $paramname.Replace("_","-")
    $triggerParams = GetEntityParams $params $paramName
    $trig = New-Object PSObject -Property @{
            TriggerTemplateId = $template
            UserParameters = @($triggerParams)
            }
    [void]$trigs.add($trig)
    }


if ($Disable)
    {
    $ruleState = $false
    }
else
    {
    $ruleState = $true
    }

if ($FixFragmentId -ne 0)
    {
    $ruleType = 2
    }
else
    {
    $ruleType = 1
    }


$model = New-Object PSObject -Property @{
            Type = $ruleType
            Name = $Name
            Description = $Description
            PreConditionFragmentId = $PreconditionFragmentId
            PreConditionParameters = @($preconfragparams)
            FixFragmentId = $FixFragmentId
            FixParameters = @($fixfragparams)
            CheckFragmentId = $CheckFragmentId
            CheckParameters = @($checkfragparams)
            Triggers=@($trigs.ToArray())
            Enabled = $ruleState
            }

$url = "/consumer/rules"
$modelJson = convertto-json $model -Depth 99
$res = PostHttpRequest $url $modelJson
return $res
}
}

function Update-Rule
{
<#
.SYNOPSIS

Updates attributes of an existing rule. Attributes which are not specified are left unchanged

.EXAMPLE

Update-1ERule -Id 3

.PARAMETER Id

Specifies the platform Id of the rule to be updated

.PARAMETER Description

Specifies the description of the rule that should be modified

.PARAMETER Name

Specifies the name of the rule that should be modified. An error is returned if the new name would conflict with an existing rule name and no changes are made

.PARAMETER Enable

Specifies that the rule should be enabled.

.PARAMETER Disable

Specifies that the rule should be disabled.

.PARAMETER TriggerTemplateIds

If specified, replaces the existing trigger templates (and their parameter values) associated with the rule. 

.PARAMETER CheckFragmentId

If specified, replaces the existing check fragment (and its parameter values) associated with the rule.

.PARAMETER PreconditionFragmentId

If specified, replaces (or adds) a precondition fragment (and its parameter values) to be associated with the rule. If the value is -1, then the existing precondition fragment (if any) is removed from the rule

.PARAMETER FixFragmentId

If specified, replaces (or adds) a fix fragment (and its parameter values) to be associated with the rule. If the value is -1 then the existing fix fragment (if any) is removed from the rule.
If a fix fragment is added, the rule is updated to be a fix rule. If a fix fragment is removed, the rule is updated to be a check rule.


.NOTES

For releases of the platform prior to 8.3, updating a rule assigns a new rule Id to the rule and causes all rule compliance history to be lost.

#>

[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id,
     [Parameter(Mandatory=$false)] [string]$Description,
     [Parameter(Mandatory=$false)] [string]$Name,
     [Parameter(Mandatory=$false)] [switch]$Enable,
     [Parameter(Mandatory=$false)] [switch]$Disable,
     [Parameter(Mandatory=$false)] [int]$CheckFragmentId,
     [Parameter(Mandatory=$false)] [int[]]$TriggerTemplateIds,
     [Parameter(Mandatory=$false)] [int]$PreconditionFragmentId,
     [Parameter(Mandatory=$false)] [int]$FixFragmentId
     )

DynamicParam {
    $OFFSET = 1 #Change if fixed param count above changes 
    $r = get-rule -Id $id # make sure we throw straightaway if id invalid
    # this will also throw straightaway if any of the passed Ids aren't valid, to avoid you being prompted for params and then having the cmdlet fail.
    $ret = ProcessDynamicArgsForRule $triggerTemplateIds $checkFragmentId $PreconditionFragmentId $FixFragmentId $OFFSET
    return $ret.Dict
    }
Process
    {
    if ((IsNullOrEmpty $Description) -and (IsNullOrEmpty $Name) -and ($Enable -eq $false) -and ($Disable -eq $false) -and ($CheckFragmentId -eq 0) -and ($TriggerTemplateIds -eq 0 -or $TriggerTemplateIds.Count -eq 0) -and ($PreconditionFragmentId -eq 0) -and ($FixFragmentId -eq 0))
        {
        throw "You must specify at least one parameter to update"
        }
    $params = BuildParams $ret.Metadata $PSBoundParameters | convertfrom-json
    $url = "/Consumer/Rules"

    $r = get-rule -Id $id

    $model = BuildUpdateableRuleModel $r

    if (-not (IsNullOrEmpty $Description))
        {
        $model.Description = $Description
        }

    if (-not (IsNullOrEmpty $Name))
        {
        $model.Name = $Name
        }

    if ($Enable)
        {
        $model.Enabled = $true
        }    

    if ($Disable)
        {
        $model.Enabled = $false
        }    

    if (($null -ne $CheckFragmentId) -and ($CheckFragmentId -ne 0))
        {
        $checkfrag = get-fragment -id $CheckFragmentId
        $checkfragparams = GetEntityParams $params $checkfrag.Name
        }

    if (($null -ne $PreconditionFragmentId) -and ($PreconditionFragmentId -ne 0))
        {
        if ($PreconditionFragmentId -eq -1)
            {
            $model.PSObject.Properties.Remove("PreconditionFragmentId")
            $model.PSObject.Properties.Remove("PreconditionParameters")
            }
        else
            {
            $preconfragparams = @()
            $preconfrag = get-fragment -id $PreconditionFragmentId
            $preconfragparams = GetEntityParams $params $preconfrag.Name
            }
        }

    if (($null -ne $FixFragmentId) -and ($FixFragmentId -ne 0))
        {
        if ($FixFragmentId -eq -1)
            {
            $model.PSObject.Properties.Remove("FixFragmentId")
            $model.PSObject.Properties.Remove("FixParameters")
            }
        else
            {
            $fixfragparams = @()
            $fixfrag = get-fragment -id $FixFragmentId
            $fixfragparams = GetEntityParams $params $fixfrag.Name
            }
        }

    if (($null -ne $TriggerTemplateIds) -and (($TriggerTemplateIds -ne 0) -or ($TriggerTemplateIds.Count -gt 0)))
        {

        $trigs = New-Object System.Collections.Generic.List[System.Object]
        $procTrigs = @{}
        $index = 0
        foreach ($template in $TriggerTemplateIds)
            {
            $t = get-triggertemplate -id $template
            # we can specify a trigger template multiple times, so we need to check this
            if ($null -ne $procTrigs[$t.Name])
                {
                $paramname = findNewName $procTrigs $t.Name ([ref]$index)
                }
            else
                {
                $paramname = $t.Name
                }
            $procTrigs[$paramname] = $paramname
            $paramname = $paramname.Replace("_","-")
            $triggerParams = GetEntityParams $params $paramName
            $trig = New-Object PSObject -Property @{
                    TriggerTemplateId = $template
                    UserParameters = @($triggerParams)
                    }
            [void]$trigs.add($trig)
            }
        }
   
    if (($null -ne $CheckFragmentId) -and ($CheckFragmentId -ne 0))
        {
        $model.CheckFragmentId = $CheckFragmentId
        $model.CheckParameters = @($checkfragparams)
        }

    if (($null -ne $FixFragmentId) -and ($FixFragmentId -gt 0))
        {
        $model.FixFragmentId = $FixFragmentId
        $model.FixParameters = @($fixfragparams)
        }

    if (($null -ne $PreconditionFragmentId) -and ($PreconditionFragmentId -gt 0))
        {
        $model.PreconditionFragmentId = $PreconditionFragmentId
        $model.PreconditionParameters = @($preconfragparams)
        }

    if (($null -ne $TriggerTemplateIds) -and (($TriggerTemplateIds -ne 0) -or ($TriggerTemplateIds.Count -gt 0)))
        {
        $model.Triggers=@($trigs.ToArray())
        }
    if ($null -ne $model.FixFragmentId)
        {
        $model.Type = 2
        }
    else
        {
        $model.Type = 1
        }
    $modelJson = convertto-json $model -Depth 99
    $res = PutHttpRequest $url $modelJson
    return $res
    }
}




function Get-RulePolicy
{
<#
.SYNOPSIS

Retrieves any Guaranteed State policies that include the specified rule

.EXAMPLE

Get-1ERulePolicy -Id 3

.PARAMETER Id

Specifies the platform Id of the rule

#>

[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id
     )
$includedPolicies = New-Object System.Collections.Generic.List[System.Object]
$policies = get-allpolicy
foreach ($pol in $policies)
	{
	foreach ($rul in $pol.Rules)
		{
		if ($rul -eq $id)
			{
			[void]$includedPolicies.Add($pol)
			break
			}
		}
	}
return $includedPolicies.ToArray()
}

function Get-AllFragment
{
<#
.SYNOPSIS

Retrieves all Guaranteed State fragments

.EXAMPLE

Get-1EAllFragment

#>

[CmdletBinding()]
Param()

$url = "/Consumer/Fragments/Shallow/All"
$res = GetHttpRequest $url
return $res
}

function Publish-Instruction
{
<#
.SYNOPSIS

Publishes (uploads) the specified instruction XML file to the platform server

.EXAMPLE

Publish-1EInstruction -File 1E-Exchange-MyNewInstruction.xml -InstructionSet MySet

.PARAMETER File

Specifies the instruction XML file to publish

.PARAMETER InstructionSet

Specifies the name of the instruction set to which the instruction should be assigned

.PARAMETER Force

If specified, causes any active instructions of the same name to be stopped, then deletes the existing instruction and uploads the specified file. 

.NOTES

Instruction XML files must be signed
An instruction XML file that has an instruction version less than or equal to the same named instruction already on the server cannot be published unless the -Force parameter is specified

#>

[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [string]$File,
     [Parameter(Mandatory=$true)] [string]$InstructionSet,
     [Parameter(Mandatory=$false)] [switch]$force
     )
# force will cancel all running instances of instruction and delete instruction itself, so that it can be replaced, even with same version

if ($force)
	{
    $xml = get-instructionxml -file $file
    $instName = $xml.Name
	$activeInsts = get-activeinstruction | where-object {$_.Name -eq $instName}
	foreach ($inst in $activeInsts)
		{
		stop-instruction -Id $inst.Id
		}
	$pendingInsts = get-instructionhistory | where-object {$_.Name -eq $instName -and $_.Status -eq "Authenticating"}
	foreach ($inst in $pendingInsts)
		{
		stop-instruction -Id $inst.Id
		}
	try
		{
		remove-instruction -Name $instName
		}
	catch
    	{
		}
	}


$inst = MultipartWrap $file
$r = UploadInstructionToSetName $inst $InstructionSet
return $r
}

function Get-Instruction
{
<#
.SYNOPSIS

Retrieves information about all instructions on the platform server

.PARAMETER Id

If specified, defines the platform Id for the instruction whose details are to be returned

.PARAMETER Name

If specified, defines the nane of the instruction whose details are to be returned

.EXAMPLE

Get-1EInstruction

#>

[CmdletBinding(DefaultParameterSetName='Name')]
param
(
     [Parameter(Mandatory=$false,ParameterSetName='Name')] [string]$Name,
     [Parameter(Mandatory=$false,ParameterSetName='Id')] [int]$Id
)

$url= "/consumer/InstructionDefinitions/all"

if ($Id -ne 0)
	{
	$url= "/consumer/InstructionDefinitions/Id/" + $Id
	}

if (-not (IsNullOrEmpty $Name))
	{
	$url= "/consumer/InstructionDefinitions/Name/" + $Name
	}
$url += "?dataSourceFilter=All"

$res = GetHttpRequest $url

return $res
}


function Move-Instruction
{
<#
.SYNOPSIS

Moves an instruction from its current instruction set to the new instruction set defined

.PARAMETER Id

Defines the platform Id for the instruction to be moved

.PARAMETER Name

If specified, defines the nane of the instruction to be moved

.PARAMETER SetId

Defines the Id of the instruction set into which the instruction is to be moved

.EXAMPLE

Move-1EInstruction -Id 3 -SetId 4

#>

[CmdletBinding(DefaultParameterSetName='Name')]
param
(
     [Parameter(Mandatory=$true,ParameterSetName='Name')] [string]$Name,
     [Parameter(Mandatory=$true,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$true)] [int]$SetId
)

if (-not (IsNullOrEmpty $Name))
	{
	$instr = get-instruction -name $Name
    $id = $instr.Id
	}


$payload = @"
{
  "SetId": $($SetId),
  "InstructionDefinitionIds": [
    $($Id)
  ]
}
"@

$url= "/consumer/InstructionSets/Contents"

$res = PostHttpRequest $url $payload

return $res
}


function Get-ComponentHealth
{
<#
.SYNOPSIS

Returns information on the status of various key platform subsystem components

.EXAMPLE

Get-1EComponentHealth

#>

[CmdletBinding()]
param()
$url= "/consumer/ComponentHealth"
$res = GetHttpRequest $url
return $res	
}

function Get-InstructionSet
{
<#
.SYNOPSIS

Retrieves all instruction sets defined on the platform server

.EXAMPLE

Get-1EInstructionSet

#>

[CmdletBinding()]
param()
$url= "/consumer/InstructionSets"
$res = GetHttpRequest $url
return $res	
}

function Get-DeviceTag
{
<#
.SYNOPSIS

Retrieves all defined device tags on the platform server

.EXAMPLE

Get-1EDeviceTag
#>

[CmdletBinding()]
param()
$url= "/consumer/CustomProperties/TypeName/CoverageTag"
$res = GetHttpRequest $url
return $res	
}

function Get-DeviceTagName
{
<#
.SYNOPSIS

Retrieves the Device tag name for the Device tag whose platform Id is specified

.EXAMPLE

Get-1EDeviceTagName -Id 4

.PARAMETER Id

Specifies the platform Id of the Device tag

#>

[CmdletBinding()]
Param(
     [Parameter(Mandatory=$true)] [int]$Id
     )
$tag = get-Devicetag | where-object {$_.Id -eq $($Id)}
return $tag.Name
}

function Get-DeviceTagId
{
<#
.SYNOPSIS

Retrieves the Device tag Id for the Device tag whose name is specified

.EXAMPLE

Get-1EDeviceTagId -Name MyTag

.PARAMETER Name

Specifies the name of the Device tag

#>

[CmdletBinding()]
Param(
     [Parameter(Mandatory=$true)] [string]$Name
     )
$tag = get-Devicetag | where-object {$_.Name -eq $($Name)}
return $tag.Id
}

function Get-DeviceTagValue
{
<#
.SYNOPSIS

Gets the values associated with the specified Device tag

.EXAMPLE

Get-1EDeviceTagValue -Name MyTag

.PARAMETER Id

Specifies the platform Id of the Device tag

.PARAMETER Name

Specifies the platform name of the Device tag

#>

[CmdletBinding(DefaultParameterSetName='Name')]
Param(
     [Parameter(Mandatory=$true,ParameterSetName='Name')] [string]$Name,
     [Parameter(Mandatory=$true,ParameterSetName='Id')] [int]$Id
     )
if (-not (IsNullOrEmpty $Name))
	{
	$id = get-Devicetagid $name
	}
$url= "/consumer/CustomPropertyValues/Property/" + $id
$res = GetHttpRequest $url
return $res	
}

function Add-DeviceTagValue
{
<#
.SYNOPSIS

Adds the specified value to the Device tag value set

.EXAMPLE

Add-1EDeviceTagValue -Name MyTag -Value MyValue

.PARAMETER Id

Specifies the platform Id of the Device tag

.PARAMETER Name

Specifies the platform name of the Device tag

.PARAMETER Value

Specifies the value to be added to the Device tag value set

#>

[CmdletBinding(DefaultParameterSetName='Name')]
Param(
     [Parameter(Mandatory=$true,ParameterSetName='Name')] [string]$Name,
     [Parameter(Mandatory=$true,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$true)] [string]$Value
     )
if (-not (IsNullOrEmpty $Name))
	{
	$id = get-Devicetagid $name
	}
$payload = @"
{
  "Id": 0,
  "Value": $(quotify $Value),
  "PropertyId": $($Id)
}
"@
$url= "/consumer/CustomPropertyValues"
$res = PostHttpRequest $url $payload
return $res	
}

function Remove-DeviceTagValue
{
<#
.SYNOPSIS

Removes the specified value from the Device tag value set

.EXAMPLE

Remove-1EDeviceTagValue -Name MyTag -Value MyValue

.PARAMETER Id

Specifies the platform Id of the Device tag

.PARAMETER Name

Specifies the platform name of the Device tag

.PARAMETER Value

Specifies the value to be removed from the Device tag value set

#>

[CmdletBinding(DefaultParameterSetName='Name')]
Param(
     [Parameter(Mandatory=$true,ParameterSetName='Name')] [string]$Name,
     [Parameter(Mandatory=$true,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$true)] [string]$Value
     )
if (-not (IsNullOrEmpty $Name))
	{
	$id = get-Devicetagid $name
	}
$allvals = get-Devicetagvalue -Id $id
$tagval = $allvals | where-object {$_.Value -eq $($Value)}
if ($null -eq $tagval)
	{
	throw "The specified value does not exist for this Device tag"
	}
if ($null -eq $allvals.Count)
    {
    throw "You cannot delete this value as it is the only value associated with this tag"
    }

$url= "/consumer/CustomPropertyValues"
# {id} variant of this endpoint doesn't seem to work properly
$payload = "[" + $tagVal.Id + "]"
$res = DeleteHttpRequest $url $payload
return $res	
}


function Add-DeviceTag
{
<#
.SYNOPSIS

Adds the specified Device tag, along with an initial value set

.EXAMPLE

Add-1EDeviceTag -Name MyTag -Values @("MyValue1","MyValue2")

.PARAMETER Name

Specifies the name of the Device tag to be added

.PARAMETER Values

Specifies the initial value set for the Device tag

#>

[CmdletBinding()]
Param(
     [Parameter(Mandatory=$true)] [string]$Name,
     [Parameter(Mandatory=$true)] [string[]]$Values
     )

$valueList = New-Object System.Collections.Generic.List[System.Object]

foreach ($value in $values)
    {
    $v = New-Object PSObject -Property @{
                Id = 0
                Value = $value
                PropertyId = 0
                }
    $valueList.add($v)
    }
$valuesJson = convertto-json $valueList
$payload = '{"Values":' + $valuesJson 
$suffix = @"
  ,"Name": $(quotify $Name),
  "TypeName": "CoverageTag"
  }
"@
$payload += $suffix

$url= "/consumer/CustomProperties"
$res = PostHttpRequest $url $payload
return $res	
}


function Remove-DeviceTag
{
<#
.SYNOPSIS

Removes (deletes) the Device tag specified, along with its value set

.EXAMPLE

Remove-1EDeviceTag -Name MyTag


.PARAMETER Id

Specifies the platform Id of the Device tag to be removed

.PARAMETER Name

Specifies the name of the Device tag to be removed


#>



[CmdletBinding(DefaultParameterSetName='Name')]
Param(
     [Parameter(Mandatory=$true,ParameterSetName='Name')] [string]$Name,
     [Parameter(Mandatory=$true,ParameterSetName='Id')] [int]$Id
     )
if (-not (IsNullOrEmpty $Name))
	{
	$id = get-Devicetagid $name
	}
$url= "/consumer/CustomProperties/$($id)"
$res = DeleteHttpRequest $url
return $res	
}


function Get-ActiveInstruction
{
<#
.SYNOPSIS

Returns all instruction which are currently active i.e, in-flight

.EXAMPLE

Get-1EActiveInstruction

.PARAMETER Full

If specified, returns full information for each instruction rather than a summary

#>

[CmdletBinding()]
param(
     [Parameter(Mandatory=$False)] [switch]$Full=$false
)

$res = GetActiveInstructions
if ($Full)
	{
	return $res	
	}
else
	{
	$instructions = New-Object System.Collections.Generic.List[System.Object]
	foreach ($r in $res)
		{
	        $value = New-Object PSObject -Property @{
        	        Id = $r.Id
			Name = $r.Name
			CreatedTimestampUTC = $r.CreatedTimeStampUTC
			CreatedBy = $r.CreatedBy
                	}
		$instructions.Add($value)
		}	
	return $instructions
	}
}

function Get-InstructionStatus
{
<#
.SYNOPSIS

Returns the status of a specified instruction

.EXAMPLE

Get-1EInstructionStatus -Id 32

.PARAMETER Id

Specifies the platform Id for the instruction whose status is to be returned

.PARAMETER Full

Specifies that full information on the instruction is returned, rather than summary information

#>

[CmdletBinding()]
Param(
     [Parameter(Mandatory=$true)] [int]$Id,
     [Parameter(Mandatory=$false)] [switch]$Full
     )
$url= "/consumer/Instructions/" + $id
$res = GetHttpRequest $url
if (-not $Full)
    {
    return DecodeInstructionStatus $res.Status
    }
$res.Status = DecodeInstructionStatus $res.Status
$res.WorkFlowState = DecodeWorkflowState $res.WorkflowState
return $res
}

function Stop-Instruction
{
<#
.SYNOPSIS

Stops (terminates) an active instruction.

.EXAMPLE

Stop-1EInstruction -Id 26

.PARAMETER Id

Specifies the platform Id of the instruction to be stopped

.PARAMETER DeleteResults

If specifies, causes all results associated with the instruction to be deleted. Otherwise, the results collected up to the point the instruction was stopped remain available until the results time to live expires

#>
[CmdletBinding()]
Param(
     [Parameter(Mandatory=$true)] [int]$Id,
     [Parameter(Mandatory=$false)] [switch]$DeleteResults=$false
     )


$url = "/consumer/Instructions/" + $id + "/Cancel/" + (-not $deleteResults) + "?dataSourceFilter=All"
$res = PostHttpRequest $url ""
return $res
}


function Restart-Instruction
{
<#
.SYNOPSIS

Restarts (re-runs) the specified instruction, with all parameters as specified the previous time the instruction was run

.EXAMPLE

Restart-1EInstruction -Id 23

.PARAMETER Id

Specifies the platform Id of the instruction to be restarted

.PARAMETER DrillDown

Specifies that the results from the instruction should be collected at detail level, rather than aggregated

.PARAMETER ResultFilter

Specifies a result filter expression that allows the results to be filtered prior to being returned to the user

#>
[CmdletBinding()]
Param(
     [Parameter(Mandatory=$true)] [int]$Id,
     [Parameter(Mandatory=$false)] [switch]$DrillDown,
     [Parameter(Mandatory=$false)] [string]$Resultfilter
     )


$url = "/consumer/Instructions/" + $id + "/Rerun"
$res = PostHttpRequest $url ""
if ($null -ne $res -and $null -ne $res.Id)
    {
    $script:gLastInstructionId = $res.Id
    $res = getinstructionresults $res.Id $drilldown $resultFilter
    }
return $res
}

function New-SLAManagementGroup
{
<#
.SYNOPSIS

Creates a new SLA management group with the rules specified

.EXAMPLE

New-1ESLAManagementGroup -Name NewGroup -Description "My New group" -Rules "[ReportProductCatalog.Vendor] in (Vendor1,Vendor2,Vendor3)"

.PARAMETER Name

Specifies the name of the new group to be created. Each management group name must be distinct

.PARAMETER Description

Specifies a description for the new group. If not specified, the management group name is also used as its description

.PARAMETER Rules

Specifies a rule expression which combines one or more management group rule attributes to determine the devices that will fall into the scope of the management group.

.PARAMETER ParentId

Optionally specifies the Id of a management group which will become the parent of this group


.NOTES

To obtain a list of rule attributes use the Get-1ESLAManagementGroupRuleAttribute cmdlet.
Valid rule attribute names are derived by combining the RecordTypeDisplayName member and RecordTypeAttributeName member to create a dotted pair, as in the example above.

If you receive a permission denied error when attempting to create a management group with a parent, it is possible that the parent management group has not yet been synchronised from SLA to the platform
To synchronise a management group, use the xxxxx cmdlet.

#>

[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)] [string]$Name,
[Parameter(Mandatory=$false)] [string]$Description,
[Parameter(Mandatory=$true)] [string]$Rules,
[Parameter(Mandatory=$false)] [int]$ParentId
)

if (IsNullOrEmpty $Description)
    {
    $Description = $Name
    }

$ruleJson = get-slamanagementgrouprule -expression $Rules

$payload = @"
{
    "Rules": $($ruleJson),
    "Name": $(quotify $Name),
    "Description": $(quotify $Description),
    "RuleType": "RuleBased",
    "Parent": $(getParentJson $ParentId)
}
"@

$url = "/Admin/ManagementGroupsEx"
$res = PostHttpRequest $url $payload
return $res

}

function Get-SLAManagementGroupDevice
{
<#
.SYNOPSIS

Returns a list of devices which are members of the SLA management group Id specified

.EXAMPLE

Get-1ESLAManagementGroupDevice -Id 1


.PARAMETER Id
Specifies the Id of the management group in SLA. 

.PARAMETER RepositoryId
Specifies the Id of the SLA repository to be queried for device membership

.NOTES

Currently the underlying API called returns an error if the management group specified contains no devices.

#>

[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id,
     [Parameter(Mandatory=$true)] [int]$RepositoryId
     )
$url = "/Admin/ManagementGroupsEx/SearchMemberFqdn/" + $Id + "/" + $RepositoryId
$payload = @"
{
    "Start": 1,
    "PageSize": 1000,
    "Filter": {
     },
    "Sort": [
        {
            "Column": "Fqdn",
            "Direction": "ASC"
        }
    ]
}
"@

$res = PostHttpRequestPaged $url $payload
return $res
}

function Get-ManagementGroupReadPermission
{
<#
.SYNOPSIS

Returns management groups that user has permission to read

.EXAMPLE

Get-1EManagementGroupReadPermission

#>

[CmdletBinding()]
Param()
$url = "/consumer/ManagementGroups/SecurableType/Security/Operation/Read"
$ret = GetHttpRequest $url
return $ret | where-object {$_.CallerHasPermissionToAccess -eq $true}
}

function Get-ManagementGroupWritePermission
{
<#
.SYNOPSIS

Returns management groups that user has permission to write to

.EXAMPLE

Get-1EManagementGroupWritePermission

#>

[CmdletBinding()]
Param()
$url = "/consumer/ManagementGroups/SecurableType/Security/Operation/Write"
$ret = GetHttpRequest $url
return $ret | where-object {$_.CallerHasPermissionToAccess -eq $true}
}


function Get-ManagementGroupDependency
{
<#
.SYNOPSIS

Returns entities that depend on a management group. These may need to be deleted before a group can be deleted

.PARAMETER Id

Specifies the Usable Id parameter of the management group


.EXAMPLE

Get-1EManagementGroupDependency -Id 3

#>

[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)] [int]$Id
)
$url = "/consumer/ManagementGroups/AffectedEntities/UsableId/" + $Id
$ret = GetHttpRequest $url
return $ret
}

function Get-InvestigationCategory
{
<#
.SYNOPSIS

Returns the available platform Experience investigation categories

.EXAMPLE

Get-1EInvestigationCategory

#>

[CmdletBinding()]
Param()
$url = "/Experience/InvestigationCategories"
$ret = GetHttpRequest $url
return $ret
}


function Get-InvestigationCategoryMetric
{
<#
.SYNOPSIS

Returns the available metrics for a platform Experience investigation category

.EXAMPLE

Get-1EInvestigationCategoryMetric -Name Network

#>

[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)] [string]$Name
)
$url = "/Experience/InvestigationCategories/Metrics/" + $Name
$ret = GetHttpRequest $url
return $ret
}


function Get-InvestigationCategoryAttribute
{
<#
.SYNOPSIS

Returns the available attributes for a platform Experience investigation category

.EXAMPLE

Get-1EInvestigationCategoryAttribute -Name Network

#>

[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)] [string]$Name
)
$url = "/Experience/InvestigationCategories/Attributes/" + $Name
$ret = GetHttpRequest $url
return $ret
}

function Get-MetricInformation
{
<#
.SYNOPSIS

Returns information about platform experience metrics. If the optional Id or Name parameter is specified, only the information for the specified metric is returned
Otherwise information on all metrics is returned

.EXAMPLE

Get-1EMetricInformation

.PARAMETER Name

Specifies the name of the metric to return information for

.PARAMETER Id

Specifies the Id of the metric to return information for. 

#>

[CmdletBinding(DefaultParameterSetName = 'Name')]
Param(
[Parameter(Mandatory=$false, ParameterSetName='Name')][string]$Name,
[Parameter(Mandatory=$false, ParameterSetName='Id')][int]$Id
)
$url = "/Experience/Metrics/Metadata"
$ret = GetHttpRequest $url
if ($Id -ne 0)
    {
    return $ret | where-object {$_.Id -eq $Id}
    }
if (-not (IsNullOrEmpty $name))
    {
    return $ret | where-object {$_.Name -eq $Name}
    }
return $ret
}

function Export-Survey
{
<#
.SYNOPSIS

Exports a platform survey definition to a file that can be used to import the survey definition subsequently

.EXAMPLE

Export-1ESurvey -Name MySurvey -Path c:\surveys\mysurvey.json

.PARAMETER Name

Specifies the name of the survey for which data is to be exported

.PARAMETER Path

Specifies the name and path to a file which will contain the exported data, in JSON format

#>

[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)] [string]$Name,
[Parameter(Mandatory=$true)] [string]$Path
)
$survey = Get-Survey -Name $Name
if (IsNullOrEmpty $survey)
	{
	throw "The requested survey could not be found"
	}
$surveyJson = convertto-json $survey -Depth 99
set-content -Path $path -Value $surveyJson
return "Survey " + $Name  + " exported successfully"
}

function Import-Survey
{
<#
.SYNOPSIS

Creates a new survey definition from an exported survey definition file

.EXAMPLE

Import-1ESurvey -Name MySurvey -Path c:\surveys\mysurvey.json

.PARAMETER Name

Specifies the name of the survey to be created from the export file

.PARAMETER Path

Specifies the name and path to a file which will contain the exported survey data, in JSON format

#>

[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)] [string]$Name,
[Parameter(Mandatory=$true)] [string]$Path
)

$surveyJson = Get-Content -Path $Path -Raw

if (IsNullOrEmpty $surveyJson)
	{
	throw "The survey definition file does not contain valid survey information"
	}
$survey = convertfrom-json $surveyJson

$payload = @"
{
"Name": $(quotify $Name),
"Question": $(quotify $Survey.Question),
"Description": $(quotify $Survey.Description),
"Link": $(quotify $Survey.Link),
"SurveyType": $(ValOrNull $Survey.SurveyType),
"Choices": $(convertto-json $Survey.Choices -Depth 99),
"DefaultChoiceIndex": $(ValOrNull $Survey.DefaultChoiceIndex 0),
"Validation": $($Survey.Validation),
"AllowFreeText": $(([string]$Survey.AllowFreeText).ToLower()),
"PromptFrequencyDays": $($Survey.PromptFrequencyDays),
"DeadLine": $(quotifyOrNull $Survey.Deadline),
"TemplateType": $(convertto-json $Survey.TemplateType -Depth 99),
"From": $(quotifyOrNull $Survey.From),
"Icon": $(quotifyOrNull $Survey.Icon),
"Notes": $(quotifyOrNull $Survey.Notes),
"HighPriority": $(([string]$Survey.HighPriority).ToLower()),
"SenderDesignation": $(quotifyOrNull $Survey.SenderDesignation),
"SourceId": $($Survey.SourceId),
"SubscriptionId": $($Survey.SubscriptionId),
"CreatedBy": $(quotify $Survey.CreatedBy),
"CreatedTimestampUtc": $(quotify $Survey.CreatedTimestampUtc)
}
"@

$url = "/Experience/Surveys"
$ret = PostHttpRequest $url $payload
return $ret
}

function Get-Survey
{
<#
.SYNOPSIS

Returns all platform Experience surveys or the survey specified by name or id

.EXAMPLE

Get-1ESurvey

.PARAMETER Name

Specifies the name of the survey for which data is to be returned. If not specified, all surveys are returned

#>

[CmdletBinding(DefaultParameterSetName = 'Name')]
Param(
[Parameter(Mandatory=$false, ParameterSetName = 'Name')] [string]$Name,
[Parameter(Mandatory=$false, ParameterSetName = 'Id')] [int]$Id
)

$url = "/Experience/Surveys"
if ($id -ne 0)
    {
    $url += "/" + $Id
    }
$ret = GetHttpRequest $url
if (-not (IsNullOrEmpty $Name))
    {
    $ret = $ret | where-object {$_.Name -eq $Name}
    }
return $ret
}

function Remove-Survey
{
<#

.SYNOPSIS

Removes the survey defined by its name or survey id

.EXAMPLE

Remove-1ESurvey -Name MySurvey

.PARAMETER Name

Specifies the name of the survey to be removed

.PARAMETER Id

Specifies the Id of the survey to be removed


#>

[CmdletBinding(DefaultParameterSetName = 'Name')]
Param(
[Parameter(Mandatory=$false, ParameterSetName = 'Name')] [string]$Name,
[Parameter(Mandatory=$false, ParameterSetName = 'Id')] [int]$Id
)

$url = "/Experience/Surveys"


if (-not (IsNullOrEmpty $Name))
{
    $ret = $ret | where-object {$_.Name -eq $Name}
    if (IsNullOrEmpty $ret)
        {
        throw "The specified survey could not be located"
        }
    $id = $ret.Id
}
$url += "/" + $Id
$ret = DeleteHttpRequest $url 
return $ret
}


function Enable-Survey
{
<#
.SYNOPSIS

Enables the specified Experience survey

.EXAMPLE

Enable-1ESurvey -Id 3


.PARAMETER Id

Specifies the platform Id of the survey to be enabled

#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id
     )
$url = "/Experience/Surveys/" + $Id +"/Enable"
$payload = "true"
$res = PostHttpRequest $url $payload
return $res
}

function Disable-Survey
{
<#
.SYNOPSIS

Disables the specified Experience survey

.EXAMPLE

Disable-1ESurvey -Id 3


.PARAMETER Id

Specifies the platform Id of the survey to be disabled

#>
[CmdletBinding()]

Param(
     [Parameter(Mandatory=$true)] [int]$Id
     )
$url = "/Experience/Surveys/" + $Id +"/Enable"
$payload = "false"
$res = PostHttpRequest $url $payload
return $res
}


function Get-SurveyResponse
{
<#
.SYNOPSIS

Returns responses for the specified survey

.EXAMPLE

Get-1ESurveyResponse -Id 3

.PARAMETER Id

Specifies the Id of the survey for which data is to be returned.

#>


[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)] [int]$Id
)
$url = "/Experience/Surveys/Responses/" + $Id
$payload = @"
{
"Start": 1,
"PageSize": 2000
}
"@
$ret = PostHttpRequestPaged $url $payload
return $ret.Items
}

function Get-Topic
{
<#
.SYNOPSIS

Returns all platform Experience topics or information for the specified topic

.EXAMPLE

Get-1ETopic

.PARAMETER Name

Specifies the name of the topic for which data is to be returned.

.PARAMETER Id

Specifies the Id of the topic for which data is to be returned.


#>

[CmdletBinding(DefaultParameterSetName = 'Name')]
Param(
[Parameter(Mandatory=$false, ParameterSetName = 'Name')] [string]$Name,
[Parameter(Mandatory=$false, ParameterSetName = 'Id')] [int]$Id
)
$url = "/Experience/Topics"
$ret = GetHttpRequest $url
if ($Id -ne 0)
    {
    $ret = $ret | where-object {$_.Id -eq $Id}
    }

if (-not (IsNullOrEmpty $Name))
{
    $ret = $ret | where-object {$_.Name -eq $Name}
}
return $ret
}

function Set-SLADirectManagementGroup
{
<#
.SYNOPSIS

Creates or updates an SLA direct membership management group

.EXAMPLE

Set-1ESLADirectManagementGroup -Name NewGroup -Description "My New group" -FqdnList @("urth-sql.urth.local","urth-dev.urth.local")

.PARAMETER Name

Specifies the name of the new group to be created. Each management group name must be distinct

.PARAMETER Description

Specifies a description for the new group. If not specified, the management group name is also used as its description

.PARAMETER FqdnList

Specifies a list of one or more Fqdns to be set as the group direct members

.NOTES

This cmdlet will immediately initiate the synchronisation of the created or updated management group with the platform.

#>

[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)] [string]$Name,
[Parameter(Mandatory=$true)] [string[]]$FqdnList,
[Parameter(Mandatory=$false)] [string]$Description
)
if (IsNullOrEmpty $Name)
    {
    throw "Management group name must be specified"
    }

if (IsNullOrEmpty $Description)
    {
    $Description = $Name
    }

$url = "/Admin/ManagementGroups/Upload/" + $Name + "/" + $Description
$payload = convertto-json $FqdnList
$res = PostHttpRequest $url $payload
return $res
}

function Update-SLAManagementGroup
{
<#
.SYNOPSIS

Updates an SLA management group

.EXAMPLE

Update-1ESLAManagementGroup -Id 6 -Name NewGroup -Description "My New group" -Rules "[ReportProductCatalog.Vendor] in (Vendor1,Vendor2,Vendor3)"

.PARAMETER Id

Specifies the Id of the group to be updated

.PARAMETER Description

Specifies a description for the group.

.PARAMETER Rules

Specifies a rule expression which combines one or more management group rule attributes to determine the devices that will fall into the scope of the management group.

.PARAMETER ParentId

Optionally specifies the Id of a management group which will become the parent of this group


.NOTES

To obtain a list of rule attributes use the Get-1ESLAManagementGroupRuleAttribute cmdlet.
Valid rule attribute names are derived by combining the RecordTypeDisplayName member and RecordTypeAttributeName member to create a dotted pair, as in the example above.

If you receive a permission denied error when attempting to create a management group with a parent, it is possible that the parent management group has not yet been synchronised from SLA to the platform.
To synchronise a management group, use the xxxxx cmdlet.

#>

[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)]  [int]$Id,
[Parameter(Mandatory=$false)] [string]$Name,
[Parameter(Mandatory=$false)] [string]$Description,
[Parameter(Mandatory=$false)] [string]$Rules,
[Parameter(Mandatory=$false)] [switch]$RemoveParent,
[Parameter(Mandatory=$false)] [int]$ParentId
)

$mg = get-slamanagementgroup -id $Id -IncludeRules

# don't allow direct membership groups to be updated
if ($mg.RuleType -ne "RuleBased")
    {
    throw "Only rule-based management groups are updateable. This management group has a rule type of " + $mg.RuleType
    }

# defend against a current API issue
if ($parentId -ne 0 -and $parentid -eq $mg.Id)
    {
    throw "Cannot specify management group as its own parent"
    }

if (-not (IsNullOrEmpty $Rules))
    {
    $mgRules = get-slamanagementgrouprule -expression $Rules
    }
else
    {
    $mgRules = $mg.Rules | convertto-json -depth 99
    }

if (-not (IsNullOrEmpty $Name))
    {
    $mgName = $Name
    }
else
    {
    $mgName = $mg.Name
    }

if (-not (IsNullOrEmpty $Description))
    {
    $mgDesc = $Description
    }
else
    {
    $mgDesc = $mg.Description
    }

if ($ParentId -ne 0)
    {
    $mgParentId = $ParentId
    }
else
    {
    $mgParentId = $mg.Parent.Id
    }

if ($RemoveParent)
    {
    $mgParentId = 0
    }

$payload = @"
{
    "Id": $($Id),
    "Rules": $($mgRules),
    "Name": $(quotify $mgName),
    "Description": $(quotify $mgDesc),
    "RuleType": "RuleBased",
    "Parent": $(getParentJson $mgParentId)
}
"@

$url = "/Admin/ManagementGroupsEx"
$res = PutHttpRequest $url $payload
return $res

}



function Sync-SLAManagementGroup
{
<#
.SYNOPSIS

Synchronises the specified SLA management group and repository with the platform.

.EXAMPLE

Sync-1ESLAManagementGroup -Id 2 -RepositoryId 1

.PARAMETER Id

Specifies the Id of the management group to be synchronised

.PARAMETER RepositoryId

Specifies the Id of the associated repository (see notes)


.NOTES

In order for child management groups to be created from a management group, the parent management group must first be synchronised, otherwise an error will be thrown when it is specified as the new group's parent
If a synchronisation process is already underway, invoking this cmdlet will return no data. Otherwise information on the sync process is returned
In the event that an existing synchronisation process is underway, new sync requests are queued and will be processed when previous sync requests complete.

To retrieve the Id of the associated repository, use the get-1Eslarepository cmdlet. Normally the repository is Default Inventory. The Id member of the repository is the value to use
#>

[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)] [int]$Id,
[Parameter(Mandatory=$true)] [int]$RepositoryId
)
$url = "/admin/ManagementGroupsEx/EvaluateManagementGroup"
$payload = @"
    {
    "RepositoryId" : $($RepositoryId),
    "ManagementGroupId" : $($Id)
    }
"@
$res = PostHttpRequest $url $payload
return $res
}

# get management groups from SLA rather than the platform

function Get-SLAManagementGroup
{
<#
.SYNOPSIS

Returns all SLA management groups or the group specified by the -Id or -Name property

.PARAMETER Id

Specifies the platform Id of the management group to be returned

.PARAMETER Name

Specifies the name of the management group to be returned

.Parameter IncludeRules

If specified, causes the rules associated with the selected management group or all groups, to be returned

.EXAMPLE

Get-1ESLAManagementGroup -Name MG1 

.NOTES

SLA management groups are those created inside the SLA subsystem. They will become visible to the platform, and hence retrievable using the Get-1EManagementGroup cmdlet
once an SLA sync has been performed.
Note that SLA management groups have different properties, such as rules, which are not visible when querying groups via the Get-1EManagementGroup cmdlet
SLA management groups do not have a useableID property. When they are synchronised with the platform, the internal platform management group will be allocated a useableId property
SLA management groups can have a parent group. This cmdlet will 'flatten out' the management group hierarchy and return a group or groups that match the search criteria regardless of their depth

#>

[CmdletBinding(DefaultParameterSetName='Name')]
Param(
     [Parameter(Mandatory=$false,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$false,ParameterSetName='Name')] [string]$Name,
     [Parameter(Mandatory=$false)] [switch]$IncludeRules
     )

if ($IncludeRules)
	{
	$url = "/admin/ManagementGroupsEx?WithRules=true"
	}
else
	{
	$url = "/admin/ManagementGroupsEx?WithRules=false"
	}

$res = GetHttpRequest $url 
return getChildMGs -MGList $res -Name $Name -Id $Id
}


function Get-ManagementGroup
{
<#
.SYNOPSIS

Returns all management groups or the group specified by the -Id, -UsableId or -Name property

.PARAMETER Id

Specifies the platform Id of the management group to be returned

.PARAMETER UsableId

Specifies the UsableId of the management group to be returned (see notes)

.PARAMETER Name

Specifies the name of the management group to be returned

.PARAMETER Devices

Specifies that the devices which are contained in the management group are to be returned
This parameter is ignored if the -Source parameter is specified as SLA

.PARAMETER Source

Specifies the source for the management group information. This can be either "Platform" (the default) or "SLA"

.EXAMPLE

Get-1EManagementGroup -Name MG1

.NOTES

When using management group Ids in scope expressions, you should use the UsableId property of the management group, not its platform Id. 
SLA management groups are those created inside the SLA subsystem. They will become visible to the platform, and hence retrievable using the Get-1EManagementGroup cmdlet with -Source Platform
once an SLA sync has been performed. They can be retrieved at any time with the -Source property set to SLA
Note that SLA management groups have different properties, such as rules, which are not visible when querying groups via the Get-1EManagementGroup cmdlet using -Source Platform
SLA management groups do not have a useableID property. When they are synchronised with the platform, the internal platform management group will be allocated a useableId property

#>
[CmdletBinding(DefaultParameterSetName='Name')]
Param(
     [Parameter(Mandatory=$false,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$false,ParameterSetName='UsableId')] [int]$UsableId,
     [Parameter(Mandatory=$false,ParameterSetName='Name')] [string]$Name,
     [Parameter(Mandatory=$false)] [switch]$Devices,
     [Parameter(Mandatory=$false)]
	[ValidateSet("SLA","Platform")] [string]$Source = "Platform"	
     )
if ($Source -eq "SLA")
	{
	if ($UsableId -ne 0 -or $Devices)
		{
		throw "UsableId and Devices parameters are not valid for SLA source"
		}
	if ($id -ne 0)
		{
		return Get-SLAManagementGroup -Id $id
		}
	if (-not (IsNullOrEmpty $Name))
		{
		return Get-SLAManagementGroup -Name $Name
		}
	return Get-SLAManagementGroup
	}

$url = "/consumer/ManagementGroups"

if ($Devices)
	{
	if ($Id -eq 0 -and $UsableId -eq 0 -and (IsNullOrEmpty $Name))
		{
		throw "You must specify a management group via the -Id, -UsableId or -Name property when using the -Devices switch"
		}
	$url += "/Contents"
	}

if ($id -ne 0)
	{
	$url += "/Id/" + $Id
	}

if ($UsableId -ne 0)
	{
	$url += "/UsableId/" + $UsableId
	}

if (-not (IsNullOrEmpty $Name))
	{
	$url += "/Name/" + (ToBase64 $Name)
	}


$res = GetHttpRequest $url 
return $res
}


function Get-InstructionStatistics
{
<#
.SYNOPSIS

Returns instruction statistics for the specified instruction (e.g, number of devices to which the instruction has been sent, etc)

.EXAMPLE

Get-1EInstructionStatistics -Id 23

.PARAMETER Id

Specifies the platform Id of the instruction for which statistics are requested

#>

[CmdletBinding()]
Param(
     [Parameter(Mandatory=$true)] [int]$Id
     )
    return (GetStatistics $id)
}

function Get-Notification
{
<#
.SYNOPSIS

Retrieves any notifications that have been sent to the user account currently interacting with the platform server or details of a specific notification, given by the Id specified

.EXAMPLE

Get-1ENotification


.PARAMETER Id

Specifies the platform Id of the notification for which details are to be returned

#>

[CmdletBinding()]
Param(
     [Parameter(Mandatory=$false)] [int]$Id = $null
     )

if ($null -eq $Id)
	{
	$url = "/consumer/Notifications"
	}
else
	{
	$url = "/consumer/Notifications/" + $id
	}
$res = GetHttpRequest $url
return $res
}

function Get-ApprovalNotification
{
<#
.SYNOPSIS

Retrieves any notifications relating to workflow approvals for the user interacting with the platform

.EXAMPLE

Get-1EApprovalNotification

#>

[CmdletBinding()]
Param(
     )

$url = "/consumer/Approvals/Notifications"
$res = GetHttpRequest $url
return $res
}



function ConvertFrom-Raw
{
<#
.SYNOPSIS

Converts raw data from an instruction stored in a file back to an in-memory representation, identical to that which would have been returned if the instruction had not been run in Raw mode

.EXAMPLE

$myResults = ConvertFrom-1ERaw -File MyRawInstructionResults.json


.PARAMETER File

Specifies the input file containing the raw JSON data from an instruction


#>

[CmdletBinding()]
param(
     [Parameter(Mandatory=$true)] [string]$File
)

$valueSet = @{}
$res = get-content $file | convertfrom-json
foreach ($r in $res)
    {
    $responses = $r.Responses
    foreach ($response in $responses)
	{
	    $fqdn = $response.Fqdn
        if ($null -eq $fqdn)
            {
            $fqdn = $AGGREGATEKEY # assume aggregated result set
            }
        if ($response.Status -eq 0)
            {
            $value = $Response.Values
            }
        else
            {        
            $value = New-Object PSObject -Property @{
                 ErrorData = $response.ErrorData
                 Status = $response.Status
                }
            }
	    if (-not $valueSet.ContainsKey($fqdn))
	     {
	     $deviceValues = New-Object System.Collections.Generic.List[System.Object]
	     $deviceValues.Add($value)
	     $valueSet[$fqdn] = $deviceValues
	     }
	else
	     {
	     $valueSet[$fqdn].Add($Value)
	     }
	}
    }
return $valueSet
}

function Optimize-Memory
{
<#
.SYNOPSIS

Invokes the PowerShell garbage collector. This may free up memory in some situations

.EXAMPLE

Optimize-1EMemory

#>
[CmdletBinding()]
param()
[system.gc]::Collect() 
}

function Get-InstructionHistory
{
<#
.SYNOPSIS

Retrieves all or part of the instruction history. 

.EXAMPLE

Get-1EInstructionHistory -ItemCount 1


.PARAMETER ItemCount

Specifies the number of items to return (all history is otherwise returned). History is sorted by descending date/time, so an itemcount of 1 will always return the most recent item in history

#>

[CmdletBinding()]
param
(
     [Parameter(Mandatory=$false)] [int]$ItemCount = 0
)
$PAGESIZE = 10000

$payload = @"
	    {
        "PageSize":$($PAGESIZE),
        "Start":1,
        "Sort": 
            [{
            "Column": "CreatedTime",
            "Direction": "DESC"
            }]
        }
"@

$res = PostHttpRequestPaged "/consumer/instructions/search?DataSourceFilter=All" $payload
# translate numeric status and type to human-readable. Note this is a little inefficient if we retrieve all history and then only ask for 1 item, will review later
foreach ($item in $res.Items)
	{
	$item.Status = DecodeInstructionStatus $item.Status
	$item.InstructionType = DecodeInstructionType $item.InstructionType
	}
if ($itemcount -gt 0)
	{
	return $res.Items[0..($itemcount - 1)]
	}

return $res.Items
}


function Get-TargetFileInstructionStatus
{
<#
.SYNOPSIS

Returns the status for each instruction recorded in the specified target file.

.EXAMPLE

Get-1ETargetFileInstructionStatus -TargetFile results.json


.PARAMETER TargetFile

Specifies the target file to be read

.NOTES

Target files are created using the -TargetFile option of the Invoke-Instruction cmdlet. They track the success or failure of an instruction as it is delivered to each endpoint and are useful in staged rollout scenarios

#>

[CmdletBinding()]
param(
     [Parameter(Mandatory=$true)] [string]$TargetFile
     )
$contents = get-content $TargetFile | convertfrom-json
$instrIds = @{}
$statuses = New-Object System.Collections.Generic.List[System.Object]
foreach ($item in $contents)
    {
    $instrIds[$item.Id] = $item.Id
    }
foreach ($key in $instrIds.Keys)
    {
    $status = get-instructionstatus $instrIds[$key] -Full
    $statuses.add($status)
    }
return $statuses.ToArray()
}

function Get-InstructionStatusDesc
{
<#
.SYNOPSIS

Decodes a numeric instruction status as recorded by the platform to a human-readable form

.EXAMPLE

Get-1EInstructionStatusDesc -Value 1

.PARAMETER Value

Specifies the numeric status code to be decoded

#>

[CmdletBinding()]
param(
     [Parameter(Mandatory=$true)] [int]$value
     )
return DecodeInstructionStatus $value
}

function Get-WorkflowStateDesc
{
<#
.SYNOPSIS

Decodes a numeric workflow state as recorded by the platform to a human-readable form

.EXAMPLE

Get-1EWorkflowStateDesc -Value 1


.PARAMETER Value

Specifies the numeric state value to be decoded

#>

[CmdletBinding()]
param(
     [Parameter(Mandatory=$true)] [int]$value
     )
return DecodeWorkflowState $value
}

function Get-InstructionMetaData
{
<#
.SYNOPSIS

Retrieves information about the specified platform instruction, such as its parameters

.EXAMPLE

Get-1EInstructionMetaData -Name 1E-Explorer-MyInstruction

.PARAMETER Id

Specifies the platform Id of the instruction for which metadata is to be returned

.PARAMETER Name

Specifies the name of the instruction for which metadata is to be returned

.PARAMETER Schema

If specified, causes the returned data schema of the instruction to be returned

#>

[CmdletBinding(DefaultParameterSetName='Name')]
param(
     [Parameter(Mandatory=$true,ParameterSetName='Id')] [int]$Id,
     [Parameter(Mandatory=$true,ParameterSetName='Name')] [string]$Name,
     [Parameter(Mandatory=$False)] [switch]$Schema
     )

if (-not (IsNullOrEmpty $name))
    {
    $res = GetInstructionMetaDataByName $Name
    }
else
    {
    $res = GetInstructionMetaDataById $Id
    }
if ($schema)
    {
    return GetSchema $res.Schema
    }
return $res
}

function Get-InstructionResult
{
<#
.SYNOPSIS

Returns the results of the instruction specified

.EXAMPLE

Get-1EInstructionResult -Id 42

.PARAMETER Id

Specifies the platform Id of the instruction entry in instruction history for which results are to be returned

.PARAMETER DrillDown

Specifies that results are to be returned in detail form rather than aggregated

.PARAMETER ResultFilter

Specifies a result filter which will filter the results returned to the user

.PARAMETER Raw

Specifies a file to which results will be written in raw form. If not specified, results are returned directly for assignment to a PowerShell variable

.PARAMETER ReceivedOnly

Specifies that only the currently received results will be returned. If an instruction is in progress, the current received count will be taken to be the result count to be returned
When an instruction transitions to 'Complete', this parameter will have no effect. All available rows will be taken as the final result set, since no further devices can now contribute data

.NOTES

You cannot retrieve the results of an instruction from history if the results time to live for that instruction has expired

You cannot retrieve the results of an instruction in detail form if the instruction was not originally run with the -Drilldown option specified, because only aggregated data is available otherwise


#>

[CmdletBinding()]
param(
     [Parameter(Mandatory=$true)] [int]$Id,
     [Parameter(Mandatory=$false)] [switch]$DrillDown,
     [Parameter(Mandatory=$false)] [string]$Resultfilter,
     [Parameter(Mandatory=$false)] [string]$Raw,
     [Parameter(Mandatory=$false)] [switch]$ReceivedOnly
     )

return GetInstructionResults $id $drilldown $Resultfilter $Raw $ReceivedOnly
}

function Get-TargetFromFile 
{
<#
.SYNOPSIS

Returns a list of target fqdns from results in a target file

.EXAMPLE

Get-1ETargetFromFile -File results.json

.PARAMETER File

Specifies the target file to be read

.NOTES

Target files are created when the invoke-instruction cmdlet is run with the -TargetFile option specified. Target files track the success or failure of an instruction for each endpoint to which it is delivered

#>
[CmdletBinding()]
param(
     [Parameter(Mandatory=$true)] [string]$File
     )
     [array]$targetDevices = get-content $file | convertfrom-json | ForEach-Object {$($_.fqdn)}
     return $targetDevices
}

function Approve-Instruction
{
<#
.SYNOPSIS

Approves the instruction or schedule creation specified via the platform workflow

.EXAMPLE

Approve-1EInstruction -Id 32 -Token XYZZY -Comment "I have approved this instruction"


.PARAMETER Id

Specifies the instruction Id in the platform instruction history

.PARAMETER ScheduleId

Specifies the Id of a schedule instead of a normal instruction. Use the get-1Eschedule cmdlet to retrieve schedule ids

.PARAMETER Token

Optionally specifies the 2FA token that is returned to the instruction initiator when an action is first submitted to the platform

.PARAMETER Comment

Specifies an optional comment for the approval

.NOTES

This cmdlet is useful in test scenarios where the instruction initiator has configured the system for self-approval i.e they can approve their own instructions.
In that scenario, the initiator receives an email containing the 2FA token, which they then supply to this cmdlet to authenticate themselves and also approve their own instruction
If the approver is not the initiator, then they can invoke this cmdlet to approve the instruction. However they will not supply the token as the initiator will already have done this
using the set-instructionauthtoken cmdlet

If required, you must supply the 2FA token within 10 minutes of invoking the instruction, or creating the schedule, or it will be rejected

#>

[CmdletBinding(DefaultParameterSetName = 'id')]
param(
     [Parameter(Mandatory=$true, ParameterSetName = 'id')] [int]$Id,
     [Parameter(Mandatory=$true, ParameterSetName = 'scheduleid')] [int]$ScheduleId,
     [Parameter(Mandatory=$False)] [string]$Token,
     [Parameter(Mandatory=$false)] [string]$Comment
     )
if (IsNullOrEmpty $comment)
	{
	$comment = "This instruction was approved via the PowerShell integration toolset"
	}

if (-not (IsNullOrEmpty $token))
	{
    if ($id -ne 0)
        {
	    $res = Set-InstructionAuthToken -Id $Id -Token $Token
        }
    else
        {
        $res = Set-InstructionAuthToken -ScheduleId $ScheduleId -Token $Token
        }
	}

if ($id -ne 0)
    {
    $res = ApproveOrDenyInstruction $id $true $comment
    }
else
    {
    $res = ApproveOrDenyScheduledInstruction $scheduleid $true $comment
    }
return $res
}

function Set-InstructionAuthToken
{
<#
.SYNOPSIS

Associates the 2FA authentication token supplied with an instruction in the platform history or a schedule

.EXAMPLE

Set-1EInstructionAuthToken -Id 42 -Token XYZZY

.PARAMETER Id

Specifies the platform Id of the instruction in the platform instruction history

.PARAMETER ScheduleId

Specifies the platform Id of the schedule

.PARAMETER Token

Specifies the 2FA token that is returned to the instruction initiator when an action is first submitted to the platform

.NOTES




You must supply the 2FA token within 10 minutes of invoking the instruction or it will be rejected

#>

[CmdletBinding(DefaultParameterSetName = 'id')]
param(
     [Parameter(Mandatory=$true, ParameterSetName = 'id')] [int]$Id,
     [Parameter(Mandatory=$true, ParameterSetName = 'scheduleid')] [int]$ScheduleId,
     [Parameter(Mandatory=$true)] [string]$Token
     )
    if ($id -ne 0)
        {
	    $res = SendInstructionAuthToken $Id $Token
    	# this can succeed even when the instruction is then rejected, so go get the instruction status; we'll throw at this point if token not accepted
	    $res = Get-InstructionStatus -Id $Id
	    while ($res -eq "Authenticating")
    		{
    		write-information -MessageData ([string](get-date) + " Waiting for instruction to transition from Authenticating state,sleep 1")
    		$res = Get-InstructionStatus -Id $Id
    		Start-Sleep 1
    		}
        return $res
        }
# else scheduled instruction
    $res = SendScheduledInstructionAuthToken $ScheduleId $Token
    return $res
}

function Deny-Instruction
{
<#
.SYNOPSIS

Rejects the instruction or schedule creation specified via the platform workflow

.EXAMPLE

Deny-1EInstruction -Id 32 -Token XYZZY -Comment "I have not approved this instruction"


.PARAMETER Id

Specifies the instruction Id in the platform instruction history

.PARAMETER ScheduleId

Specifies the Id of a schedule

.PARAMETER Token

Optionally specifies the 2FA token that is returned to the instruction initiator when an action is first submitted to the platform

.PARAMETER Comment

Specifies an optional comment for the rejection

.NOTES

This cmdlet is useful in test scenarios where the instruction initiator has configured the system for self-approval i.e they can approve/reject their own instructions.
In that scenario, the initiator receives an email containing the 2FA token, which they then supply to this cmdlet to authenticate themselves and also reject their own instruction
If the approver is not the initiator, then they can invoke this cmdlet to reject the instruction. However they will not supply the token as the initiator will already have done this
using the set-instructionauthtoken cmdlet

You must supply the 2FA token within 10 minutes of invoking the instruction or creating the schedule, or it will be rejected automatically with an authentication failure

#>

[CmdletBinding(DefaultParameterSetName = 'id')]
param(
     [Parameter(Mandatory=$true, ParameterSetName = 'id')] [int]$Id,
     [Parameter(Mandatory=$true, ParameterSetName = 'scheduleid')] [int]$ScheduleId,
     [Parameter(Mandatory=$false)] [string]$Token,
     [Parameter(Mandatory=$false)] [string]$Comment
     )

if (-not (IsNullOrEmpty $token))
	{
    if ($id -ne 0)
        {
	    $res = Set-InstructionAuthToken -Id $Id -Token $Token
        }
    else
        {
        $res = Set-InstructionAuthToken -ScheduleId $ScheduleId -Token $Token
        }
	}

if (IsNullOrEmpty $comment)
	{
	$comment = "This instruction was rejected via the PowerShell integration toolset"
	}
if ($id -ne 0)
    {
    $res = ApproveOrDenyInstruction $id $false $comment
    }
else
    {
    $res = ApproveOrDenyScheduledInstruction $scheduleid $false $comment
    }
return $res
}

function Invoke-SyncInstruction
{
<#
.SYNOPSIS

Invokes the platform instruction specified synchronously

.EXAMPLE

Invoke-1ESyncInstruction 1E-Explorer-TachyonAgent-Echo -TargetFqdns "urth-myserver.urth.local"

.PARAMETER Instruction

Specifies the name of the instruction to be invoked

.PARAMETER TargetScope

Specifies the scope of the target. The scope defines attributes such as fqdns, operating system version etc associated with the endpoints to which the instruction should be sent when executed

.PARAMETER TargetFqdns

Specifies one or more endpoint fqdns which will be the targets of the instruction selected. This parameter is mutually exclusive with TargetScope

.PARAMETER PromptDefaults

Specifies that instruction parameters with default values will be prompted for

.PARAMETER Refresh

Specifies that instruction results are re-evaluated and not returned from cache

.NOTES

Invoking a platform instruction synchronously causes the instruction to be sent individually to each device which is defined by the scope or target fqdn list. Results are returned directly and are not stored
on the platform responses database.
An error will be thrown if more than 10 devices are targeted by scope or target fqdn
Each device that receives the instruction will result in an individual entry in the platform instruction history
Instruction results are automatically cached on endpoints. If the same instruction is invoked by the same platform user, then any endpoints where the cached data is still valid will return the cached
data rather than re-executing the instruction, unless the optional -Refresh parameter is specified. Cache values remain valid for 180 seconds by default.

#>
[CmdletBinding(SupportsShouldProcess=$true, DefaultParameterSetName='targetscope')]
Param(
    [Parameter(Mandatory=$true, Position=1)]
    [string]$instruction,

    [Parameter(Mandatory=$true, ParameterSetName = 'targetscope')]
    [string]$TargetScope,

    [Parameter(Mandatory=$true, ParameterSetName = 'targetfqdns')]
    [string[]]$TargetFqdns,

    [Parameter(Mandatory=$false)] [switch]$PromptDefaults = $false,
    [Parameter(Mandatory=$false)] [switch]$Refresh = $false
)
DynamicParam {
    $OFFSET = 5 #Change if fixed param count above changes (note: include -Whatif and remember TargetFqdns|TargetScope are one param, mutually exclusive. Unfortunately $PSBoundParams doesn't reflect params that will subsequently be prompted for if not supplied and so we don't know how many there are programmatically
    $ret = BuildDynamicParams $instruction $OFFSET
    $instrId = $ret.InstrId # we need this below
    return $ret.dict
    }

Process
    {

    $defaultProps = @{} 
    if ($PromptDefaults)
	{
	foreach ($p in $ret.Metadata)
		{
         # prompt if there's a default, and if the parameter was passed in specifically, it is set to the default value (i.e from an auto-generated cmdlet that uses invoke-instruction)
		if (-not (IsNullOrEmpty $p.DefaultValue) -and ($PSBoundParameters -eq $null -or ($PSBoundParameters -ne $null -and $PSBoundParameters[$p.Name] -eq $p.DefaultValue )))
			{
			write-host $p.Name ":[" $p.DefaultValue "] " -NoNewLine
			$line = read-host
			if ($line -ne "")
				{
				$defaultProps[$p.Name]=$line
				}
			}
		}
	}
    $params = BuildParams $ret.Metadata $PSBoundParameters $defaultProps
    $payload = @"
    {
    "DefinitionId": $instrId
    $(FormatAttribute "Parameters" $params)
    }
"@

    if (-not (IsNullOrEmpty $targetscope))
        {
        $targetfqdns = get-respondingdevice -targetscope $targetscope -active -asarray
        }

    if ($targetfqdns.Count -gt $MAXSYNCTARGETDEVICES)
        {
        throw "Target device count exceeds maximum"
        }

    if ($pscmdlet.ShouldProcess($instruction))
        {
        $results = @{}
        foreach ($fqdn in $targetfqdns)
            {
            $dev = get-device -Fqdn $fqdn
            $guid = $dev.TachyonGuid
            if ($Refresh)
                {
                $url = "/consumer/devices/tachyonguid/" + $guid +"/instruction" + "/true"
                }
            else
                {
                $url = "/consumer/devices/tachyonguid/" + $guid +"/instruction" 
                }
# synchronous instructions return errors by returning an error HTTP code, so we must trap this, unlike regular instructions, which return errors as part of the response
            try
                {
                $res = PostHttpRequest $url $payload
                $results[$fqdn] = [object []]$res.Values
                }
            catch
                {
# we already know that the instruction was valid, so we can assume that an error here is directly caused by the instruction returning an error via the platform and not an infrastructure failure
                $e = $_.Exception.Message
                $m = convertfrom-json $e
                $errorData = $m.Data
                $results[$fqdn] = New-Object PSObject -Property @{
                    Status = 2
                    ErrorData = $errorData
                    }
                }
            }
        return $results
        }
    else #whatif, return fqdns that would be targeted
        {
        $ret = New-Object System.Collections.Generic.List[System.Object]           
        foreach ($fqdn in $TargetFqdns)
            {
            $v = New-Object PSObject -Property @{Fqdn = $fqdn}
            [void]$ret.Add($v)
            }
            return $ret.ToArray()
        }
  
    }
}

function Get-Scope
{
<#
.SYNOPSIS

Returns a JSON translation of the scope expression specified.

.EXAMPLE

Get-1EScope -TargetScope "fqdn like %xyz%"


.PARAMETER TargetScope

Specifies the target scope to be translated.

.NOTES

This cmdlet will return the internal representation of a scope expression as directly used by the platform APIs. It is useful for test purposes

#>

[CmdletBinding()]
param(
     [Parameter(Mandatory=$true)] [string]$TargetScope
     )

return (exprToJson $TargetScope)
}

function Get-Filter
{
<#
.SYNOPSIS

Returns a JSON translation of the result filter expression specified.

.EXAMPLE

Get-1EScope -ResultFilter "Memory_In_MB=3968"


.PARAMETER ResultFilter

Specifies the result filter expression to be translated.

.NOTES

This cmdlet will return the internal representation of a result filter expression as directly used by the the platform APIs. It is useful for test purposes

#>

[CmdletBinding()]
param(
     [Parameter(Mandatory=$true)] [string]$Resultfilter
     )

return (exprToJson $Resultfilter)
}


function Get-VersionAsString
{
<#
.SYNOPSIS

Returns the platform internal encoded version information as a human-readable version string

.EXAMPLE

Get-1EVersionAsString -Version 123412341234


.PARAMETER Version

Specifies the platform internal encoded version information returned for some device properties


.NOTES

The platform encodes some internal version numbers which are of the human-readable form 1.2.3.4 as a single integer. This cmdlet will decode the numeric representation of the version to human-readable form

#>

[CmdletBinding()]
param(
     [Parameter(Mandatory=$true)] [bigint]$version
     )
$ver1 = [string]($version % 65536)
$ver2 = [string](($version -shr 16) % 65536)
$ver3 = [string](($version -shr 32) % 65536)
$ver4 = [string](($version -shr 48) % 65536)
return $ver4 + "." + $ver3 + "." + $ver2 + "." + $ver1
}


function Get-InstructionXml
{
<#
.SYNOPSIS

Returns the content of an instruction XML file as an XML document in memory

.EXAMPLE

Get-1EInstructionXml -File MyInstruction.xml

.PARAMETER File

Specifies the instruction Xml file to be read

#>

[CmdletBinding()]
param(
     [Parameter(Mandatory=$true)] [string]$file
     )
[xml]$doc = get-content $file
return $doc.ChildNodes[1]
}

function Invoke-OSQuery
{
<#
.SYNOPSIS

Runs the specified OSQuery query

.EXAMPLE

Invoke-1EOSQuery -Query "select * from startup_items" -Targetscope xyz


.PARAMETER Query

Specifies the OSQuery query to be run

.PARAMETER TargetScope

Specifies a scope expression targetting the endpoints on which the query is to be run

.PARAMETER TargetFqdns

Specifies one or more target FQDNs against which the query is to be run. This parameter is mutually exclusive with TargetScope

.NOTES

This cmdlet requires that you have uploaded the support instruction "1E-Exchange-OSQuery" to the platform server


#>

[CmdletBinding(DefaultParameterSetName='targetscope')]

#note - TargetScope and TargetFqdns params mutually exclusive as are TargetPercent and TargetCount

Param(

    [Parameter(Mandatory=$true)]
    [string]$Query,

    [Parameter(Mandatory=$true, ParameterSetName = 'targetscope')]
    [string]$TargetScope,

    [Parameter(Mandatory=$true, ParameterSetName = 'targetfqdns')]
    [string[]]$TargetFqdns

    )

    return RunQuery "1E-Exchange-OSQuery" $query $targetscope $targetfqdns

}


function Invoke-WMIQuery
{
<#
.SYNOPSIS

Runs the specified WMI query

.EXAMPLE

Invoke-1EWMIQuery -Query "select AdapterType from Win32_NetworkAdapter" -Namespace "root\cimv2" -Targetscope xyz


.PARAMETER Query

Specifies the WMI query to be run

.PARAMETER Namespace

Specifies the WMI query namespace to be used

.PARAMETER TargetScope

Specifies a scope expression targetting the endpoints on which the query is to be run

.PARAMETER TargetFqdns

Specifies one or more target FQDNs against which the query is to be run. This parameter is mutually exclusive with TargetScope

.NOTES

This cmdlet requires that you have uploaded the support instruction "1E-Exchange-ExecuteWMIQuery" to the platform server


#>

[CmdletBinding(DefaultParameterSetName='targetscope')]

#note - TargetScope and TargetFqdns params mutually exclusive as are TargetPercent and TargetCount

Param(

    [Parameter(Mandatory=$true)]
    [string]$Query,

    [Parameter(Mandatory=$true)]
    [string]$Namespace,

    [Parameter(Mandatory=$true, ParameterSetName = 'targetscope')]
    [string]$TargetScope,

    [Parameter(Mandatory=$true, ParameterSetName = 'targetfqdns')]
    [string[]]$TargetFqdns

    )

# This instruction returns a CLOB field. To protect against a deref issue with platform versions < 5.1, check release first
    if (($script:TACHYONMAJORVER -lt 5)	-or (($script:TACHYONMAJORVER -eq 5) -and ($script:TACHYONMINORVER -lt 1)))
	{
	if ($script:TACHYONVER -eq "")
		{
		throw "The platform server has not been defined. Use set-1eserver to specify the platform server you wish to connect to"
		}
	throw "This cmdlet requires platform version 5.1 or greater. The current version of the platform you are connected to is $($script:TACHYONVER)"
	}
    return RunQuery "1E-Exchange-ExecuteWMIQuery" $query $targetscope $targetfqdns $namespace

}


function Invoke-ActivityQuery
{
<#
.SYNOPSIS

Queries the specified platform Activity Record table on the targetted endpoints

.EXAMPLE

Invoke-1EActivityQuery -Query "select * from $arp_live" -TargetScope xyz


.PARAMETER Query

Specifies the query to be run on the endpoints


.PARAMETER TargetScope

Specifies a scope expression targetting the endpoints on which the query is to be run

.PARAMETER TargetFqdns

Specifies one or more target FQDNs against which the query is to be run. This parameter is mutually exclusive with TargetScope

.NOTES

This cmdlet requires that you have uploaded the support instruction "1E-Exchange-ActivityRecordQry" to the platform server


#>

[CmdletBinding(DefaultParameterSetName='targetscope')]

#note - TargetScope and TargetFqdns params mutually exclusive as are TargetPercent and TargetCount

Param(

    [Parameter(Mandatory=$true)]
    [string]$Query,

    [Parameter(Mandatory=$true, ParameterSetName = 'targetscope')]
    [string]$TargetScope,

    [Parameter(Mandatory=$true, ParameterSetName = 'targetfqdns')]
    [string[]]$TargetFqdns

    )

    return RunQuery "1E-Exchange-ActivityRecordQry" $query $targetscope $targetfqdns

}


function Export-Fragment
{
<#
.SYNOPSIS

Exports a fragment from the platform server to an XML file

.EXAMPLE

Export-1EFragment -Name 1E-Explorer-MyFragment -File out.xml


.PARAMETER Name

Specifies the name the fragment to export

.PARAMETER Id

Specifies the platform Ids of the fragment to export.

.PARAMETER File

Specifies the name of the output file to create.


#>

[CmdletBinding(DefaultParameterSetName='Name')]
param(
    [Parameter(Mandatory=$true,ParameterSetName='Name')] [string]$Name,
    [Parameter(Mandatory=$true,ParameterSetName='Id')] [string]$Id,
    [Parameter(Mandatory=$true)] [string]$File
     )

if (IsNullOrEmpty $Name)
	{
	$fullurl = "/consumer/Fragments/Export/Id/" + $Id
	}
else
	{
	$fullurl = "/consumer/Fragments/Export/Name/" + $Name
	}

$res = GetHttpRequestRaw $fullUrl 
$filepath = GetFullPath $File
# we have to convert from an incorrectly encoded response to UTF8 - this causes non-ASCII characters to be mis-encoded otherwise (e.g, there's a fragment with some pasted-in French text that provokes this issue)
$content = [System.Text.Encoding]::UTF8.GetString([System.Text.Encoding]::GetEncoding(28591).GetBytes($res.content))
#has user indicated an extension? If not, append .xml
if ($filePath.indexOf(".") -lt 0)
    {
    $filePath += ".xml"
    }
# we have to add a UTF8 BOM to the output to exactly mimic what the fragment signature expects for the file hash
$Utf8BomEncoding = New-Object System.Text.UTF8Encoding $true
[io.file]::WriteAllText($Filepath, $content, $utf8BomEncoding) 

}

function Export-Instruction
{
<#
.SYNOPSIS

Exports one or more instructions from the platform server to a ZIP file

.EXAMPLE

Export-1EInstruction -Names @("1E-Explorer-Instruction1","Acme-Instruction2") -File out.zip


.PARAMETER Names

Specifies the names of one or more instructions to export. If specifying multiple instructions, use an array as in the example

.PARAMETER Ids

Specifies the platform Ids of one or more instructions to export. If specifying multiple instructions, use an array as in the example

.PARAMETER File

The name of the ZIP file to create. Each instruction will be packaged as a separate XML file inside the ZIP archive file


#>

[CmdletBinding(DefaultParameterSetName='Names')]
param(
    [Parameter(Mandatory=$true,ParameterSetName='Names')] [string[]]$Names,
    [Parameter(Mandatory=$true,ParameterSetName='Ids')] [string[]]$Ids,
    [Parameter(Mandatory=$true)] [string]$File
     )
$payloadNames = @"
{
     "Names": [
"@

$payloadIds = @"
{
     "Ids": [
"@


$notfirst = $false
if ($null -ne $Names)
    {
    $payload = $payloadNames
    foreach ($name in $names)
        {
        if ($notfirst)
            {
            $payload += "," + (quotify $Name)
            }
        else
            {
            $notfirst = $true
            $payload +=  quotify $Name
            }
        }
    }
else
    {
    $payload = $payloadIds
    foreach ($id in $ids)
        {
        if ($notfirst)
            {
            $payload += "," + $id
            }
        else
            {
            $notfirst = $true
            $payload += $id
            }
        }
    }

$payload += "]}"
$fullurl = "/consumer/InstructionDefinitions/Export"

$res = PostHttpRequestRaw $fullUrl $payload
$filepath = GetFullPath $File

#has user indicated an extension? If not, append .zip
if ($filePath.indexOf(".") -lt 0)
    {
    $filePath += ".zip"
    }

[io.file]::WriteAllBytes($Filepath, $res.Content) 
}

function Get-Consumer
{
<#
.SYNOPSIS

Returns all platform Consumers that have been defined, or information about a specific consumer

.EXAMPLE

Get-1EConsumer


.PARAMETER Id

Specifies the platform Id of the consumer to return information on

.PARAMETER Name

Specifies the name of the consumer to return information on

#>

[CmdletBinding(DefaultParameterSetName='Id')]
param(
[Parameter(Mandatory=$false, ParameterSetName='Id')] [int]$Id = 0,
[Parameter(Mandatory=$false, ParameterSetName ='Name')] [string]$Name = ""
)
return GetConsumers $Name $id
}

function Get-LastInstructionId
{
<#
.SYNOPSIS

Returns the platform Id for the most recently invoked instruction from the PowerShell toolkit (if any)

.EXAMPLE

Get-1ELastInstructionId


#>

[CmdletBinding()]
param()
return $script:gLastInstructionId
}


function Get-LastInstructionState
{

<#
.SYNOPSIS

Returns statistics information for the most recently invoked instruction from the PowerShell toolkit (if any)

.EXAMPLE

Get-1ELastInstructionState

#>

[CmdletBinding()]
param(
[Parameter(Mandatory=$false)] [switch]$Full = $false
)

$lastId = get-lastinstructionId
if ($lastId -ne 0)
    {
    $res = get-instructionstatistics -id $lastId
    }
else
    {
    throw "No instruction has been executed yet in this session"
    }
if (-not $full)
    {
    if (($res.EstimatedCount - $res.SentCount -eq 0) -and ($res.TotalErrorRespondents + $res.NotImplementedRespondents + $res.TotalResponseTooLargeRespondents -eq 0))
        {
        $successful = $true
        }
    else
        {
        $successful = $false
        }
    $res = New-Object PSObject -Property @{
        Id = $res.Id
        EstimatedCount = $res.EstimatedCount
        SentCount = $res.SentCount
        ReceivedCount = $res.ReceivedCount
        SuccessCount = $res.TotalSuccessRespondents + $res.TotalSuccessNoDataRespondents
        ErrorCount = $res.TotalErrorRespondents + $res.NotImplementedRespondents + $res.TotalResponseTooLargeRespondents
        Successful = $successful
        }
    }
    return $res
}

# adaptor function which allows you to build a target fqdn array from either a string array (unmodified) or a property array with an fqdn property

function Get-TargetFqdn
{

<#
.SYNOPSIS

Returns an fqdn array suitable for use with the -TargetFqdns property used by other cmdlets. The input can be either a string array or a property array with an fqdn member

.EXAMPLE

$fqdns = Get-1ETargetFqdn


.PARAMETER -TargetFqdns

Specifies the string array or property array to be used as the source

#>

[CmdletBinding()]
param(
[Parameter(Mandatory=$true)] [object[]] $targetFqdns
)
if ($null -eq $targetFqdns -or $targetFqdns.Count -eq 0)
    {
    throw "No fqdns available"
    }

if ($targetFqdns[0].getType().Name -eq "string")
    {
    return $targetFqdns
    }

if ("fqdn" -in $targetFqdns[0].PSObject.Properties.Name)
    {
    return $targetFqdns | select-object -ExpandProperty fqdn
    }
}

function Get-ResultAsCsvFile
{
<#
.SYNOPSIS

Creates a CSV file from either the results of an instruction that have been stored in a variable, or from an instruction result in history, or from a raw result file

.EXAMPLE

Get-1EResultAsCsvFile -Id 13


.PARAMETER InputObject

Specifies the input variable containing the instruction results to be used as the source of data

.PARAMETER Id

Specifies the platform instruction Id in history whose results are to be used as the source of data

.PARAMETER Raw

Specifies a data file containing the raw results from an instruction, which is to be used as the source of data

.PARAMETER Path

Specifies the filename and path to be used as the CSV output file

.PARAMETER ResultFilter

Specifies a result filter which will be used to filter the results before creating the output file

.PARAMETER ResultColumns

Specifies one or more column names, comma-delimited, which are to be included in the results. If not specified, all columns are included

.PARAMETER ReceivedOnly

Specifies that only the currently received results will be returned. If an instruction is in progress, the current received count will be taken to be the result count to be returned
When an instruction transitions to 'Complete', this parameter will have no effect. All available rows will be taken as the final result set, since no further devices can now contribute data

#>

[CmdletBinding(DefaultParameterSetName='Object')]
param(
[Parameter(Mandatory=$true, ParameterSetName='Object')] [object]$InputObject,
[Parameter(Mandatory=$true, ParameterSetName='Id')] [int]$Id,
[Parameter(Mandatory=$true, ParameterSetName='Raw')] [string]$Raw,
[Parameter(Mandatory=$true)] [string]$Path,
[Parameter(Mandatory=$false)] [switch]$ReceivedOnly,
[Parameter(Mandatory=$false)] [switch]$Drilldown=$false,
[Parameter(Mandatory=$false)] [string]$ResultFilter,
[Parameter(Mandatory=$false)] [string]$ResultColumns
)
$arguments = @{}
if (-not (IsNullOrEmpty $ResultFilter))
    {
    if ($null -ne $inputobject -or (-not (IsNullOrEmpty $raw)))
        {
        throw "Result filter not supported for raw results or results from an existing object"
        }
    $arguments.Add("ResultFilter",$resultFilter)
    }

if ($ReceivedOnly)
	{
	$arguments.Add("ReceivedOnly",$true)
	}

if (-not (IsNullOrEmpty $raw))
    {
    if ($drilldown)
        {
        throw "Drilldown is not supported for raw mode"
        }
    $v = convertfrom-raw $raw
    }

if ($null -ne $InputObject)
    {
    if ($drilldown)
        {
        throw "Drilldown is not supported for results using an existing object"
        }
    $v = $inputobject
    }

if ($Id -ne 0)
    {
    if ($drilldown)
        {
        $v = get-instructionresult -Id $Id -drilldown @arguments
        }
    else
        {
        $v = get-instructionresult -Id $Id @arguments
        }
    }

if ($null -eq $v -or $v.Count -eq 0)
    {
    throw "No information was returned for export to csv"
    }
MergeFqdn $v
if (-not (IsNullOrEmpty $resultcolumns))
    {
        $v.Values.ToArray() | select-object -Property ($resultcolumns.Split(",")) | export-csv -path $Path -NoTypeInformation
    }
else
    {
        $v.Values.ToArray() | export-csv -path $Path -NoTypeInformation
    }
return ""

}


function Get-Credential
{

<#
.SYNOPSIS

Retrieves the names of any credentials stored on endpoints. These are visible using the Windows Credential Manager as Web Credentials in the context of the platform agent account (normally LocalSystem)

.EXAMPLE

Get-1ECredential 


.NOTES

You must have uploaded the support instructions 1E-Exchange-ListCredentials to use this cmdlet.

#>

[CmdletBinding(DefaultParameterSetName='TargetScope')]
param(
[Parameter(Mandatory=$true, ParameterSetName='TargetScope')] [string]$TargetScope,
[Parameter(Mandatory=$true, ParameterSetName='TargetFqdns')] [string[]]$TargetFqdns
)

if (-not (IsNullOrEmpty $TargetScope))
	{
	$ret = invoke-instruction 1E-Exchange-ListCredentials -targetscope $targetscope
	}
else
	{
	$ret = invoke-instruction 1E-Exchange-ListCredentials -targetfqdns $targetfqdns
	}
return $ret
}


function Remove-Credential
{

<#
.SYNOPSIS

Removes the specified credential from the endpoints targeted

.EXAMPLE

Remove-1ECredential -Name MyCredential


.NOTES

You must have uploaded the support instructions 1E-Exchange-DeleteCredential to use this cmdlet.

#>

[CmdletBinding(DefaultParameterSetName='TargetScope')]
param(
[Parameter(Mandatory=$true, ParameterSetName='TargetScope')] [string]$TargetScope,
[Parameter(Mandatory=$true, ParameterSetName='TargetFqdns')] [string[]]$TargetFqdns,
[Parameter(Mandatory=$true)] [string]$Name
)

if (-not (IsNullOrEmpty $TargetScope))
	{
	$ret = invoke-instruction 1E-Exchange-DeleteCredential -Name $name -targetscope $targetscope
	}
else
	{
	$ret = invoke-instruction 1E-Exchange-DeleteCredential -Name $name -targetfqdns $targetfqdns
	}
return $ret
}


# TODO: this is not available yet for non-Windows environments

function Set-Credential
{

<#
.SYNOPSIS

Securely stores the supplied credentials as a Web Credential in the credential store of the target endpoints

.EXAMPLE

Set-1ECredential -Name MyCred


.PARAMETER Credential

Specifies a valid set of credentials. If not supplied, you are prompted securely for them. Otherwise you can assign them to a variable using the get-credential cmdlet and supply that variable as the parameter to avoid a prompt

.PARAMETER Name

Specifies the name (URL) associated with the Web Credential on the target endpoints

.PARAMETER TargetScope

Specifies the scope of the target. The scope defines attributes such as fqdns, operating system version etc associated with the endpoints to which the credentials should be sent

.PARAMETER TargetFqdns

Specifies one or more endpoint fqdns which will receive the credentials. This parameter is mutually exclusive with TargetScope


.NOTES

You must have uploaded the support instructions 1E-Exchange-CreateCredential and 1E-Exchange-CreateEncryptionCert to use this cmdlet. 

#>

[CmdletBinding(DefaultParameterSetName='TargetScope')]
param(
[Parameter(Mandatory=$true)] [PSCredential]$credential,
[Parameter(Mandatory=$true)] [string]$Name,
[Parameter(Mandatory=$true, ParameterSetName='TargetScope')] [string]$TargetScope,
[Parameter(Mandatory=$true, ParameterSetName='TargetFqdns')] [string[]]$TargetFqdns

)
#create suitable certs on the targets and return their public keys

if (-not (IsNullOrEmpty $TargetScope))
	{
	$devs = Get-RespondingDevice -targetscope $targetscope
	if ($devs.Count -gt $MAXTARGETDEVICES)
		{
		throw "Instruction scope exceeds maximum target devices"
		}
	$pubkeys = invoke-instruction 1e-exchange-createencryptioncert -targetscope $targetscope
	}
else
	{
	if ($targetFqdns.Count -gt $MAXTARGETDEVICES)
		{
		throw "Instruction scope exceeds maximum target devices"
		}

	$pubkeys = invoke-instruction 1e-exchange-createencryptioncert -targetfqdns $targetfqdns
	}
# get the credentials and build a string from them
$nwcreds = $credential.GetNetworkCredential()
$msg = $nwcreds.Domain + "\" + $nwcreds.UserName + "~" + $nwcreds.Password

#for each returned result (certificate with just the public key), create a temp certificate, import into the cert store, encrypt the credentials with the public key and then send a sync instruction
#down to each endpoint with the endpoint-specific encrypted credentials so they can be decrypted and added as a web credentials

$res = @{}
foreach ($key in $pubkeys.keys)
	{
    if (IsNullOrEmpty $pubkeys[$key].Value)
        {
        continue
        }
	set-content -path _temp.cer -value $pubkeys[$key].Value
	$ic = import-certificate -filepath _temp.cer -certstorelocation cert:\currentuser\my
	$encmsg = $msg | protect-cmsmessage -to $ic.thumbprint
	$encmsg = [string]::join("",($encmsg.split("`r`n"))) #flatten out to a single string, removing all line breaks, so that we can pass it back as a param to the second platform instruction
	#for platform versions 5.2 onwards use sync instructions, otherwise roll back to normal instructions
	try
		{
		$x = invoke-syncinstruction 1e-exchange-createcredential -credential $encmsg -name $Name -targetfqdn $key
		}
	catch
		{
		$x = invoke-instruction 1e-exchange-createcredential -credential $encmsg -name $Name -targetfqdn $key
		}
	$res[$key]=[object []]$x.Values
	get-childitem -path cert:\currentuser\my -documentencryptioncert | where-object {$_.Thumbprint -eq $ic.Thumbprint} | remove-item
	}
return $res
}


function Get-InstructionTargetFqdn
{

<#
.SYNOPSIS

Returns the target list of fqdns associated with an instruction

.EXAMPLE

Get-1EInstructionTargetFqdn -Id 13


.PARAMETER Id

Specifies the platform Id of an instruction history entry

.NOTES

The instruction must have been invoked with a targeted set of FQDNs as opposed to a scope expression for this cmdlet to succeed

#>
[CmdletBinding()]
param(
[Parameter(Mandatory=$true)] [int]$Id
)
$url = "/consumer/instructions/" + $id + "/targetlist"
$res = GetHttpRequest $url
return $res
}

function Get-EventSource
{
<#
.SYNOPSIS

Returns all event sources

.EXAMPLE

Get-1EEventSource

.NOTES

This cmdlet requires platform version 5.1 or later

#>
[CmdletBinding()]
param()

$url = "/consumer/eventsource"
$res = GetHttpRequest $url
return $res
}

function Get-ConnectorType
{
<#
.SYNOPSIS

Returns all connector types

.EXAMPLE

Get-1EConnectorType


#>
[CmdletBinding()]
param()

$url = "/admin/ConnectorTypes"
$res = GetHttpRequest $url
return $res
}

function Get-SLARepository
{
<#
.SYNOPSIS

Returns information on SLA repositories

.EXAMPLE

Get-1ESLARepository

#>
[CmdletBinding()]
param()
$url = "/admin/Repositories/search"
$payload = @"
{
"Start" : 1,
"PageSize" : 2000
}
"@
$res = PostHttpRequestPaged $url $payload
return $res.Items
}

function Get-SLAManagementGroupRuleAttribute
{
<#
.SYNOPSIS

Returns all SLA management group rule attributes

.EXAMPLE

Get-1ESLAManagementGroupRuleAttribute


#>
[CmdletBinding()]
param()

$url = "/admin/ManagementGroupRuleAttributes/GetRuleMetadata"
$res = GetHttpRequest $url
return $res
}

function Update-Connector
{
<#
.SYNOPSIS

Updates the connector specified by the Id

.PARAMETER Id

Specifies the Id of the connector to be updated

.EXAMPLE

Update-Connector -Id 7

.NOTES

This cmdlet is intended currently to allow a connector of type 'Tachyon' to be refreshed when migrating to a SaaS environment and ensures that appropriate credentials
are removed to ensure that behaviour operates correctly in the SaaS environment.
When run against any other type of connector, no changes are made.

#>
[CmdletBinding()]
param(
[Parameter(Mandatory=$true)] [int]$Id
)
if (($script:TACHYONMAJORVER -lt 8) -or (($script:TACHYONMAJORVER -eq 8) -and ($script:TACHYONMINORVER -lt 2)))
{
throw "This cmdlet is only available on platform releases 8.2 onwards"
}

$conn = get-connector -id $Id
if ($conn.ConnectorType -ne "Tachyon")
	{
	throw "This connector is not of type 'Tachyon'"
	}
foreach ($prop in $conn.Properties)
	{
	if ($prop.Name -eq "Password")
		{
		$prop.Value = "NotApplicable"
		}
	}
$payload = convertto-json $conn
$url = "/admin/Connectors"
$res = PutHttpRequest $url $payload
return $res
}



function Get-Connector
{
<#
.SYNOPSIS

Returns all connectors or information about the connector whose Id is specified

.PARAMETER Id

If specified, indicates the Id of the connector to retrieve information from

.EXAMPLE

Get-1EConnector


#>
[CmdletBinding()]
param(
[Parameter(Mandatory=$false)] [int]$Id
)

if ($Id -eq 0)
	{
	$url = "/admin/Connectors/Search"
	$payload = @"
	    {
	    "Start": 1,
	    "PageSize": 2000,
	    "Filter" : {
	    "Operator": "and",
	    "Operands": [{
	       "Attribute": "Name",
	       "Operator" : "like",
	       "Value" : "%"
	       }]
	    }
	}
"@
	$res = PostHttpRequestPaged $url $payload
	return $res.Items
	}
else
	{
	$url = "/admin/Connectors/" + $Id
	$res = GetHttpRequest $url
	return $res
	}
}




# we 'denormalise' the results for this to include the consumer name and target url for user convenience

function Get-EventSubscription
{
<#
.SYNOPSIS

Returns all event subscriptions or the information associated with a particular event subscription

.EXAMPLE

Get-1EEventSubscription

.PARAMETER Id

Specifies the platform Id of an event subscription

.NOTES

This cmdlet requires platform version 5.1 or later


#>

[CmdletBinding()]
param(
[Parameter(Mandatory=$false)] [int]$Id = 0
)
if ($id -eq 0)
	{
	$url = "/consumer/eventsubscriptions"
	}
else
	{
	$url = "/consumer/eventsubscriptions/" + $id
	}
$consumers = Get-Consumer
$consumerdict = @{}
foreach ($consumer in $consumers)
	{
	$consumerdict[$consumer.Id] = $consumer
	}
$res = GetHttpRequest $url
foreach ($r in $res)
	{
        add-member -MemberType NoteProperty -Name "ConsumerName" -Value $consumerDict[$r.ConsumerId].Name -inputobject $r
        add-member -MemberType NoteProperty -Name "OffloadTargetUrl" -Value $consumerDict[$r.ConsumerId].OffloadTargetUrl -inputobject $r
	}
return $res
}

# we 'denormalise' the results for this to include the subscription topic and URL because otherwise the results are a bit cryptic

function Get-EventSubscriptionAssignment
{
<#
.SYNOPSIS

Returns all event subscription assignments or only assignments associated with a specific event topic

.EXAMPLE

Get-1EEventSubscriptionAssignment


.PARAMETER Topic

Specifies an event topic for which event subscription assignments are to be returned

.NOTES

This cmdlet requires platform version 5.1 or later

#>
[CmdletBinding()]
param(
[Parameter(Mandatory=$false)] [string]$Topic
)
$subscriptions = Get-EventSubscription
$subdict = @{}
foreach ($subscription in $subscriptions)
	{
	$subdict[$subscription.Id] = $subscription
	}
$url = "/consumer/eventsubscriptionassignments"
$res = GetHttpRequest $url
foreach ($r in $res)
	{
        add-member -MemberType NoteProperty -Name "Topic" -Value $subDict[$r.SubscriptionId].Topic -inputobject $r
        add-member -MemberType NoteProperty -Name "Url" -Value $subDict[$r.SubscriptionId].Url -inputobject $r
	}
if (-not (IsNullOrEmpty $topic))
    {
    return $res | where-object {$_.Topic -eq $topic}
    }
return $res
}

function Add-EventSubscription
{
<#
.SYNOPSIS

Adds an event subscription

.EXAMPLE

Add-1EEventSubscription -ConsumerName Inventory -Topic Alpha.Beta -Url https://myserver.mydomain.local


.PARAMETER ConsumerName

Specifies the consumer to be associated with the event subscription

.PARAMETER Topic

Specifies the topic for the event

.PARAMETER Url

Specifies the URL to which events will be forwarded

.NOTES

This cmdlet requires platform version 5.1 or later

#>

[CmdletBinding()]
param(
[Parameter(Mandatory=$true)] [string]$ConsumerName,
[Parameter(Mandatory=$true)] [string]$Topic,
[Parameter(Mandatory=$true)] [string]$Url
)
$consumerId = (Get-Consumer -Name $ConsumerName).Id
$payload = @"
	    {
        "ConsumerId":$($consumerId),
        "Topic":$(quotify $topic),
        "Url":$(quotify $Url),
	"Status": 1
        }
"@
$res = PostHttpRequest "/consumer/eventsubscriptions" $payload
return $res
}

function Add-EventSubscriptionAssignment
{
<#
.SYNOPSIS

Adds an event subscription assignment

.EXAMPLE

Add-1EEventSubscriptionAssignment


.PARAMETER SubscriptionId

Specifies the platform Id of an Event Subscription to which the assignment is to be made

.PARAMETER ManagementGroupId

Specifies the platform Id of a Management Group to be associated with the event subscription assignment

.PARAMETER Deploy

Causes all active Guaranteed State policies, if any, to be redeployed. Event subscription changes are not propagated to endpoints unless this is done.

.NOTES

See also the Send-1EPolicy cmdlet, which redeploys all active Guaranteed State policies.

#>

[CmdletBinding()]
param(
[Parameter(Mandatory=$true)] [int]$SubscriptionId,
[Parameter(Mandatory=$true)] [int]$ManagementGroupId,
[Parameter(Mandatory=$false)] [switch]$Deploy
)
$payload = @"
	    {
        "SubscriptionId":$($SubscriptionId),
        "ManagementGroupId":$($ManagementGroupId)
        }
"@
$res = PostHttpRequest "/consumer/eventsubscriptionassignments" $payload
if ($Deploy)
    {
    $r = Send-Policy
    }
return $res
}

function Remove-EventSubscriptionAssignment
{
<#
.SYNOPSIS

Removes (deletes) an event subscription assignment

.EXAMPLE

Remove-1EEventSubscriptionAssignment -Id 11


.PARAMETER Id

Specifies the platform Id of an existing event subscription assignment

.PARAMETER Deploy

Causes all active Guaranteed State policies, if any, to be redeployed. Event subscription changes are not propagated to endpoints unless this is done.

.NOTES

See also the Send-1EPolicy cmdlet, which redeploys all active Guaranteed State policies.

#>

[CmdletBinding()]
param(
[Parameter(Mandatory=$true)] [int]$Id,
[Parameter(Mandatory=$false)] [switch]$Deploy
)
$url = "/consumer/eventsubscriptionassignments/" + $Id 
$res = DeleteHttpRequest $url
if ($Deploy)
    {
    $r = Send-Policy
    }
return $res
}


function Remove-EventSubscription
{
<#
.SYNOPSIS

Removes an event subscription

.EXAMPLE

Remove-1EEventSubscription -Id 33


.PARAMETER Id

Specifies the platform Id of an event subscription to be removed

.NOTES

Any event subscription assignments associated with the event subscription are also removed when the event subscription is removed

#>

[CmdletBinding()]
param(
[Parameter(Mandatory=$true)] [int]$Id
)
$url = "/consumer/eventsubscriptions/" + $Id 
$res = DeleteHttpRequest $url
return $res
}

function Get-DeviceList
{
<#
.SYNOPSIS

Given a list of devices as an array, returns a fresh array with only the active (default) or inactive devices included

.EXAMPLE

Get-1EDeviceList -TargetFqdns @("device1.mydomain.local","device2.mydomain.local")

#>

[CmdletBinding()]
param(
[Parameter(Mandatory=$true)][string []]$TargetFqdns,
[Parameter(Mandatory=$false)][switch]$Inactive=$false
)
if (IsNullOrEmpty $TargetFqdns)
    {
    return [string[]]@()
    }
$devList = New-Object System.Collections.Generic.List[System.String]

foreach ($fqdn in $TargetFqdns)
    {
    $dev = GetDeviceInfo $fqdn
    if ($Inactive)
        {
        if ($dev.status -eq 0)
            {
            [void]$devList.Add($dev.fqdn)
            }
        }
    else
        {
        if ($dev.status -eq 1)
            {
            [void]$devList.Add($dev.fqdn)
            }
        }
    }
return $devList.ToArray()
}


function Get-SystemStatistics
{
<#
.SYNOPSIS

Returns summary system statistics

.EXAMPLE

Get-1ESystemStatistics

#>

[CmdletBinding()]
param(
)
$url = "/consumer/systemstatistics/highlevel"
$res = GetHttpRequest $url
return $res
}

function Set-InstructionPrefix
{
<#
.SYNOPSIS

Sets the instruction prefix to be used when creating dynamic instructions. The default is "1E-Exchange"

.EXAMPLE

Set-1EInstructionPrefix -Prefix "1E-Explorer"

.PARAMETER Prefix

Specifies the instruction prefix to be set

#>

[CmdletBinding()]
  param
  (
  [Parameter(Mandatory=$true)][string]$Prefix
  )
  $script:INSTPREFIX = $Prefix
}


function Get-InstructionPrefix
{
<#
.SYNOPSIS

Returns the instruction prefix which is used when creating dynamic instructions.

.EXAMPLE

Get-1EInstructionPrefix

#>

[CmdletBinding()]
  param
  (
  )
  return $script:INSTPREFIX
}

function Set-DynamicInstructionSet
{
<#
.SYNOPSIS

Sets the instruction set to be used when uploading dynamic instructions. The default is "DynamicScripting"

.EXAMPLE

Set-1EDynamicInstructionSet -Name MySet

.PARAMETER Name

Specifies the instruction set name to use when uploading dynamic instructions

#>

[CmdletBinding()]
  param
  (
  [Parameter(Mandatory=$true)][string]$Name
  )
  $script:INSTRUCTIONSET = $Name
}


function Get-DynamicInstructionSet
{
<#
.SYNOPSIS

Returns the instruction set to be used when uploading dynamic instructions.

.EXAMPLE

Get-1EDynamicInstructionSet

#>

[CmdletBinding()]
  param
  (
  )
  return $script:INSTRUCTIONSET
}

function New-InstructionXmlForMethod
{
<#
.SYNOPSIS

Creates a platform instruction XML file which will invoke the specified SCALE method

.EXAMPLE

New-1EInstructionXmlForMethod -MethodName Agent.Echo


.PARAMETER MethodName

Specifies the SCALE method that the instruction will invoke

.PARAMETER IncludeOptionalParams

If specified, any optional parameters for the SCALE Method are included as parameters to the instruction itself. This allows the user to specify values for these parameters. 

.PARAMETER OptionalParams

Allows the user to supply a list of parameters separated by commans, that, if they correspond to method parameters, will be included as parameters to the instruction itself.
This allows more fine-grained control over which method parameters are exposed by the instruction.

#>

[CmdletBinding()]
  param
  (
  [Parameter(Mandatory=$true)][string]$MethodName,
  [Parameter(Mandatory=$false)][switch]$IncludeOptionalParams,
  [Parameter(Mandatory=$false)][string]$OptionalParams
  )
  return CreateInstructionForMethod $MethodName $IncludeOptionalParams $OptionalParams
}

function Get-MethodParameter
{
<#
.SYNOPSIS

Returns the parameters associated with a SCALE method.

.EXAMPLE

Get-1EMethodParameter -MethodName Agent.Echo


.PARAMETER MethodName

Specifies the SCALE method whose parameters are to be returned

.PARAMETER NoTranslate

Bypasses parameter type remapping to instruction types. For example, if this parameter is not specified, a method parameter of type boolean is translated to be of type 'int', because instructions do not expose a boolean parameter type.


#>

[CmdletBinding()]
  param
  (
  [Parameter(Mandatory=$true)][string]$MethodName,
  [Parameter(Mandatory=$false)][switch]$NoTranslate
  )
  if ($NoTranslate)
    {
    return GetMethodParameters $MethodName
    }
 else
    {
    $params = GetMethodParameters $MethodName
    foreach ($p in $params)
        {
        # handle scenario where DefaultValue property is missing
        if (-not ("DefaultValue" -in $p.PSObject.Properties.Name))
            {
            add-member -MemberType NoteProperty -Name "DefaultValue" -Value $null -InputObject $p
            }
        $p.DefaultValue =  MapDefaultValue $p
        $p.Type = GetParamDataType $p.Type
        }
    }
    return $params
}


function Get-MethodInfo
{
<#
.SYNOPSIS

Gets information about the specified SCALE method, or summary information on all SCALE methods if no method name is specified

.EXAMPLE

Get-1EMethodInfo -MethodName Agent.Echo


.PARAMETER MethodName

Specifies the SCALE method for which information is required


#>

[CmdletBinding()]
  param
  (
  [Parameter(Mandatory=$false)][string]$MethodName
  )
  if (-not (IsNullOrEmpty $methodName))
	{
	  return GetMethodInfo $MethodName
	}
  $methods = GetMethodInfo 
  $methList = New-Object System.Collections.Generic.List[System.Object]
  foreach ($method in $methods.Values)
	{
	$result = New-Object PSObject -Property @{
                Name = $method.NormalisedName
		Description = $method.Description
		}
	[void]$methList.add($result)
	}
  return $methList | sort-object -property Name
}


function Get-MethodSchema
{
<#
.SYNOPSIS

Gets the schema of the returned data from the specified SCALE method

.EXAMPLE

Get-1EMethodSchema -MethodName Agent.Echo


.PARAMETER MethodName

Specifies the SCALE method for which schema data is required

.PARAMETER AsText

Specifies that the schema should be returned in text form. In text form, the schema is returned as a single string suitable for passing to the -schema parameter for the new-instructionxml cmdlet

#>

[CmdletBinding()]
  param
  (
  [Parameter(Mandatory=$true)][string]$MethodName,
  [Parameter(Mandatory=$false)][switch]$AsText
  )
  if (-not $AsText)
    {
    return GetMethodSchema $MethodName
    }
  else
    {
    $schema = GetMethodSchema $MethodName
    $schemaText = ""
    $notfirst = $false
    foreach ($entry in $schema)
        {
        if ($notfirst)
            {
            $schemaText += ","
            }
        else
            {
            $notfirst = $true
            }
        $schematext += $entry.Name + " " + $entry.Type
        if ($entry.Type -eq "string")
            {
            $schematext += "(256)"
            }
        }
        return $schemaText
    }
}


function Protect-InstructionXml
{
<#
.SYNOPSIS

Protects (signs) the specified instruction XML file. Instructions must be signed with a valid code signing certificate before they can be used with the platform

.EXAMPLE

Protect-1EInstructionXml -Path MyNewInstruction.xml


.PARAMETER Path

Specifies the file to be signed

.NOTES

A valid code signing certificate must be located in the local machine/personal certificate store on the device from which this cmdlet is executed
The platform code signing executable must be located in the same folder as the cmdlet is being run from, as it will be invoked to perform the signing process

#>

[CmdletBinding()]
  param
  (
    [Parameter(Mandatory=$true)][string]$Path
  )
if (-not (test-path -path $path))
    {
    $msg = "Unable to locate the XML file " + $Path
    throw $msg
    }
$signer = $PSScriptRoot + "\${INSTRUCTIONSIGNTOOL}"
& $signer $Path -SkipResources > $null
if ($LASTEXITCODE -ne 0)
	{
	$errMsg =  "${INSTRUCTIONSIGNTOOL} reported Exit code: " + $LASTEXITCODE
	$errMsg += "`r`nEnsure you have an appropriate code signing certificate in your personal store for the local machine"
	$errMsg += "`r`nIf this is the case, does the account you are running from have appropriate permissions?"
	$errMsg += "`r`nIf the signing process works only when you run from an elevated command prompt, you can use the winhttpcertcfg utility"
	$errMsg += "`r`nto add appropriate permissions to the user account you are running from, if you wish"
    throw $errMsg
	} 
}




function New-InstructionXml
{
<#
.SYNOPSIS

Creates a new instruction XML file.

.EXAMPLE

New-1EInstructionXml -Name 1E-Exchange-MyNewInstruction -Path MyNewInstruction.xml -ReadablePayload "Agent Echo Test" -Content '@t = Agent.Echo(Message: "this is a test");' -schema "message string(100)"


.PARAMETER Name

Specifies the name of the instruction to be created

.PARAMETER Path

Specifies the output xml file to be created

.PARAMETER ReadablePayload

Specifies the readable payload of the instruction i.e, how it will be visible in platform searches

.PARAMETER Description

Specifies a description for the instruction. If not specified, the readablepayload parameter value is used

.PARAMETER Content

Specifies the SCALE content to be included in the instruction

.PARAMETER Schema

Specifies the schema for the instruction results. If not specified a default schema "ExitCode int64, Output string(8000)" is used

.PARAMETER Resources

Specifies one or more resource files to be embedded in the instruction. To specify multiple files, pass the parameter as a PowerShell array

.PARAMETER InstructionType

Specifies whether the instruction is a Question or an Action. If not specified, Question is assumed

.PARAMETER Version

Specifies a version for the instruction. If not specified, "1.0" is assumed

.PARAMETER Parameters

Specifies a set of parameters for the instruction. In the simplest case these can just be a comma-separated list of parameter names, which will be interpreted as unconstrained string parameters

.NOTES

Please refer to the online help for more information on method parameters

The -Content property accepts resource objects created using the New-Resource cmdlet. This simplifies the management of embedded resources which are intended to be executed, in particular.

#>

[CmdletBinding()]
  param
  (
  [Parameter(Mandatory=$true)][string]$Name,
  [Parameter(Mandatory=$true)][string]$Path,
  [Parameter(Mandatory=$true)][string]$ReadablePayload,
  [Parameter(Mandatory=$false)][string]$Description = $ReadablePayload,
  [Parameter(Mandatory=$true)][object]$Content,
  [Parameter(Mandatory=$false)][string]$schema = "ExitCode int64, Output string(8000)",
  [Parameter(Mandatory=$false)][string[]]$Resources,
  [Parameter(Mandatory=$false)]
  [ValidateSet('Question','Action')]
    [string]$InstructionType = "Question",
  [Parameter(Mandatory=$false)][string]$Version="1.0",
  [Parameter(Mandatory=$false)][object[]]$parameters


  )
  if (-not ($name -match "-"))
    {
    $fullName = $INSTPREFIX + "-" + $Name
    }
  else
    {
    $fullName = $Name
    }
  # James is picky about case here so normalise.
  if ($instructiontype -eq "question")
    {
    $instructiontype = "Question"
    }
  else
    {
    $instructiontype = "Action"
    }
  $parms = $parameters
  if ($null -ne $parameters)
    {
    $parms = GetParms $parameters
    }
  
  if ($content.GetType().Name -eq "string")
    {
    $xml= CreateInstructionXml $fullName $ReadablePayload $Description $InstructionType $version $content $schema $resources $parms
    }
  else
    {
    # assume content is an object returned from new-resource
    $cnt = $content.Content
    $resources = $content.ResourcePath
    $schema = $content.Schema
    $xml= CreateInstructionXml $fullName $ReadablePayload $Description $InstructionType $version $cnt $schema $resources $parms
    }
  # saveXML doesn't respect current location
  $filepath = GetFullPath $path
  $xml.Save($filepath)
  return "Instruction " +  $fullname + " created as file " + $filepath
}



function New-Resource

{
<#
.SYNOPSIS

Creates a resource object that can be used with the New-InstructionXml cmdlet

.EXAMPLE

New-1EResource -Path script.ps1


.PARAMETER Path

Specifies the path to the resource file which is to be used as the actual embedded resource

.PARAMETER ResourceVar

If specified, overrides the default SCALE variable name used as the target for the resource. The default name is 'Resource'

.PARAMETER InterpretAsJson

If specified, causes the embedded SCALE code associated with the resource to assume that the resource, when executed, returns JSON results which should be deserialised
This parameter is ignored if the Execute parameter is not set

.PARAMETER Execute

If specified, indicates that the embedded resource is to be executed, and creates SCALE code to do so

.PARAMETER CopyTo

If specified, incidates that the embedded resource is to be copied to a destination folder

.PARAMETER Schema

Defines the schema for the resource, when it is executed i.e the data it is expected to return. If not specified, a default schema "ExitCode int64, Output string(8000)" is used

.PARAMETER Force

If specified, and the resource is a PowerShell script, causes the PowerShell execution policy on the receiving endpoints to be overridden. This allows a script to run regardless of the execution policy on the target endpoints

.PARAMETER Parameters

Specifies one or more parameters to be passed to the executed resource. To define multiple parameters, pass them as a PowerShell array

.NOTE

The resulting object can be directly passed to the -Content parameter of the New-InstructionXml cmdlet

#>

[CmdletBinding()]
  param
  (
    [Parameter(Mandatory=$true)][string]$Path,
    [Parameter(Mandatory=$false)][string]$ResourceVar = "Resource",
    [Parameter(Mandatory=$false)][switch]$interpretasJson = $false,
    [Parameter(Mandatory=$false)][switch]$Execute = $false,
    [Parameter(Mandatory=$false)][string]$CopyTo,
    [Parameter(Mandatory=$false)][string]$schema = "ExitCode int64, Output string(8000)",
    [Parameter(Mandatory=$false)][switch]$Force = $false,
    [Parameter(Mandatory=$false)][string[]]$Parameters

  )

  $path = GetFullPath $path
  if (-not (test-path $Path))
    {
    throw "Specified resource file could not be located"
    }
    if (IsLegacyPS)
	{
	    $text = get-content -Raw $Path
	}
    else
	{
	    $text = get-content $Path -AsByteStream
	}
    $length = $text.Length
    $hash = (get-filehash $Path).hash.ToLower()
    
    $baseName = split-path -Path $Path -Leaf
        
    $content = @"
@$($ResourceVar) = HttpGetFile(URL:"$($baseName)", Size:$($length), Hash:"$($hash)");
"@

$resourceType = InferResourceType $Path

if ($execute)
    {
    
    if ($resourceType -ne "Executable" -and $resourceType -ne "PowerShell")
        {
        throw "Execute option not supported for this resource type"
        }
# while we could expose splitlines as a param we then have four combinations, one of which is invalid and really most of the time if we aren't dealing with json we want split lines
    if ($interpretAsJson -eq $false)
        {
        $splitLines = $true
        }
    else
        {
        $splitLines = $false
        }
    $exec = GetExecuteScale $resourceVar $resourceType $splitLines $interpretAsJson $force $parameters
    $content += "`r`n" + $exec
    }

if (-not (IsNullOrEmpty $copyto))
    {
    $cpy = GetCopyScale $resourceVar $copyto.Replace("\","\\")
    $content += "`r`n" + $cpy
    }

$result = New-Object PSObject -Property @{
                Content = $content
                Schema = $schema
                ResourcePath = $path
                ResourceType = $resourceType
                }


return $result
}

function Get-ResourceInfo
{
<#
.SYNOPSIS

Returns information about all embedded resources in an instruction XML file

.EXAMPLE

Get-1EResourceInfo -Path MyInstruction.xml

.PARAMETER Path

Specifies the path to the instruction XML file

#>

[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)][string]$path
)
[xml]$xml = new-object system.xml.xmldocument
$fullPath = GetFullPath $path
$resList = New-Object System.Collections.Generic.List[System.Object]

$xml.Load($FullPath)
foreach ($resource in $xml.InstructionDefinition.Resources)
    {
    $r = $resource.Resource.Content
    #$base64 = $r."#cdata-section"
    $resType = $r.Attributes["Type"]."#text"
    $resName = $r.Attributes["FileName"]."#text"
    $resHash = $r.Attributes["Hash"]."#text"
    $resSize = $r.Attributes["Size"]."#text"
    $resPlatform = $r.Attributes["Platform"]."#text"
    $resEntry = New-Object PSObject -Property @{
                Name = $resName
                Type = $resType
                Size = $resSize
                Hash = $resHash
                Platform = $resPlatform
                }
    $resList.Add($resEntry)
    }
return $resList.ToArray()
}

function Export-Resource
{
<#
.SYNOPSIS

Exports the specified resource from an instruction XML file to create an external resource file

.EXAMPLE

Export-1EResource -Name MyResource -Path MyInstructionFile.xml -OutFile MyResourceFile.txt

.PARAMETER Name

Specifies the name of the resource to be exported

.PARAMETER Path

Specifies the path to the instruction xml file

.PARAMETER OutFile

Specifies the output file to write the exported resource to

#>

[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)][string]$name,
[Parameter(Mandatory=$true)][string]$path,
[Parameter(Mandatory=$false)][string]$outfile
)

[xml]$xml = new-object system.xml.xmldocument
$fullPath = GetFullPath $path
$xml.Load($FullPath)
foreach ($resource in $xml.InstructionDefinition.Resources)
    {
    $r = $resource.Resource.Content
    $resName = $r.Attributes["FileName"]."#text"
    if ($resName -eq $name)
        {
        $base64 = $r."#cdata-section"
        [byte[]]$rawData=[System.Convert]::FromBase64String($base64)
        if (-not (IsNullOrEmpty $outfile))
            {
            $outpath = GetFullPath $outfile
            }
        else
            {
            $outpath = GetFullPath $name
            }
        [io.file]::WriteAllBytes($outpath, $rawData) 
        }
    }
return "resource exported successfully"
}


# The weird parameter sets define two mutually exclusive groups of params i.e {-script,-query, -executable or -scale} and independently either {-TargetScope or -TargetFqdns}


function Invoke-Dynamic
{
<#
.SYNOPSIS

Creates a dynamic instruction, uploads it to the platform and invokes it

.EXAMPLE

Invoke-1EDynamic -Script script.ps1 -TargetScope xyz


.PARAMETER Script

Specifies the name of a PowerShell script to be run. The dynamic instruction will run that script on the target endpoints defined by the scope of the instruction. The script is embedded in the instruction and is not required to be on the endpoints already.

.PARAMETER Query

Specifies a query to be run against a platform Activity Record on the endpoints

.PARAMETER Executable

Specifies an executable file which is to be run on the endpoints. The file will be embedded in the instruction and need not already be present on the endpoints

.PARAMETER Files

Specifies one or more files which are to be copied to a folder on the target endpoints. To specify multiple files, use a PowerShell array

.PARAMETER Path

If the -Files parameter is specified, defines the target path on the endpoints to which the source files should be copied. The target path is automatically created if it does not exist. Any files which already exist and match names are overwritten

.PARAMETER TargetScope
Specifies the scope of the target. The scope defines attributes such as fqdns, operating system version etc associated with the endpoints to which the instruction should be sent when executed

.PARAMETER TargetFqdns
Specifies one or more endpoint fqdns which will be the targets of the instruction selected. This parameter is mutually exclusive with TargetScope

.PARAMETER Force
If specified, and a script has been supplied, causes the PowerShell execution policy on the receiving endpoints to be overridden. This allows a script to run regardless of the execution policy on the target endpoints

.PARAMETER Parameters

Specifies one or more parameter values to pass to a script or executable file. To pass multiple values, use a PowerShell array

.PARAMETER Schema

If specified, defines the schema to be used when returning results from a dynamic script, SCALE snippet or Activity Record table. The default schema is ExitCode int64, Output string(8000) 
When a schema is defined, the script, SCALE or Activity Record is assumed to return data whose content matches the specified schema. For a script, the script must return this data in JSON format
This parameter is ignored for the -Files option


.PARAMETER DataSource

Specifies the data source for a server-side instruction. Specifying this parameter automatically causes the instruction to be considered to be server-side

.PARAMETER RowSourceType

Specifies the row source type for a server-side instruction; the default is 'generic' if not specified

#>

[CmdletBinding(DefaultParameterSetName='A1_B1', SupportsShouldProcess=$true)]
  param
  (
    [string]
    [Parameter(Mandatory=$true,ParameterSetName='A1_B1')]
    [Parameter(Mandatory=$true,ParameterSetName='A1_B2')]
    $Script,

    [string]
    [Parameter(Mandatory=$true,ParameterSetName='A2_B1')]
    [Parameter(Mandatory=$true,ParameterSetName='A2_B2')]
    $Query,

    [string]
    [Parameter(Mandatory=$true,ParameterSetName='A3_B1')]
    [Parameter(Mandatory=$true,ParameterSetName='A3_B2')]
    $Scale,

    [string]
    [Parameter(Mandatory=$true,ParameterSetName='A4_B1')]
    [Parameter(Mandatory=$true,ParameterSetName='A4_B2')]
    $Executable,

    [string[]]
    [Parameter(Mandatory=$true,ParameterSetName='A5_B1')]
    [Parameter(Mandatory=$true,ParameterSetName='A5_B2')]
    $Files,

    [string]
    [Parameter(Mandatory=$true,ParameterSetName='A5_B1')]
    [Parameter(Mandatory=$true,ParameterSetName='A5_B2')]
    $Path,
    

    [string]
    [Parameter(Mandatory=$true,ParameterSetName='A1_B1')]
    [Parameter(Mandatory=$true,ParameterSetName='A2_B1')]
    [Parameter(Mandatory=$true,ParameterSetName='A3_B1')]
    [Parameter(Mandatory=$true,ParameterSetName='A4_B1')]
    [Parameter(Mandatory=$true,ParameterSetName='A5_B1')]
    $TargetScope,

    [string []]
    [Parameter(Mandatory=$true,ParameterSetName='A1_B2')]
    [Parameter(Mandatory=$true,ParameterSetName='A2_B2')]
    [Parameter(Mandatory=$true,ParameterSetName='A3_B2')]
    [Parameter(Mandatory=$true,ParameterSetName='A4_B2')]
    [Parameter(Mandatory=$true,ParameterSetName='A5_B2')]
    $TargetFqdns,

    [Parameter(Mandatory=$false)] [switch] $Force = $false,	
    [Parameter(Mandatory=$false)] [string[]] $Parameters,
    [Parameter(Mandatory=$false)] [string] $Schema,
    [Parameter(Mandatory=$false)] [string] $DataSource,
    [Parameter(Mandatory=$false)] [string] $RowSourceType
  )

Process
{
if (IsNullOrEmpty $INSTPREFIX)
    {
    throw "You must specify an instruction namespace prefix to use (e.g ACME) for which you have a valid license and signing certificate. Use set-instructionprefix to define this"
    }


if ((IsNullOrEmpty $script) -and (IsNullOrEmpty $query) -and (IsNullOrEmpty $scale) -and (IsNullOrEmpty $executable) -and (IsNullOrEmpty $files))
	{
	throw "Must specify either script, SCALE file, executable, query to invoke, or files to copy remotely"
	return
	}
# Platform version 5.2; this will throw for an invalid instruction set, for earlier releases it will not, so handle both
try
    {
    $setid = getInstructionSetId $INSTRUCTIONSET
    }
    catch
    {
    }
if (IsNullOrEmpty $setid)
	{
    [void](new-InstructionSet -InstructionSet $INSTRUCTIONSET)
	}

#did user specify whatif? If so, simply return target list

if (-not $pscmdlet.ShouldProcess($instruction))
	{
	if (-not (IsNullOrEmpty $TargetScope))
		{
		return (Get-RespondingDevice -TargetScope $TargetScope -Active)
		}
	else
		{
		$ret = New-Object System.Collections.Generic.List[System.Object]           
	        foreach ($fqdn in $fqdns)
        	        {
                	$v = New-Object PSObject -Property @{Fqdn = $fqdn}
	                $ret.Add($v)
        	        }
            	return $ret.ToArray()		
		}
	}

# see if the proposed scope would select 0 devices or too many devices

if (-not (IsNullOrEmpty $TargetScope))
	{
	$targetCount = Get-RespondingDeviceCount -TargetScope $TargetScope -Active
	if ($null -eq $targetCount -or $targetCount -eq 0)
		{
		throw "No target devices identified by the specified target scope ("  + $TargetScope + ")"
		}

	}
else
	{
	$targetCount = $TargetFqdns.Count
	if ($null -eq $targetCount -or $targetCount -eq 0)
		{
		throw "No target devices identified by the specified fqdn array"
		}
	}



if ($targetCount -gt $MAXTARGETDEVICES)
	{
	throw "The scope of this instruction (" +  $targetCount +  ") devices exceeds the specified maximum (" + $MAXTARGETDEVICES  + ")"
	}
# try and delete any expired instructions in the set; if they are still active, the delete will fail silently

$insts = Get-InstructionInSet -InstructionSet $INSTRUCTIONSET

foreach ($i in $insts)
    {
    try
        {
        Remove-Instruction -Id $i.Id
        }
    catch
        {
        }
    }

# create a new dynamic instruction name

$guid = [string](new-guid)
$guid = $guid -replace "-" , ""

$instruction = $INSTPREFIX + "-" + $guid

$output = "_temp.xml"
$readablePayload = $instruction
$description = "Dynamically invoked script"
$instructionType = "Question"
$version = "1.0"

$defaultSchema = "ExitCode int64, Output string(8000)"

if (IsNullOrEmpty $schema)
    {
    $schema = $defaultSchema
    }

#examine arg to see if it is a script, query or SCALE file
if (-not (IsNullOrEmpty $script))
    {
    $argpath = $Script
    }

if (-not (IsNullOrEmpty $executable))
    {
    $argpath = $executable
    }

if (-not (IsNullOrEmpty $argpath))
	{
	if (-not (Test-Path $argpath))
		{
		throw "File " + $argpath + " could not be opened"
		}
    if ($schema -eq $defaultSchema)
	{
	    if ($force)
		{
		    $content = New-Resource -Path $argpath -ResourceVar Resource1 -Execute -Force -Parameters $Parameters -Schema $schema
		}
	     else
		{
		   $content = New-Resource -Path $argpath -ResourceVar Resource1 -Execute -Parameters $Parameters -Schema $schema
		}
	}
    else
	{
	    if ($force)
		{
		    $content = New-Resource -Path $argpath -ResourceVar Resource1 -Execute -Force -Parameters $Parameters -Schema $schema -InterpretAsJson 
		}
	    else
		{
		    $content = New-Resource -Path $argpath -ResourceVar Resource1 -Execute -Parameters $Parameters -Schema $schema -InterpretAsJson 
		}
	}
    $cnt = $content.Content
    $resources = $content.ResourcePath
    $schema = $content.Schema

    $outXml= CreateInstructionXml $instruction $ReadablePayload $Description $InstructionType $version $cnt $schema $resources
    }

if (-not (IsNullOrEmpty $files))
    {
    if (IsNullOrEmpty $path)
        {
        throw "You must specify a remote destination path for the files to be copied"
        }

    $i = 0
    $resources = New-Object System.Collections.Generic.List[System.Object]
    foreach ($file in $files)
        {
        if (-not (Test-Path $file))
            {
            throw "File " + $file + " could not be opened"
            }
            $i++
            $resourceVar = "Resource" + $i
            $content = New-Resource -Path $file -ResourceVar $ResourceVar -CopyTo $path
            $cnt += "`r`n" + $content.Content
            [void]$resources.add($content.ResourcePath)

        }
     $postamble =
      @"
        `r`nselect 0 ExitCode,  "$($i) Files Copied" Output;
"@
    $cnt += $postamble
    #Always uses the default schema
    $schema = $defaultSchema
    $outXml= CreateInstructionXml $instruction $ReadablePayload $Description $InstructionType $version $cnt $schema $resources
    }


if ($scale -ne "")
	{

    $content = get-content -path $scale -raw
    if (IsNullOrEmpty $DataSource)
        {
        if ($schema -eq $defaultSchema)
            {
            $suffix = @"
            @out = Utilities.JsonFromTable(Table: @result);
            select 0 ExitCode, Json Output from @out;
"@
            }
        else
            {
            $suffix = @"
            select * from @result;
"@
            }
        $content += $suffix
        }
    else
        {
        if ($schema -eq $defaultSchema)
            {
            throw "You must specify an explicit schema when creating server-side instructions"
            }
        if (IsNullOrEmpty $RowSourceType)
            {
            $RowSourceType="Generic"
            }
        }
    
    $outXml= CreateInstructionXml $instruction $ReadablePayload $Description $InstructionType $version $content $schema "" "" $DataSource $RowSourceType
    }


if (-not (IsNullOrEmpty $query))
    {
    $prefix = "@result = "
    if ($schema -eq $defaultSchema)
        {
        $suffix = @"
        ;@out = Utilities.JsonFromTable(Table: @result);
        select 0 ExitCode, Json Output from @out;
"@
        }
    else
        {
        $suffix = @"
        ;select * from @result;
"@

        }

    $content = $prefix + $query +  $suffix

    $outXml= CreateInstructionXml $instruction $ReadablePayload $Description $InstructionType $version $content $schema

    }
# saveXML doesn't respect current location
$outpath = GetFullPath $output
$outXml.Save($outpath)
Protect-InstructionXml -Path $output
$r = Publish-Instruction -File $output -InstructionSet $INSTRUCTIONSET
$id = Get-InstructionId -Instruction $instruction
if ($null -eq $id)
    {
    throw "cannot locate uploaded instruction. Does the account you are running from have appropriate platform permissions to upload?"
    }

$arguments = @{}

if (-not (IsNullOrEmpty $TargetScope))
	{
	$arguments.Add("TargetScope",$TargetScope)
	}

if ($null -ne $TargetFqdns)
	{
	$arguments.Add("TargetFqdns",$TargetFqdns)
	}

if ($informationPreference -eq "Continue")
	{
	$arguments.Add("InformationAction","Continue")
	}

$r = Invoke-Instruction $instruction @arguments
return $r
}

}

############### BEGIN SLA API section ########################


function Get-SLAComponentHealth
{
<#
.SYNOPSIS

Returns the status of the SLA subsyste,

.EXAMPLE

Get-1ESLAComponentHealth

#>

[CmdletBinding()]
Param()

$url = "/platform/api/ComponentHealth"
$res = GetHttpRequest $url
return $res
}


function Publish-ConditionalAction
{
<#
.SYNOPSIS

Publishers (uploads) a conditional action as a script to be run server-side as part of a scheduled conditional evaluation

.PARAMETER Path

Specifies the path and name of a script to be published. The script must be validly signed with a code signing certificate which is associated with a trusted publisher on the 
platform server. This cmdlet does not verify that the script is signed.

.PARAMETER Force

Specifies that any existing copy of the script should be replaced. If not specified, and the destination script already exists, an error is thrown.

.EXAMPLE

Publish-1EConditionalAction -Path c:\scripts\myscript.ps1

.NOTES

Regardless of the source path to this cmdlet, Conditional Action scripts are published to a fixed path on the platform server. They must therefore all be distinct by name. 

#>

[CmdletBinding()]
Param(
[string][Parameter(Mandatory=$true)]$Path,
[switch][Parameter(Mandatory=$false)]$Force
)

$url = "/consumer/conditionalactions"
try
{
$content = get-content $Path -raw -ErrorAction stop
}
catch
{
throw "the specified file could not be found"
}
$encodedContent = ToBase64 $content
$baseName = split-path -Path $Path -Leaf
if (-not $Force)
    {
    $actions = Get-ConditionalAction
    foreach ($action in $actions)
        {
        if ($action -eq $basename)
            {
            throw "Specified conditional action already exists, use -Force to overwrite"
            }
        }
    }
$payload = @"
{
$(quotify $basename) : $(quotify $encodedContent)
}
"@
$res = PostHttpRequest $url $payload
return $res
}


function Get-ConditionalAction
{
<#
.SYNOPSIS

Returns all conditional action scripts which have been defined on the platform server

.EXAMPLE

Get-1EConditionalAction


#>

[CmdletBinding()]
Param(
)

$url = "/consumer/conditionalactions"
$res = GetHttpRequest $url
return $res
}


function Remove-ConditionalAction
{
<#
.SYNOPSIS

Removes (deletes) a conditional action

.PARAMETER Name

Specifies the name of a conditional action to be removed. An error is thrown if the conditional action does not exist


.EXAMPLE

Remove-1EConditionalAction -Name myscript.ps1

#>

[CmdletBinding()]
Param(
[string][Parameter(Mandatory=$true)]$Name
)

$url = "/consumer/conditionalactions"
$actions = Get-ConditionalAction
$found = $false
foreach ($action in $actions)
    {
        if ($action -eq $name)
            {
            $found = $true
            break
            }
    }
if (-not $found)
    {
    throw "The specified conditional action was not found"
    }
$url += "/" + $name
$res = DeleteHttpRequest $url
return $res
}

function Publish-Schedule
{
<#
.SYNOPSIS

Publishes a platform schedule.

.PARAMETER InstructionName

Specifies the name of the instruction to be scheduled

.PARAMETER TargetScope

Specifies the target scope for the instruction when it is executed. 

.PARAMETER Schedule

Specifies the schedule options to be used. See notes for valid schedule options

.PARAMETER EvaluationCondition

If specified, provides an evaluation condition which, if met, causes the supplied task script to be executed on the platform server. See notes for valid evaluation conditions.
If no task script parameter is supplied, this property has no effect

.PARAMETER Task

Specifies a conditional action task script to be executed when the schedule is run. If an evaluation condition is specified, it must be met before the conditional action task script is executed. 
Otherwise, the task script is executed unconditionally when the instruction has been run.

.PARAMETER StartDate

If specified, defines the date on which the schedule becomes effective. Format is YYYY-mm-dd
If not specified, defaults to today's date

.PARAMETER StartTime

If specified, defines the time on the start date when the schedule becomes effective. The format is HHmmss e.g 102320 is 10:23:20am

.PARAMETER EndDate

If specified, defines the date on which the schedule stops being effective. Format is YYYY-mm-dd
If not specified, defaults to one day after the start date

.PARAMETER EndTime

If specified. defines the time on the end date at which the schedule stops being effective. If not specified, defaults to 23:59:59. Format is HHmmss i.e 235959 is 23:59:59pm

.PARAMETER InstructionTtlMins

If specified, defines how long the instruction will remain actively retrieving data. Default is 60 minutes

.PARAMETER ResponseTtlMins

If specified, defines how long the instruction results will remain available after the instruction has ceased to actively retrieve data. Default is 60 minutes

.PARAMETER ConsumerCustomData

If specified, provides arbitrary data which is passed through and retrievable when the instruction is scheduled, using the get-1Einstructionstatus cmdlet.
If a string is passed this is stored directly. Otherwise if an object is passed it is assumed to be a serialisable object that can be encoded as JSON
For example, @{Property = "Value"} will be encoded as {"Property": "Value"} and stored as a JSON-encoded string


.NOTES

Valid schedule options are:-
Once
[Every] nn mins|minutes
Hourly
Daily
Weekly [on day n] - Sunday (default) = day 1 of week
Monthly [on day nn] - default day 1 of month


#>

[CmdletBinding()]
Param(
[string][Parameter(mandatory=$true)]$InstructionName,
[string][Parameter(mandatory=$true)]$TargetScope,
[string][Parameter(mandatory=$true)]$Schedule,
[string][Parameter(mandatory=$false)]$EvaluationCondition,
[string][Parameter(mandatory=$false)]$Task,
[datetime][Parameter(mandatory=$false)]$StartDate,
[datetime][Parameter(mandatory=$false)]$EndDate,
[int][Parameter(mandatory=$false)]$StartTime = 0,
[int][Parameter(mandatory=$false)]$EndTime = 0,
[int][Parameter(mandatory=$false)]$InstructionTtlMins = 60,
[int][Parameter(mandatory=$false)]$ResponseTtlMins = 60,
[object][Parameter(mandatory=$false)]$ConsumerCustomData = ""
)

DynamicParam {
    $OFFSET = 12 #Change if fixed param count above changes
    $ret = BuildDynamicParams $instructionName $OFFSET
    return $ret.Dict
    }

Process
{
    # if Starttime is 0 and we ask for a one shot schedule today, set start time to now otherwise API will throw
    if ($schedule -eq "once" -and $starttime -eq 0 -and ((IsNullOrEmpty $StartDate) -or ((get-date) - [datetime]((get-date).ToString("yyyy-MM-dd"))).Days -eq 0))
    {
        $starttime = ((get-date).AddMinutes(1)).ToString("HHmmss")
    }

    if (IsNullOrEmpty $StartDate)
        {
        $StartDate = (Get-Date).ToUniversalTime()
        $StartDateString = $StartDate.ToString("yyyy-MM-dd")
        }
    else
        {
        $StartDateString = $StartDate.ToString("yyyy-MM-dd")
        }

    if (IsNullOrEmpty $EndDate)
        {
        $EndDate = $StartDate.AddDays(1)
        $EndDateString = $EndDate.ToString("yyyy-MM-dd")
        }
    else
        {
        $EndDateString = $EndDate.ToString("yyyy-MM-dd")
        }
    if ($StartDate -gt $EndDate)
        {
        throw "Schedule start date must not be less than its end date" # API validation can cause confusing errors, so we validate for it
        }

    if ($endtime -eq 0)
        {
        $endtime = 235959
        }

    $sched = Get-ScheduleParam $Schedule

    $url = "/consumer/scheduledinstructions"

    $res = Get-Instruction -Name $InstructionName

    $params = BuildParams $ret.Metadata $PSBoundParameters # TODO: do we need default props support as for invoke-instruction?


    if (-not (IsNullOrEmpty $Task))
    {
    $taskString = quotify $task
    if (IsNullOrEmpty $EvaluationCondition)
        {
        $evaluateConditionOn = quotify "Always"
        $evaluateConditionExpr = "null"
        }
    else
        {
        $evaluateConditionOn = quotify "Impact"
        $evaluateConditionExpr = get-scope $evaluationcondition
        }
    }
    else
    {
        $evaluateConditionOn = "null"
        $evaluateConditionExpr = "null"
        $taskString = "null"
    }

    if ($consumercustomdata.gettype().Name -eq "String")
        {
        $customdata = quotify $consumercustomdata
        }
    else
        {
        $customdata = $consumercustomdata | convertto-json -compress
        $customdata = "'" + $customdata + "'"
        }

    $payload = @"
    {
    "DefinitionId" : $($res.Id),
    "Export": false,
    "ExportLocation": null,
    "InstructionTtlMinutes": $($InstructionTtlMins),
    "KeepRaw": 1
    $(FormatAttribute "Parameters" $params),
    "ParameterJson": null,
    "ParentInstructionId": null,
    "PreviousResultsFilter": {},
    "ResponseTtlMinutes": $($ResponseTtlMins),
    "ResultsFilter": {},
    "ScheduleActiveStartDate": $(quotify $StartDateString),
    "ScheduleActiveStartTime": $($startTime),
    "Task": $($taskString),
    "EvaluationCondition":  $($evaluateconditionExpr),
    "EvaluateConditionOn": $($evaluateConditionOn),
    "ScheduleActiveEndDate": $(quotify $EndDateString),
    "ScheduleActiveEndTime": $($endTime),
    "ScheduleEnabled": true,
    "ScheduleFreqType": $($sched.ScheduleFreqType),
    "ScheduleFreqInterval": $($sched.ScheduleFreqInterval),
    "ScheduleFreqSubdayType": $($sched.ScheduleFreqSubdayType),
    "ScheduleFreqSubdayInterval": $($sched.ScheduleFreqSubdayInterval),
    "ScheduleFreqRelativeInterval": 0,
    "ScheduleFreqRecurrenceFactor": $($sched.ScheduleFreqRecurrenceFactor),
    "Scope": $(RetrieveScope $targetscope),
    "DisallowCatchup":"false",
    "ConsumerCustomData": $($CustomData)
    }

"@
    $res = PostHttpRequest $url $payload
    return $res
    }
}


function Get-Schedule
{
<#
.SYNOPSIS

Retrieves all Schedules or the schedule for which an Id was specified

.PARAMETER Id

Specifies the platform Id of the schedule to be retrieved


#>

[CmdletBinding()]
Param(
[int][Parameter(mandatory=$false)]$Id
)

if ($Id -eq 0)
    {
    $url = "/consumer/scheduledinstructions"
    }
else
    {
    $url = "/consumer/scheduledinstructions/" + $Id
    }
$res = GetHttpRequest $url
return $res
}

function Remove-Schedule
{
<#
.SYNOPSIS

Removes (deletes) a platform schedule

.PARAMETER Id

Specifies the platform Id of the schedule to be removed

.EXAMPLE

Remove-1ESchedule -Id 3


#>

[CmdletBinding()]

Param(
[int][Parameter(mandatory=$true)]$Id
)

$url = "/consumer/scheduledinstructions/" + $id
$res = DeleteHttpRequest $url
return $res
}


function Get-ScheduleActivation
{
<#
.SYNOPSIS

Retrieves all activations that have occurred for a schedule

.PARAMETER Id

Specifies the platform Id of the schedule for which activations are to be retrieved

.EXAMPLE

Get-1EScheduleActivation -Id 3


#>

[CmdletBinding()]

Param(
[int][Parameter(mandatory=$true)]$Id
)
#TODO: throws if no history!
try
{
    $res = Get-Schedule -id $Id
}
catch
{
    throw "The specified schedule ID does not exist"
}

$url = "/consumer/scheduledinstructions/search"
$tomorrow = ((get-date).AddDays(1)).ToString("yyyy-MM-dd")

$payload = @"
{
    "EndDate": $($tomorrow),
    "Attribute": "DefinitionId",
    "Operator": "==",
    "Value": $($Id)
}
"@

try
    {
    $res = PostHttpRequest $url $payload
    return $res
    }
catch
    {
    }
    return @()
}


function Get-ScheduleParam
{
<#
.SYNOPSIS

Retrieves the schedule parameters for a specified schedule

.PARAMETER Schedule

Specifies the schedule for which parameters are to be retrieved

.EXAMPLE

Remove-1EScheduleParam -Schedule Daily


#>

[CmdletBinding()]

Param(
[string][Parameter(mandatory=$true)]$Schedule
)
return ParseSchedule $Schedule
}


function Get-InstructionResultFqdn
{
<#
.SYNOPSIS

Returns a set of distinct device FQDNs from an instruction result

.EXAMPLE

Get-1EInstructionResultFqdn -Id 3

.PARAMETER Id

Specifies the Id of the instruction in history (see get-1Einstructionhistory)

#>


[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)] [int]$Id
)
$url = "/Consumer/Responses/" + $Id + "/UniqueFqdns"
# TODO: pagesize is pragmatic compromise to avoid implementing paging logic for this; may need reviewing later but what would consumer do with a huge list anyway?
$payload = @"
{
"Start": "0;0",
"PageSize": 100000 
}
"@
$ret = PostHttpRequest $url $payload
return $ret
}

# modern auth cmdlets

function Get-JwtPrincipalMapping
{
<#
.SYNOPSIS

Returns the current set of mappings between Jwt certificate thumbprints and principals

.EXAMPLE

Get-1EJwtPrincipalMapping


#>


[CmdletBinding()]
Param(
)
$url = "/Consumer/KidToUpnMappings"
$ret = GetHttpRequest $url
return $ret
}

function Add-JwtPrincipalMapping
{
<#
.SYNOPSIS

Adds the specified Jwt principal mapping

.PARAMETER Identifier

Specifies the base 64 representation of the signing certificate thumbprint

.PARAMETER Principal

Specifies the user principal name to be associated with the thumbprint, or "*" to associate any user principal

.EXAMPLE

Add-1EJwtPrincipalMapping -identifier  "LYwS5N58Xzm5AkTQdm-lcpZdFSM" -principal "Bob.Smith@myorg.com"

.NOTES 

The identifier should be the base 64 representation of a certificate thumbprint.
To return the base 64 representation of a certificate thumbprint, use the Get-1ECertificateThumbprint cmdlet
Use wildcard mapping with caution. It allows any holder of the signing certificate to request any platform identity and is recommended only for testing purposes.

#>


[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)] [string]$Identifier,
[Parameter(Mandatory=$true)] [string]$Principal
)
$url = "/Consumer/KidToUpnMapping"
$payload = @"
{
"Kid": $(quotify $Identifier),
"Upn": $(quotify $principal)
}
"@

$ret = PostHttpRequest $url $payload
return $ret
}

function Remove-JwtPrincipalMapping
{
<#
.SYNOPSIS

Removes the Jwt to principal mapping specified by the Id

.EXAMPLE

Remove-1EJwtPrincipalMapping -Id 1


#>


[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)] [int]$Id
)

$url = "/Consumer/KidToUpnMapping/" + $Id
$ret = DeleteHttpRequest $url
return $ret
}

function Get-CertificateThumbprint
{
<#
.SYNOPSIS

Returns the thumbprint in base 64 URL-safe format, for all certificates in the  store specified, along with the certificate properties

.PARAMETER StoreName

Specifies the certificate store to be searched

.PARAMETER Certificate

Specifies an X509 Certificate to be used

.EXAMPLE

Get-1ECertificateThumbprint -StoreName "LocalMachine\My"

.NOTES

This cmdlet is useful when using the Add-1EJwtPrincipalMapping cmdlet to map certificates to principals
On non-Windows platforms you should query the CurrentUser\My certificate store

#>


[CmdletBinding()]
Param(
[Parameter(Mandatory=$false)] [string]$StoreName,
[Parameter(Mandatory=$false)] [object]$Certificate
)
if ((IsNullOrEmpty $StoreName) -and (IsNullOrEmpty $Certificate))
	{
	throw "You must specify either a store name or a certificate"
	}
if (-not (IsNullOrEmpty $Certificate))
	{
	$certs = New-Object System.Collections.Generic.List[System.Object]
	[void]$certs.Add($Certificate)
	}
else
	{
	$os = GetOS
	if ($os -eq "Windows")
		{
		$path = "cert:\" + $storename
		$certs = get-childitem $path
		}
	else
		{
	 	$certs = GetCertFromStore $storename
		}
	}

$certList = New-Object System.Collections.Generic.List[System.Object]
foreach ($cert in $certs)
    {
    $CertEntry = New-Object PSObject -Property @{
                Subject = $cert.Subject
                Thumbprint=$cert.Thumbprint
                Kid=getThumbprint $cert.Thumbprint
                }
    [void]$certList.Add($CertEntry)
    }
    return $certList
}


function Update-AuthToken
{
<#
.SYNOPSIS

Refreshes or recreates the current authentication token, depending on whether it is an interactive or non-interactive, or platform token


.EXAMPLE

Update-1EAuthToken

.NOTES

An error is thrown if there is no current authentication token, or if the current token cannot be refreshed or recreated


#>


[CmdletBinding()]
Param(
)
if (-not (HaveValidToken))
	{
	throw "There is no current authentication token"
	}

$decodedToken = get-authtoken -Decode

if ($decodedToken.Type -eq 0)
	{
	# interactive token, refresh
    $tok = $script:AUTHTOKEN
    $script:AUTHTOKEN = GetEmptyToken
    $authToken = RefreshAuthToken $tok # this prevents an infinite regression getting tokens to get tokens
    $authTokenDecoded = DecodeAuthToken $authToken
    $script:AUTHTOKEN = New-Object PSObject -Property @{
		Token = $authToken
		ExpiryTime = GetTokenExpiryUTC $authToken
		IssueAppId = $null
		IssueCertSubject = $null
		IssueCertThumbprint = $null
		IssuePrincipal = $authTokenDecoded.UserName
		TokenType = $authTokenDecoded.Type
		}
	return $script:AUTHTOKEN
	}

if ($decodedToken.Type -eq 1)
	{
	# non-interactive token, do the JWT grant flow again
	if (-not (IsNullOrEmpty $script:AuthToken.IssueCertSubject))
		{
		$cert = GetCertBySubject $script:AuthToken.IssueCertSubject	
		}
	else
		{
		$cert = GetCertByThumbprint $script:AuthToken.IssueCertThumbprint
		}
    $AppId =  $script:AuthToken.IssueAppId
    $Principal = $decodedToken.UserName
    $CertSubject = $script:AuthToken.IssueCertSubject
    $CertThumbprint = $script:AuthToken.IssueCertThumbprint
    $script:AUTHTOKEN = GetEmptyToken # this ensures we don't get into an infinite loop trying to get a token to get a token (because the actual auth endpoint of course is not authenticated)
    $tokenEndpoint = GetTokenEndpoint (GetMetadataEndpoint)
    $authToken = GetAuthToken $cert $Principal $tokenEndpoint $AppId
    $authTokenDecoded = DecodeAuthToken $authToken
	$script:AUTHTOKEN = New-Object PSObject -Property @{
		Token = $authToken
		ExpiryTime = GetTokenExpiryUTC $authToken
		IssueAppId = $AppId
		IssueCertSubject = $CertSubject
		IssueCertThumbprint = $CertThumbprint
		IssuePrincipal = $authTokenDecoded.UserName
		TokenType = $authTokenDecoded.Type
		}
	return $script:AUTHTOKEN
	}


if ($decodedToken.Type -eq 2)
	{
	# platform token, request a new one
	if (-not (IsNullOrEmpty $script:AuthToken.IssueCertSubject))
		{
		$cert = GetCertBySubject $script:AuthToken.IssueCertSubject	
		}
	else
		{
		$cert = GetCertByThumbprint $script:AuthToken.IssueCertThumbprint
		}
        $CertSubject = $script:AuthToken.IssueCertSubject
        $CertThumbprint = $script:AuthToken.IssueCertThumbprint
        $script:AUTHTOKEN = GetEmptyToken # this ensures we don't get into an infinite loop trying to get a token to get a token (because the actual auth endpoint of course is not authenticated)
	if (-not (IsNullOrEmpty $CertThumbprint))
		{
		$authToken = get-platformtoken -CertThumbprint $CertThumbprint
		}
	else
		{
		$authToken = get-platformtoken -CertSubject $CertSubject
		}

	$authTokenDecoded = DecodeAuthToken $authToken
	$script:AUTHTOKEN = New-Object PSObject -Property @{
		Token = $authToken
		ExpiryTime = GetTokenExpiryUTC $authToken
		IssueCertSubject = $CertSubject
		IssueCertThumbprint = $CertThumbprint
		IssuePrincipal = $authTokenDecoded.UserName
		TokenType = $authTokenDecoded.Type
		}
	return $script:AUTHTOKEN
	}
}


function Revoke-AuthToken
{
<#
.SYNOPSIS

Revokes (invalidates) the current platform authentication token, if any


.EXAMPLE

Revoke-1EAuthToken

.NOTES

This cmdlet will not throw an error if the authentication token does not exist.


#>


[CmdletBinding()]
Param(
)
if (-not (HaveValidToken))
	{
	return
	}

try
	{
	$res = InvalidateAuthToken $script:AUTHTOKEN
	$script:AUTHTOKEN = GetEmptyToken
	return $res
	}
catch
	{
	$script:AUTHTOKEN = GetEmptyToken
	throw 
	}
}

function Get-BearerToken
{
<#
.SYNOPSIS

Retrieves a bearer token from the identity provider associated with the platform


.EXAMPLE

Get-1EBearerToken -AppId <appid> -CertSubject <subject>

.PARAMETER AppId

Specifies the application Id of the registered application associated with the identity provider that is to be asked for a bearer token

.PARAMETER CertSubject

Specifies the subject of the certificate to be used to sign the JWT which will request the bearer token

.PARAMETER Certificate

Specifies a certificate to be used to sign the JWT which will request the bearer token

.PARAMETER MetadataEndpoint

Specifies the metadata endpoint of the identity provider to be used. If not specified, the platform is contacted to obtain the metadata endpoint for its configured identity provider. 
In that situation, you must call Set-1EServer first. You can use the -BypassAuth parameter to that cmdlet to bypass any authentication, when troubleshooting

.PARAMETER Secret

Allows a bearer token to be retrieved from an identity provider such as Ping, which does not support the client assertion grant flow. You must obtain the shared secret for the specified application
When Secret is specified, you do not specify any certificate-related information because a different grant flow (client credentials) is used to communicate with the IdP


.NOTES

This cmdlet is intended for test purposes. You can verify that your platform identity provider is functioning correctly and retrieve a bearer token for any application that is appropriately configured
When using a shared secret, note that the platform configured for such an IdP acts as a proxy and still accepts signed JWTs, not secrets, from external integration apps
The platform will instead verify the JWT and then use an internal secret to communicate with the IdP. 

#>


[CmdletBinding()]
Param(
     [Parameter(Mandatory=$true)] [string]$AppId,
     [Parameter(Mandatory=$false)] [string]$CertSubject,
     [Parameter(Mandatory=$false)] [object]$Certificate,
     [Parameter(Mandatory=$false)] [string]$MetadataEndpoint,
     [Parameter(Mandatory=$false)] [string]$Secret
)
     if ((IsNullOrEmpty $secret) -and (IsNullOrEmpty $certsubject) -and (IsNullOrEmpty $Certificate))
		{
		throw "You must specify either a shared secret,certificate or a certificate subject"
		}
      
     if (IsNullOrEmpty $MetadataEndpoint)
	{
         $endpoint = GetMetadataEndpoint
	     $tokenEndpoint = GetTokenEndpoint ($endpoint) 
	}
     else
	{
         $endpoint = $MetadataEndpoint
	     $tokenEndpoint = GetTokenEndpoint $MetadataEndpoint
	}

     # somewhat hacky way of determining if IdP is Okta, in which case we need different scope
     $scope = ".default"

        if ($endpoint.Contains("okta"))
            {
	    # ask for the minimum scope we expect to be set up
            $scope = "okta.users.read"
            }

        if ($endpoint.Contains("ping"))
            {
            $scope = "openid"
            }

    if (-not (IsNullOrEmpty $Secret))
        {
        $res = GetBearerToken $cert $tokenEndpoint $appId $scope $secret
        return $res
        }

    if (-not (IsNullOrEmpty $Certificate))
	{
	$cert = $Certificate
	}
     else
	{
     	$cert = GetCertBySubject $certSubject
	}	


     $res = GetBearerToken $cert $tokenEndpoint $appId $scope
     return $res
}


function Get-MetadataEndpoint
{
<#
.SYNOPSIS

Retrieves the metadata endpoint for the identity provider (if any) configured for the platform


.EXAMPLE

Get-1EMetadataEndpoint


.NOTES

This cmdlet is intended for test purposes. You can verify that your platform identity provider is correctly configured as part of troubleshooting


#>


[CmdletBinding()]
Param(
)
     $res = GetMetadataEndpoint
     return $res
}


function Get-PlatformToken
{
<#
.SYNOPSIS

Retrieves a platform token.

.PARAMETER CertSubject

Specifies the subject of the certificate to be used to sign the assertion which will request the platform token

.PARAMETER CertThumbprint

Specifies the thumbprint of the certificate to be used to sign the assertion which will request the platform token

.PARAMETER Cert

Specifies a retrieved X509 Certificate which will be used direct


.PARAMETER Decode

If specified, returns the token as a PowerShell object

.EXAMPLE

Get-1EPlatformToken -CertSubject <certsubject>


.NOTES

This cmdlet is intended for test and integration purposes. You can verify that your platform identity provider is correctly configured as part of troubleshooting


#>


[CmdletBinding()]
Param(
     [Parameter(Mandatory=$false)] [string]$CertSubject,
     [Parameter(Mandatory=$false)] [string]$CertThumbprint,
     [Parameter(Mandatory=$false)] [object]$Certificate,
     [Parameter(Mandatory=$false)] [switch]$Decode
)
     if ((IsNullOrEmpty $CertSubject) -and (IsNullOrEmpty $CertThumbprint) -and (IsNullOrEmpty $certificate))
	{
	throw "You must specify either a certificate subject, a certificate thumbprint or a certificate"
	}
     if (-not (IsNullOrEmpty $Certificate))
		{
		$cert = $Certificate
		}
     else
     {
     if (-not (IsNullOrEmpty $CertThumbprint))
	{
	    $cert = GetCertByThumbprint $certThumbprint
	}
     else
	{
	     $cert = GetCertBySubject $certSubject
	}
     }
     $assert = $script:PLATFORMPRINCIPAL + "." + $script:TENANTID + "." +  (GetUtcNow).Ticks.ToString()
     $assert = ToBase64UrlString $assert
     $assertion = GetSignedAssertion $assert $cert
     $url = $TACHYONAUTHENDPOINT +"/RequestPlatformAuthentication"
     $res = PostHttpRequest $url (quotify $assertion)	
     if ($Decode)
	{
    	return DecodeAuthToken $res
	}

     return $res
}

function Get-Jwt
{
<#
.SYNOPSIS

Retrieves a Jwt which would otherwise be signed and submitted to an identity provider. This cmdlet is intended for test purposes.

.EXAMPLE

Get-1EJwt -AppId <appId>

.PARAMETER AppId
Specifies the application Id of the application for which the JWT is being created

.PARAMETER Principal
If specified, adds a custom member property to the JWT defining the desired platform principal that is to be requested

.PARAMETER MetadataEndpoint
If specified, defines the metadata endpoint which is to be contacted in order to retrieve the token issuing endpoint which will be
filled in when creating the JWT
If not specified, the user is assumed to have already connected to a platform instance using the Set-1EServer cmdlet, and the appropriately configured
metadata endpoint will be retrieved from the platform instead


.NOTES

This cmdlet is intended only for test purposes. It does not sign or submit the JWT to the Identity Provider

#>
[CmdletBinding()]
Param(
  [Parameter(Mandatory=$true)] [string]$AppId,
  [Parameter(Mandatory=$false)] [string]$Principal,
  [Parameter(Mandatory=$false)] [string]$MetaDataEndpoint
)

if (IsNullOrEmpty $MetadataEndpoint)
	{
	$metadataEndpoint = GetMetadataEndpoint
	}
write-information -MessageData ([string](get-date) + " Attempting to retrieve token issuing endpoint for identity provider")
$tokenEndpoint = GetTokenEndpoint $MetadataEndpoint
write-information -MessageData ([string](get-date) + " Retrieved endpoint: " + $tokenEndpoint)
return GetJwt $tokenEndpoint $AppId $AppId $Principal
}

function Get-JwtHeader
{
<#
.SYNOPSIS

Retrieves a Jwt header which would otherwise be signed and submitted to an identity provider. This cmdlet is intended for test purposes.

.EXAMPLE

Get-1EJwtHeader -CertSubject <certSubject>

.PARAMETER CertSubject

Specifies the subject of the certificate whose thumbprint will be included in the header

.PARAMETER Certificate

Specifies an X509 Certificate whose thumbprint will be included in the header

.NOTES

This cmdlet is intended only for test purposes. It does not sign or submit the JWT header to the Identity Provider

#>
[CmdletBinding()]
Param(
  [Parameter(Mandatory=$false)] [string]$CertSubject,
  [Parameter(Mandatory=$false)] [object]$Certificate
)
if ((IsNullOrEmpty $CertSubject) -and (IsNullOrEmpty $Certificate))
	{
	throw "You must specify either a certificate or a certificate subject"
	}
if (-not (IsNullOrEmpty $Certificate))
	{
	$cert = $Certificate
	}
else
	{
	$cert = GetCertBySubject $CertSubject	
	}
return getJwtHdr (ToBase64Url $cert.GetCertHash())
}

function Get-SignedJwt
{
<#
.SYNOPSIS

Retrieves a full JWT (header and body), signs it with the specified signature and returns a base-64 encoded representation
that can be directly submitted to either the platform or an appropriately configured identity provider for authentication

.EXAMPLE

Get-1ESignedJwt -AppId <appId> -CertSubject <certsubject>

.PARAMETER AppId
Specifies the application Id of the application for which the JWT is being created

.PARAMETER CertSubject
Specifies the subject of the appropriate signing certificate, which is assumed to be present in the local machine personal cert store

.PARAMETER CertThumbprint
Specifies the thumbprint of the appropriate signing certificate, which is assumed to be present in the local machine personal cert store

.PARAMETER Certificate
Specifies an X509 certificate object to be used to sign the JWT

.PARAMETER MetadataEndpoint
If specified, defines the metadata endpoint which is to be contacted in order to retrieve the token issuing endpoint which will be
filled in when creating the JWT
If not specified, the user is assumed to have already connected to a platform instance using the Set-1EServer cmdlet, and the appropriately configured
metadata endpoint will be retrieved from the platform instead

.PARAMETER Principal
If specified, adds a custom member property to the JWT defining the desired platform principal that is to be requested
[This parameter is ignored by identity providers and is used only when authenticating via JWT to the platform]

.NOTES

This cmdlet is intended only for test purposes. It does not submit the JWT to the Identity Provider or the platform.
It can be used to create signed JWTs for use in external integration projects e.g when testing APIs via PostMan etc.

#>
[CmdletBinding()]
Param(
  [Parameter(Mandatory=$true)] [string]$AppId,
  [Parameter(Mandatory=$false)] [string]$Principal,
  [Parameter(Mandatory=$false)] [string]$MetaDataEndpoint,
  [Parameter(Mandatory=$false)] [object]$Certificate,
  [Parameter(Mandatory=$false)] [string]$CertSubject,
  [Parameter(Mandatory=$false)] [string]$CertThumbprint
)

if ((IsNullOrEmpty $CertSubject) -and (ISNullOrEmpty $CertThumbprint) -and ($null -eq $Certificate))
	{
	throw "You must specify one of -Certificate, -CertThumbprint or -CertSubject"
	}

if (-not (IsNullOrEmpty $Certificate))
	{
	$cert = $Certificate
	}
else
	{
	if (-not (IsNullOrEmpty $CertSubject))
		{
		$cert = GetCertBySubject $CertSubject	
		}
	else
		{
		$cert = GetCertByThumbpring $CertThumbprint
		}
	}

if (IsNullOrEmpty $MetadataEndpoint)
	{
	$metadataEndpoint = GetMetadataEndpoint
	}
write-information -MessageData ([string](get-date) + " Attempting to retrieve token issuing endpoint for identity provider")
$tokenEndpoint = GetTokenEndpoint $MetadataEndpoint

$jwt = GetSignedJwt $cert  $tokenEndpoint $appId $Principal
return $jwt
}

function Invoke-ProductPackDeploymentTool
{
<#
.SYNOPSIS

Invokes the Product Pack Deployment Tool. If the target platform is configured for platform-neutral authentication, a freshly refreshed access token is passed to the tool

.EXAMPLE

Invoke-ProductPackDeploymentTool -Path <path> [-Force]

.PARAMETER Path

Specifies the path to the deployment tool executable

.PARAMETER Force

Specifies that the deployment tool will be configured to allow existing product packs to be deleted. Use caution when running the tool with this functionality enabled.

#>
[CmdletBinding()]
Param(
  [Parameter(Mandatory=$true)] [string]$Path,
  [Parameter(Mandatory=$false)] [switch]$Force
)
if (IsNullOrEmpty ($script:TACHYONURL))
	{
	throw "Platform server has not been defined"
	}
$exepath= $path + "\${PPDTTOOL}"
$arglist = "-url  https://" + $script:TACHYONURL + "/consumer"
$token = Get-AuthToken
if (-not (IsNullOrEmpty $token.token))
	{
	$token = update-authtoken
	if (-not (IsNullOrEmpty $token.token))
		{
		if ($token.TokenType -eq 2)
			{
			$arglist = $arglist + " -platformtoken " + $token.token
			}
		else
			{
			$arglist = $arglist + " -token " + $token.token
			}
		}
	}
if ($Force)
	{
	$arglist = $arglist + " -poc"
	}
start-process $exepath -argumentlist $arglist
}


function Get-Application
{
<#
.SYNOPSIS

Retrieves either the full set of installed platform applications, or the application whose Id is specified by the optional -Id parameter

.EXAMPLE

Get-1EApplication

.PARAMETER Id

Specifies the id of the application for which information is to be returned



#>
[CmdletBinding()]
Param(
  [Parameter(Mandatory=$false)] [int]$Id
)
if ($id -eq 0)
    {
    $res = GetHttpRequest "/tachyon/api/Applications"
    }
else
    {
    $res = GetHttpRequest ("/tachyon/api/Applications/" + $id)
    }
return $res
}

function Get-Configuration
{
<#
.SYNOPSIS

Retrieves information on the customer, UI Telemetry Key and base consumer API endpoint

.EXAMPLE

Get-1EConfiguration


#>
[CmdletBinding()]
Param(
)
$res = GetHttpRequest "/tachyon/api/SystemInformation/Configuration"
return $res
}

function Get-GroupMember
{
<#
.SYNOPSIS

Retrieves the members of the specified group

.PARAMETER Name

Specifies the name of the group for which members are to be returned

.EXAMPLE

Get-1EGroupMember -Name Administrators


#>
[CmdletBinding()]
Param(
  [Parameter(Mandatory=$true)] [string]$Name
)
$res = GetHttpRequest ("/tachyon/api/UsersAndGroups/GetGroupMembers/" + $Name)
return $res
}



function Get-JwkFromCertificate
{
<#
.SYNOPSIS

Retrieves the public key of a certificate and returns it as a JWK. Some identity providers require certificate public keys in this format when setting up applications
to support the oAuth Client Assertion Grant Flow

.PARAMETER CertSubject

Specifies the subject of the certificate to be used 

.PARAMETER CertThumbprint

Specifies the thumbprint of the certificate to be used

.PARAMETER Certificate

Specifies an X509 Certificate object to be used


.EXAMPLE

Get-1EJwkFromCertificate -CertSubject <certsubject>



#>


[CmdletBinding()]
Param(
     [Parameter(Mandatory=$false)] [string]$CertSubject,
     [Parameter(Mandatory=$false)] [string]$CertThumbprint,
     [Parameter(Mandatory=$false)] [object]$Certificate
)
     if ((IsNullOrEmpty $CertSubject) -and (IsNullOrEmpty $CertThumbprint) -and (IsNullOrEmpty $certificate))
	{
	throw "You must specify either a certificate subject, a certificate thumbprint or a certificate"
	}
     if (-not (IsNullOrEmpty $Certificate))
		{
		$cert = $Certificate
		}	
     else
		{		
	        if (-not (IsNullOrEmpty $CertThumbprint))
			{
	   	        $cert = GetCertByThumbprint $certThumbprint
			}
	        else
			{
	     		$cert = GetCertBySubject $certSubject
		 	}
		}
     return getJwkFromCert $cert
}

function Add-AxmDatadogConfiguration 
{
<#
.SYNOPSIS

Add Datadog configuration to Global Settings

.EXAMPLE

Add-1EAxmDatadogConfiguration -DatadogKey e78236d262c7008c263f1e9c61a671e3 -DatadogSite https://myserver.mydomain.local -Enable $true

.PARAMETER DatadogApiKey

Specifies the Datadog API key requires for authentication

.PARAMETER DatadogSite

Specifies the Datadog Site url 

.PARAMETER Enable

Enables/Disables Datadog integration

.NOTES

This cmdlet requires platform release 8.4 or later

#>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)] [string]$DatadogApiKey,
        [Parameter(Mandatory = $true)] [string]$DatadogSite,
        [Parameter(Mandatory = $false)] [bool]$Enable = $true
    )
          
    $payload = @{
        Name  = 'AxmDatadogConfiguration'
        Usage = 0
        Value = '{ "ApiKey":' + (quotify $DatadogApiKey) + ', "SiteName":' + (quotify $DatadogSite) + ' }'
    }

    $payload = $payload | ConvertTo-Json

    Write-Output $payload
    $res = PostHttpRequest "/consumer/Settings" $payload

    Enable-AxmDatadogIntegration -Enable $Enable
    return $res
}

function Enable-AxmDatadogIntegration 
{
<#
.SYNOPSIS

Enable Axm Datadog integration

.EXAMPLE

Enable-1EAxmDatadogIntegration -Enable $true

.PARAMETER Enable

Enables/Disables Datadog integration

.NOTES

This cmdlet requires platform release 8.4 or later

#>

    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)] [bool]$Enable = $true
    )
    
    $payload = @"
	    {
        "Name":"EnableAxmDatadogIntegration",
        "Value": $(if ($Enable) {"true"} Else {"false"}),
        "Usage":0
        }
"@
    $res = PostHttpRequest "/consumer/Settings" $payload
    return $res
}


function Get-ExportedResult
{
<#
.SYNOPSIS

Returns the specified exported result set

.PARAMETER Id

Specifies the Id of the exported result set for which the data is to be returned
Use the Get-1EExportedResultSet cmdlet to retrieve available result sets and their associated Ids

.PARAMETER Path

Specifies the path to a file to which the results will be written instead of being directly returned as the result

.EXAMPLE

Get-1EExportedResult -Id 3

.NOTES

This cmdlet requires platform release 8.5 or later

#>

[CmdletBinding()]
param(
     [Parameter(Mandatory = $true)] [int]$Id,
     [Parameter(Mandatory = $false)] [string]$Path
     )
$start = 0
$length = 100000
$sb = [System.Text.StringBuilder]::new()	
if (-not (IsNullOrEmpty $Path))
    {
    if (test-path $Path)
        {
        throw "The specified file already exists"
        }
    }
while ($true)
	{
	$url = "/consumer/DataExport/Exported/" + $id + "/" + $start + "/" + $length
	write-information -MessageData ([string](get-date) + " Retrieving " + $length + " bytes. Start location:" + $start)
	$res = GetHttpRequest $url
    if ($res.Length -eq 0)
        {
        break
        }
    $res = FromBase64 $res
    if (IsNullOrEmpty $Path)
        {
        [void]$sb.Append($res)
        }
    else
        {
        add-content -Path $Path -Value $res
        }    
	if ($res.Length -lt $length)
		{
		break
		}
	$start = $start + $length
	}
if (IsNullOrEmpty $Path)
    {
    return $sb.ToString()
    }
}    

function Get-ExportedResultSet
{
<#
.SYNOPSIS

Returns a list of available exported result sets from instructions

.PARAMETER InstructionId

Specifies the Id of the instruction whose exported result sets are to be listed

.EXAMPLE

Get-1EExportedResultSet

.NOTES

This cmdlet requires platform release 8.5 or later

#>

    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$false)] [int]$InstructionId = 0
    )
    if ($InstructionId -gt 0)
    {
        $res = GetHttpRequest "/consumer/DataExport/Exported/Instruction/$InstructionId" 
    }
    else
    {
        $res = GetHttpRequest "/consumer/DataExport/Exported"
    }
return $res
}    

function Remove-ExportedResultSet
{
<#
.SYNOPSIS

Deletes the exported result set whose Id is specified.
Use the Get-1EExportedResultSet cmdlet to get a list of exported result sets and their Ids

.PARAMETER Id

Specifies the Id of the exported result set which is to be deleted

.EXAMPLE

Remove-1EExportedResultSet -Id 3

.NOTES

This cmdlet requires platform release 8.5 or later

#>

    [CmdletBinding()]
    param(
    [Parameter(Mandatory = $true)] [int]$Id
    )
$url = "/consumer/DataExport/Exported/" + $Id
$res = DeleteHttpRequest $url
return $res
}    

function Convert-Principal
{
<#
.SYNOPSIS

Converts principal names expressed in Windows form (domain\user) to a user principal name (mappeduser@mappeddomain.com)
and then updates the principal records for each principal.

.PARAMETER DomainMapping

Specifies either a single string to which all domains are mapped as the UPN suffix, or a dictionary(hashtable) of domain names -> UPN suffixes (see notes)

.PARAMETER UserMapping

If not specified, the user part of the principal name is directly used as the UPN prefix. If specified, contains a dictionary(hashtable) of users and their corresponding mapped identities
as UPN prefixes. A user principal entry not contained in the UserMapping dictionary is left unchanged in the principal table.

.PARAMETER WhatIf

Shows the principals and their proposed remappings but does not actually update the principal table

.PARAMETER Path

Specifies the path to a CSV file to be used to map principals. Each line in the file specifies a source principal 
and a destination principal. If you use a mapping file then the mapping entries can be any arbitrary strings
which means you can map UPNs to other UPNs, or you can map to and from domain names.

.PARAMETER OutPath

Specifies the path to a CSV file to be created from the proposed principals and their remappings. This file can then be edited
to be used as an input mapping file

.EXAMPLE

Convert-1EPrincipal -DomainMapping megacorp.com

    All users will be mapped to user@megacorp.com

.EXAMPLE

Convert-1EPrincipal -DomainMapping {"Megacorp" = "Megacorp.com"}

    Users whose domain is Megacorp will be mapped to user@megacorp.com. Other domain users will be left unchanged

.EXAMPLE

Convert-1EPrincipal -DomainMapping {"Megacorp" = "Megacorp.com"; "Ultracorp" = "Ultracorp.com"}

    Users whose domain is Megacorp will be mapped to user@megacorp.com.
    Users whose domain is Ultracorp will be mapped to user@ultracorp.com
    Other domain users will be left unchanged

.EXAMPLE

Convert-1EPrincipal -DomainMapping megacorp.com -UserMapping {"Fred Smith" = "Fred.Smith"; "Rachel Gates" = "Rachel.Gates"}

    The users Fred Smith and Rachel Gates will be mapped to Fred.Smith@megacorp.com and Rachel.Gates@megacorp.com respectively
    Other users will be left unchanged

.EXAMPLE

Convert-1EPrincipal -DomainMapping {"Megacorp" = "Megacorp.com"; "Ultracorp" = "Ultracorp.com"} 
    -UserMapping {"Fred Smith" = "Fred.Smith"; "Rachel Gates" = "Rachel.Gates"}

    The users Fred Smith and Rachel Gates will be mapped as previously, but only if their domains are Megacorp or Ultracorp
    The domain they belong to (Megacorp or Ultracorp) will be preserved e.g ultracorp\Rachel Gates -> Rachel.Gates@ultracorp.com
    Other users will be left unchanged

#>

    [CmdletBinding(SupportsShouldProcess=$true, DefaultParameterSetName='Default')]
    param(
	[Parameter(Mandatory = $true, ParameterSetName='Default')] [object]$DomainMapping,
    [Parameter(Mandatory = $true, ParameterSetName='MapFile')] [string]$Path,
	[Parameter(Mandatory = $false)] [object]$UserMapping,
    [Parameter(Mandatory = $false)] [string]$OutPath
    )
	if ((IsNullOrEmpty $DomainMapping) -and (IsNullOrEmpty $Path))
		{
		throw "You must specify a domain mapping"
		}
	if (-not (IsNullOrEmpty $UserMapping) -and $UserMapping.getType().Name -ne "HashTable")
		{
		throw "$UserMapping must be a hash table"
		}

	

    if ((-not (IsNullOrEmpty $Path)) -and (-not (IsNullOrEmpty $OutPath)))
        {
        throw "Please specify either an input file path or output file path"
        }
    if (-not (IsNullOrEmpty $OutPath))
        {
            
        if (test-path $OutPath)
            {
            throw "The specified file already exists"
            }
        $mapList = UpdatePrincipalMaps (GetPrincipalMaps $DomainMapping $UserMapping) $true
        MapListToCsv $mapList $outPath
        return
        }

    if (-not (IsNullOrEmpty $Path))
        {
        if (-not (test-path $Path))
            {
            throw "The specified file does not exist"
            }
        $hdr = 'From','To'
        $inmap = get-content -Path $Path | convertfrom-csv -Header $hdr
        $hashmap = @{}
        foreach ($map in $inmap)
            {
                $hashmap[$map.From] = $map.To
            }
        if (-not (IsNullOrEmpty $DomainMapping))
            {
            $target=$DomainMapping
            }
        else
            {
            $target=$Path
            }

        if (-not $pscmdlet.ShouldProcess($target))
		        {
                return UpdatePrincipalMaps (GetPrincipalMaps $null $null $hashmap) $true
                }
        $t = UpdatePrincipalMaps (GetPrincipalMaps $null $null $hashmap)
        }
        
    if (-not $pscmdlet.ShouldProcess($DomainMapping))
		{
            return UpdatePrincipalMaps (GetPrincipalMaps $DomainMapping $UserMapping) $true
        }
    return UpdatePrincipalMaps (GetPrincipalMaps $DomainMapping $UserMapping)
}