﻿param(

    [Parameter(Mandatory=$true, HelpMessage="Enter Folderpath")]
    [ValidateNotNullOrEmpty()]
    [string] $FolderPath,
    [Parameter(Mandatory=$true, HelpMessage="Enter the 1e servername Example: 1eServer.YourDomain.Com ")]
    [ValidateNotNullOrEmpty()]
    [string] $1EServer

 )

$scriptname = Split-Path -Leaf $MyInvocation.MyCommand.Definition 
$scriptname = $scriptname.Split(".")[0]

$scriptPath = Split-Path -parent $MyInvocation.MyCommand.Definition 
$LogFilePath = "$scriptPath\$scriptname.log"

# Import the 1E Platform Toolkit and set the Tachyon Server we`re using
$1eToolkit = "$scriptPath\Resource\Custom1etoolkit.psm1" 
$GetModule = get-module -Name Custom1etoolkit
if($null -eq $GetModule){
    import-module $1eToolkit

}
else {
    Remove-Module Custom1etoolkit
    import-module $1eToolkit
}


 function Write-Log {

    [CmdletBinding()]
    Param(
          [parameter(Mandatory=$true)]
          [String]$Path,

          [parameter(Mandatory=$true)]
          [String]$Message,

          [parameter(Mandatory=$true)]
          [String]$Component,

          [Parameter(Mandatory=$true)]
          [ValidateSet("Debug", "Info", "Message", "Warning", "Error")]
          [String]$Type
    )

    switch ($Type) {
        "Info" { [int]$Type = 1 }
        "Warning" { [int]$Type = 2 }
        "Error" { [int]$Type = 3 }
        "Debug" { [int]$Type = 4 }
        "Message" { [int]$Type = 5 }
    }

    # Create a log entry
    $Content = "<![LOG[$Message]LOG]!>" +`
        "<time=`"$(Get-Date -Format "HH:mm:ss.ffffff")`" " +`
        "date=`"$(Get-Date -Format "M-d-yyyy")`" " +`
        "component=`"$Component`" " +`
        "context=`"$([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)`" " +`
        "type=`"$Type`" " +`
        "thread=`"$([Threading.Thread]::CurrentThread.ManagedThreadId)`" " +`
        "file=`"`">"

    try {
        # Write the line to the log file
        Add-Content -Path $Path -Value $Content
    }
    catch {
        Write-Host "User does not have access to write log at path $Path"
        Write-Host $Message
    }

    if ($Type -eq 1) {
        Write-Host $Message -ForegroundColor Yellow
    }

    if ($Type -eq 3) {
        Write-Host $Message -ForegroundColor Red
    }

    if ($Type -eq 5) {
        Write-Host $Message
    }
}

Function Connect1eServer {


    # used for file Open dialog
    $message = "Does this 1ePlatform instance use Modern Auth?"
    Add-Type -AssemblyName System.Windows.Forms
    $msgBoxInput =  [System.Windows.Forms.MessageBox]::Show($message,'Enter Credentials Question','YesNo','Question') 
    switch  ($msgBoxInput) 
    {
        'Yes' {
                set-server $1EServer

           
              }
         'No' {
                $credential = $host.ui.PromptForCredential("Need credentials", "Please enter your user name and password.", "", "NetBiosUserName") 
                set-server $1EServer -credential $credential
                
        
              }
    }



}

Function GetFileContent($InputFile){
    $Fileexists = Test-Path -Path $InputFile

    if ($Fileexists) {
        $Content = "Verified Inputfile location: " + $InputFile
        Write-Log -Path $LogFilePath -Message $Content -Component $MyInvocation.MyCommand.Name -Type Message

     } else {
        $Content = "Cannot Verify Inputfile locaton: " + $InputFile
        Write-Log -Path $LogFilePath -Message $Content -Component $MyInvocation.MyCommand.Name -Type Error
        return "File Does Not Exist"
    }

    $tinputfile = Get-content -path $InputFile

    return $tinputfile


}
###########################End Functions#############################


 
Connect1eServer



$Content = "Verifying Folder Path : $FolderPath"
Write-Log -Path $LogFilePath -Message $Content -Component $MyInvocation.MyCommand.Name -Type Debug

if (!(Test-Path $FolderPath)) {
    $Content = "Folder path does not exist : $FolderPath"
    Write-Log -Path $LogFilePath -Message $Content -Component $MyInvocation.MyCommand.Name -Type Error

    exit
}

$Content = "Fetching all supported files from folder"
Write-Log -Path $LogFilePath -Message $Content -Component $MyInvocation.MyCommand.Name -Type Debug
$files = Get-ChildItem -Path $FolderPath -Filter *.txt

$Content = "Total Files in folder $FolderPath : $($files.Count)"
Write-Log -Path $LogFilePath -Message $Content -Component $MyInvocation.MyCommand.Name -Type Debug

foreach($file in $files)
{
    $fileFullPath = $file.FullName

    $Content = "Reading File : $fileFullPath"
    Write-Log -Path $LogFilePath -Message $Content -Component $MyInvocation.MyCommand.Name -Type Message

    $stopwatchFileRead =  [system.diagnostics.stopwatch]::StartNew()
    
    $computerList = New-Object System.Collections.Generic.List[System.Object]

    foreach($line in [System.IO.File]::ReadLines($fileFullPath))
    {
        if($line -ne ""){
            $computerList.Add($line.Trim())
        }
    }

    if($computerList.Count -lt 2){
        $Content = "No device present in file"
        Write-Log -Path $LogFilePath -Message $Content -Component $MyInvocation.MyCommand.Name -Type Error
        
        Continue
    }

    #File name is Management Group Name
    $MGName = $file.BaseName
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($MGName)
    $encoded = [System.Convert]::ToBase64String($bytes)
    $uri = "/Consumer/ManagementGroups/Name/$encoded"
    
    $MGID = 0
   

    try {
            $response = 1eGetHttpRequest -Url $uri
            $MGID = $response.UsableId
    
    }
    catch {
            $err = $_

            $Content = "Management Group does not exist"
            Write-Log -Path $LogFilePath -Message $Content -Component $MyInvocation.MyCommand.Name -Type Info

            $Content = "Setting Management Group ID to 0"
            Write-Log -Path $LogFilePath -Message $Content -Component $MyInvocation.MyCommand.Name -Type Info

            $MGID = 0
    } 



    #First line of the file is the Management Group Description
    $MgDescription = $computerList[0]
    
    #Removing the first line from collection as it's MG description
    $computerList.RemoveAt(0)
    
    #create payload
    $SubComputers = @()
    foreach ($computer in $computerList) 
    {
        $i += 1
        $SubComputers += [PSCustomObject]@{Operator = "=="
                     Attribute = "ReportDeviceUser.PrimaryUsername"
                     Value =  $computer 
                     _type = "text"}
        
    }


    $SubOperators = [PSCustomObject]@{
    Operator = "or"
    Operands = $SubComputers

    }


    $SubParent = [PSCustomObject]@{
    Id = 0
    Name = "All Devices"

    }
    
    $Root = [PSCustomObject]@{
    Rules = $SubOperators
    Name = $MGName
    Description = $MgDescription
    RuleType = "RuleBased"
    Parent = $SubParent
    Id = $MGID

    }
        
    $payload = $Root | ConvertTo-Json -Depth 3 


    #send payload

    $stopwatchFileRead.Stop()

    $Content = "Time taken in reading file : $($stopwatchFileRead.Elapsed.TotalSeconds) seconds"
    Write-Log -Path $LogFilePath -Message $Content -Component $MyInvocation.MyCommand.Name -Type Debug
    
    $Content = "Creating Management Group -"
    Write-Log -Path $LogFilePath -Message $Content -Component $MyInvocation.MyCommand.Name -Type Info
    
    $Content = "  Name : $MGName"
    Write-Log -Path $LogFilePath -Message $Content -Component $MyInvocation.MyCommand.Name -Type Message
    
    $Content = "  Description : $MgDescription"
    Write-Log -Path $LogFilePath -Message $Content -Component $MyInvocation.MyCommand.Name -Type Message
    
    $Content = "  Total Devices in file : $($computerList.Count)"
    Write-Log -Path $LogFilePath -Message $Content -Component $MyInvocation.MyCommand.Name -Type Message
    
    #$uri = "$TachyonApiBaseUrl/admin/ManagementGroupsEx"
    $uri = "/admin/ManagementGroupsEx"

    $Content = "URI : $uri"
    Write-Log -Path $LogFilePath -Message $Content -Component $MyInvocation.MyCommand.Name -Type Debug

    if($MGID -eq 0){
                    1ePostHttpRequest -url $uri -payload $payload
        
    }
    else{
                    1ePutHttpRequest -url $uri -payload $payload
    }


    
}

$Content = "Complete"
Write-Log -Path $LogFilePath -Message $Content -Component $MyInvocation.MyCommand.Name -Type Message









######################################################################

